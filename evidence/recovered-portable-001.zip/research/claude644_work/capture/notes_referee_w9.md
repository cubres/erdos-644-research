# notes_referee_w9.md (referee wave 9)

## [core#3] entry 0 -- START (24 Sep). Claim: Theorems L+ / L++ (heavy-neighbourhood structure).
* Read claim (w7_attack_results_full.json core list idx 3), notes_core.md c6, attacker certs w6_core_thmL{plus,pp}_cert.py,
  prior referee [core#0..2] in notes_referee_w7.md (Lemma Q logic FULL_PROOF; Theorem L CONFIRMED with convention fix).
* Hand re-derivation of L+ and L++: every budget step checks (see entry 1). Writing w9_ref_core3_*.py.

## [dense#1] entry 0 -- START (referee w9, 24 Sep). Claim: Corollary Q (3/4 for profile-quasirandom intersecting families).
* Read claim (w7_attack_results_full.json P8 list idx 1), notes_dense.md ckpt 2-5/w8, referee w7 [denseTwoPart] entries 1-4.
* Plan: hand re-derivation; w9_ref_dense1_lower.py (lower-bound lemma tau*(T) >= tau-2D-2, general shift s, small random
  families, exact f by subset enumeration); w9_ref_dense1_e2e.py (type-closed special case at large k: explicit anchored
  template + rounding -> explicit bad tuple whenever tau exceeds the bound); novelty grep vs note 7.75/7.76.

## [core#7] Lemma T (lazy tetrahedral dual pencil) -- referee report (wave 9, 24 Sep 2026)
VERDICT: CONFIRMED_WITH_FIXES (logic correct; upgrade to FULL_PROOF; not new as a support; significance overstated).
* Statement re-derived. Hand proof (3 lines): a point's type T satisfies: |T&A|<=3; pair of matching mu in T&A =>
  B-row(mu) notin T; T&A nonempty => {5,6,7} not subset T. If S|T=[7]: neither is disjoint from A (else the other
  contains A); so neither contains all of B. A type with |T&A|=3 contains a pair of every matching, hence no B-row,
  forcing the other to contain B -- impossible. So S&A, T&A are complementary pairs e, A\e: same matching mu, both
  omit B-row(mu). Contradiction. => FULL_PROOF (the CERTIFICATE label undersells it).
* w9_ref_core7_lemmaT.py (exact, independent): (a) no covering pair, all 6 orders; maximal allowed types are EXACTLY
  note Lemma 7.70's 11 parent cells (so the static support is the note's; its hand proof of non-covering is in the note).
  (b) each hypothesis necessary: dropping core rule -> {1,2,3}+{4,5,6,7}; dropping empty 4-wise intersection ->
  {1,2,3,4}+{5,6,7}; dropping any pair rule -> explicit 2-point counterexample. B-core outside U_A witness OK.
  (c) 117670 random actual 7-edge systems satisfying hypotheses: none 2-pierceable. (e) unified sharpening sound.
* w9_ref_core7_e2e.py: 400 random families, 84985 Lemma-T tuples from actual edges, none 2-pierceable; 1327 had no
  Lemma-Q completion in H (T strictly stronger than Q in practice). w9_ref_core7_k12.py: in (7,2) K_9^(5), K_12^(7)
  no quad even has |I5|,|I6|,|I7|<=t-1 (vacuous sanity check).
* SHARPENING (checked): hypothesis 'G1&..&G4 empty' may be replaced by 'G1&..&G4 empty OR G5&G6&G7 subset U_A';
  this unifies Lemma Q (G7 avoids G5&G6 => B-core empty) and Lemma T. Also G1..G7 need not be distinct.
  Note G5&G6&U_A may be replaced by G5&G6&(points in exactly one A-row) without changing the forbidden set (points in
  >=2 A-rows of G5&G6 already lie in I7) -- no quantitative gain.
* NOVELTY: static support = note Lemma 7.70 (tetrahedral K_4 support, 11 parents), already used in note Thm 7.71
  (all two-fixed-type families, incl. nonintersecting). New only: the lazy avoid-set formulation for general
  families (found A-rows, sequential B-rows) and the explicit link to Lemma Q. Modest.
* SIGNIFICANCE CAVEATS: (1) W(x,s) (the motivating two-type family) is a two-fixed-type family, so it is already
  killed by the note (Lemma 7.70 / Thm 7.71); it is a gap only in the attacker's Fano-only toolkit, not in the note.
  (2) 'oracle versions provably insufficient' (c7, w6_core_lemmaT_cont.py) is NUMERICAL (float HiGHS LP, 3 parameter
  points) and tests ONE accounting (G6 avoids I6 u (U_A\(I5uI6))); it does not prove that every oracle/lazy recipe
  fails. (3) The lemma is pure logic; its quantitative use needs |I5|,|I6|<=t-1 and |I7|+|G5&G6&U_A|<=t-1, and no
  bound on |G5&G6&U_A| for oracle B-rows is supplied -- the claim gives no inequality on H by itself.

## [dense#2] Averaging proposition: "2-part rank loss = height imbalance"  (referee w9, 24 Sep 2026)
Source: w7_attack_results_full.json key "I picked up topic P8 ...", index 2; notes_dense.md [w8 checkpoint 2].
VERDICT: CONFIRMED_WITH_FIXES (the stated inclusion + rank identity are correct; the title and the
"significance" claims go beyond what is proved).
Re-derivation (hand):
 (1) f_2(a,b)=E_U f_pi(a,U): a uniform b-subset of O, conditioned on its part counts U, is uniform and independent
     in each O_s; W cap E0 is independent. Correct. Needs E0 to be ONE unsplit part in both models.
 (2) U_s hypergeometric, E U_s = b n_s/X. If b n_s/X >= u_s+lam then {U_s<u_s} is in {U_s <= EU_s-lam}, and
     Hoeffding (1963, Sec. 6, sampling without replacement) gives prob <= exp(-2 lam^2/b). Union over s, then
     monotonicity of f_pi: f_2 >= P(U>=u) f_pi(a,u) >= (1-m e^{-2lam^2/b})(1-eta) >= 1-eta-m e^{-2lam^2/b}. Correct.
 (3) a + X h = a + sum u_s + sum n_s(h-y_s). Correct identity.
Fixes / side conditions:
 F1 b <= X is implicit; the hypothesis is satisfiable only if u_s+lam <= n_s for all s. For types with a full or
    nearly full part the image must be CLIPPED: (a, min(X, X h + lam X/min n)). Clipping is harmless because at
    b=X, U=n deterministically and f_2(a,X)=f_pi(a,n)>=f_pi(a,u).
 F2 The error term: lam = sqrt(b ln(m/delta)/2) for target failure prob delta, so the shift is
    O(sqrt(X log(m/delta)) X/min_s n_s); "O(sqrt(k log m))" needs X=O(k) (dense regime) and delta fixed; for m=1
    there is no loss at all (U deterministic). Useful only when min n_s >> sqrt(k).
 F3 TITLE OVERCLAIMS. What is proved is ONE inclusion: A_2(eta+delta) contains the (shifted, clipped) height image
    of A_pi(eta). "2-part model cannot see unbalanced fine types" and "the 2-part averaged model IS the height
    model" need the CONVERSE, which the attacker did not state. Referee's converse (same proof, other tail):
       f_2(a,b) >= 1-eta  =>  f_pi(a,v) >= 1-eta-m e^{-2lam^2/b},   v_s := min(n_s, ceil(b n_s/X + lam)),
    since f_pi(a,U) <= f_pi(a,v) on {U<=v}. v is nearly balanced (X h(v) <= b + lam X/min n + m X/min n), so
    A_2(eta) sits inside the height image of the (near-)balanced part of A_pi(eta+delta). Both inclusions hold only
    modulo the threshold shift eta -> eta+delta and the additive lam-shift; with no threshold sharpness the two
    robust sets are NOT literally equal. "Rank loss = imbalance" is therefore an approximate type-level
    correspondence, not an identity of rank-loss numbers (RL is a tau* difference).
 F4 Correct quantitative form of "2-part rank loss <= imbalance" (continuous; referee proof via uniform boxes as in
    M1): for any T subset A_pi(eta), c = lam X/min n, delta = m e^{-2lam^2/X} (note e^{-2lam^2/b} <= e^{-2lam^2/X}
    as b<=X), R = max_{g in T}(|g|+I(g)) + c:
        tau*( A_2(eta+delta)^{<=R} ) >= tau*( up T ) - c      (integer version: extra -(m+1)).
    Proof: (alpha,beta) free for the truncated 2-part set => (alpha, (beta-c)^+ n/X) free for up T.
 F5 The transfer theorem uses SHIFTED robust sets A^{(s)} (f((u-s)^+)); the proposition is stated for unshifted
    ones. Adaptation is routine (apply to (a-s)^+, (u-s)^+ and b-s) but should be written.
 F6 Lemma 7.9 example (E0 split into E0 cap X, E0 cap Z) is NOT covered: the proposition averages over O only.
    A symmetric version averaging E0-subparts also holds by the same proof.
Scripts (exact, all 0 failures):
 w9_ref_dense2_averaging.py (Fractions, subset enumeration, N<=12, m=2,3; seeds 1,7; 190 families):
    T1 identity 4854+1251 checks, T2 exact hypergeometric tail vs Hoeffding 5639+1654, T3 proposition 48539+14344,
    T4 referee converse 39024+9676, T5 rank identity, T6 tau*_int(A_pi) <= tau*_int(A_2). 0 failures.
    (Caveat: at N<=12 the Hoeffding term often makes the bound vacuous.)
 w9_ref_dense2_typeclosed.py (type-closed fine sets, n_s in [15,40], exact hypergeometric f_2): T3 11084+4284 checks
    of which 4307+1700 non-vacuous, 0 failures. SHARPNESS: min{b: f_2(a,b)>=0.9} - X*min h(g) in [-1.0, 9.5], i.e.
    the 2-part boundary tracks the HEIGHT X h(g), not |u| (e.g. X h=75.2, beta_2=81, min|u|=38): the imbalance
    loss is real, supporting the qualitative significance.
 w9_ref_dense2_rankloss.py (F4 integer form with delta=1/4): seeds 5,13 (65 instances) 0 failures; at these sizes
    the slack c dominates, so it is a sanity check only.
NOVELTY: not in the note. grep 'hoeffding|hypergeometric|height|imbalanc': note's "imbalance" (7.114-7.117) is the
    triple pair-overlap imbalance of complementary cores (different concept); "hypergeometric" only in the
    Frankl-Kupavskii literature summary. Technique is elementary/standard (coarse-graining + Hoeffding); new to the
    project as a formal statement; supporting lemma, no progress on the 3/4 bound by itself.

## [core#5] entry 0 -- START (referee w9, 24 Sep). Claim: W(x,s) two-part two-type family, tau*->6/7, all local
## rules hold, no Fano bad tuple (w7_attack_results_full.json core list idx 5; notes_core.md c7/c7b).
* Hand: tau* = min(x-s, 2x-2+2s) = 2x-2+2s when s<(2-x)/3 (automatic for s<1-2x/3, x>1). OK.
* HAND PROOF of no-Fano (much simpler than 128 LP duals, valid for ALL x,s with 3(1-s)>2x, no closeness needed):
  in any Fano-labelled tuple the 3 edges on 3 CONCURRENT lines have every vertex in <=2 of them, so their per-part
  mass sum is <= 2x. Three a-edges have Q-mass 3(1-s) > 2x, three b-edges P-mass 3(1-s) > 2x. The concurrent
  triples of lines form a (dual) Fano plane, which is not 2-colourable => some concurrent triple is monochromatic.
  Same argument as note Prop 7.55 (s=0 case of W!). Equivalently: a-edges and b-edges are each 3-wise intersecting.
* Novelty: W(x,0), x=7/5 IS note Prop 7.55 (4/5). W is also a two-fixed-type family => killed by note Thm 7.71.
  Writing w9_ref_core5_check.py.

## [dense#0] entry 0 -- START (referee w9, 24 Sep). Claim: Transfer Theorem (exact rank-loss condition, profile models).
* Read claim (w7_attack_results_full.json P8 list idx 0), notes_dense.md (all ckpts), note 7.3/Lemma 7.5, 7.75-7.80
  (Thm 7.73 3-part two-box, Lemma 7.74 gap, Thm 7.75 two-part [C] <=14 parent cells, Cor 7.76), referee w7 [denseTwoPart].
* Hand pass so far: (i) completeness, (ii) soundness rounding (window integer > u-c => >= u-s), (iii) intersecting via
  random disjoint pair, Lemma U, final chain all check.  Early flags: (b) needs r >= |E0| (w7 already asked; still
  missing); (iv) needs H intersecting for A-A pairs; 'Thm 7.75' is note section 7.77 (label 7.75), [C] (Astra).
* Plan: w9_ref_dense0_e2e.py (exact f, completeness, intersecting, soundness with general bad supports + anchored,
  explicit realised tuples brute-forced), w9_ref_dense0_lemmaU.py.

## dense#7 -- "Counting lemma: (7,2) family in the dense regime has exponentially many edges"  (referee w9, 24 Sep)
VERDICT: CONFIRMED (FULL_PROOF, elementary), with wording fixes; significance statement is heuristic only.
Re-derivation. alpha(H)=N-t exactly (edge-free set <-> complement is a transversal). A set S with |S|=N-t+1
  has complement of size t-1, not a transversal, so some edge G subset S. Count pairs (S,G), G subset S:
  C(N,N-t+1) <= sum_G C(N-|G|, N-t+1-|G|) <= |H| C(N-k',N-t+1-k')  (C(N-g,m-g)=C(N-g,N-m) is nonincreasing in g;
  edges with |G|>N-t+1 contribute 0).  Hence |H| >= C(N,t-1)/C(N-k',t-1) = C(N,k')/C(N-t+1,k') (=C(N,k')/C(alpha+1,k'),
  the trivial Turan/de Caen averaging bound for "every (alpha+1)-set contains an edge").  Side condition
  N-t+1 >= k' is automatic (t>=1).  Second inequality: ratio = prod_{i<k'} (N-i)/(N-t+1-i), each factor >=
  N/(N-t+1) since (N-i)/(M-i) increases in i for M<N.  Correct.
Issues / fixes:
 (1) TITLE: property (7,2) is NEVER used; the lemma holds for every hypergraph. Say "any family with tau=t".
 (2) t >= 3k/4 is unnecessary; t=Omega(k), k'=Omega(k), N=O(k) suffice. The rate is ~ k' ln(1+(t-1)/(N-t+1)),
     which degrades like (3/4)(k'/k)k/c for N=ck: the "dense regime" hypothesis N=O(k) is ESSENTIAL and is NOT
     supplied by the normal form (which only gives N >= 7t/3 - O(1) via the Fano bound / n >= 3t-e/2-O(1)).
     For N superlinear in k the bound is only exp(O(k^2/N)).
 (3) k'=Omega(k) in the normal form: k' >= t (intersecting) or k' >= t-floor((k+4)/5) >= 11k/20-1 (general) -- OK.
 (4) SIGNIFICANCE overclaims: "rules out few edges as the source of rank loss" is not a theorem. The bound is
     tight at complete families (N=k+t-1, k'=k gives EXACTLY C(N,k) -- verified exactly) but in relative density
     it only gives |H|/C(N,k) >= 1/C(alpha+1,k) (for k'=k), i.e. it does NOT exclude exponentially SPARSE
     families such as H_rho (rho=e^{-ck}) of notes_dense w8 checkpoint 7, which are exactly the random-like
     rank-loss examples. So the lemma excludes only absolute scarcity (subexponentially many edges), a regime
     no one proposed as the source of rank loss; no link between |H| and rank loss RL_pi is proved.
Script: w9_ref_dense7_counting.py (exact Fractions/integers): 4000 random hypergraphs N<=10 (131 of them (7,2)),
  identity C(N,t-1)/C(N-k',t-1)=C(N,k')/C(N-t+1,k') and both inequalities: 0 failures, 584 tight;
  complete K_n^k (k<=6): equality in every case; asymptotic ln(bound)/k table for N=ck, c in {7/4,2,3,5,10}.
NOVELTY: not in the note as stated (grep turan/de Caen/'many edges'/'|H| >='): note has only the linear bound
  |H| >= 4(t-1) (line ~17636) and the UPPER edge-count remark "critical-edge count binom(k+t-1,k) exponentially
  tight" (~20122), whose extremal example is exactly the equality case here. Mathematically folklore (averaging
  / Turan-number lower bound); new to the project only as a remark. No progress on 3/4 by itself.

## [dense#3] entry 1 -- checkpoint (hand verification complete; scripts)
* Hand re-derivation, line by line (continuous semantics of note 7.76: w free iff no type g <= w; closed = compact):
  M1: G'_h compact (continuous image), anchor (e,0), intersecting (a+a'<=e => y_s+y'_s>1 in some s => h+h'>1; g=g' incl.),
  box (alpha,lam X) contains (a,Xh) iff (alpha,lam x) contains g => sup free(G'_h) = sup over UNIFORM free boxes of G'
  <= sup free(G') => tau*(G'_h) >= tau*(G'); rank of image <= R; e <= R; 2-part theorem at scale R; lift: E0 loads
  identical, part-s loads b_{j,s} <= x_s h_j and Lemma 7.63 constraints are monotone upper bounds. CORRECT.
  R1: (w,0_S) contains g iff g in G_S and g<=w => tau*(G_S) >= tau*(G)-x(S). CORRECT.
  R2: (w, x_s/2) contains g iff pi(g)<=w & y_s<=1/2 => loss <= x_s/2; intersecting as claimed; lift: loads <= x_s/2,
      pencil <= 3x_s/2, total <= 3x_s (anchor 0). CORRECT.  (Lifting actually survives threshold 2/3; only intersecting
      needs 1/2 -- mutation 3/5: 0 lift failures, 279 intersecting failures.)
  R3: all b_s <= 1 <= x_s/2 so R2 with no types removed and projection only raises tau* (box (w,x_s)). CORRECT.
      'x_s>=3/2 no Fano constraint': loads<=1, off-anchor pencils <=3 <= 2x_s, total <=6 <= 4x_s -- ANCHORED only
      (needs anchor load 0 on part s; unanchored would need 7/4).
* OBSERVATION (strengthening): the proof of M1 only uses tau*(G'_h) > 3R/4, which is WEAKER than the stated
  tau*(G') > 3R/4 (tau*(G'_h) >= tau*(G'), strict in ~20% of random instances: M1_tau_gain).
* Scripts: w9_ref_dense3_lib.py (independent: Fano {i,i+1,i+3} mod 7, exact Fraction sup-free by branch and bound,
  Lemma 7.63 == class LP on 3000 random loads [w9_ref_dense3_sanity.py]); w9_ref_dense3_red.py seeds 1-5 (20,200 random
  instances, ~39.8k R2 projections, ~9k R3, ~6.9k M1 lifts): 0 failures of R1/R2/R3/NOFANO/M1-components;
  mutations detected (R2 thr 3/5: 279 intersecting failures; loss x_s/3: 514 failures; NOFANO cap 3r/2-1/4: 216).
  Logs w9_ref_dense3_red_s{2..5}.log.
* Running: w9_ref_dense3_m1climb.py seeds 11-14 (hill-climb INTO the qualifying regime; attacker's test never hit it).

## [nonint#2] entry 0 -- START (referee w9, 24 Sep). Claim: Prop C (fattened 7.97; tau=7k/10 with linearly fat core).
* Read claim (w7_attack_results_full.json key "I did not prove the P7 target..." idx 2), notes_nonint.md session 2
  checkpoints A-F, attacker scripts nonint2/fat797_{sat,symbolic,params}.py.
* Hand re-derivation done for cases 0/1/2, tau, Gamma, h. Suspected gaps: (i) case 2 uses |X n U|>=c-a delta as a
  lower bound on a PRODUCT, invalid when c-a delta<0 (degenerate c<delta satisfies (0)-(2)); (ii) scripts field says
  (14,8,11,1) UNSAT but notes ckpt F say it was still running. Plan: w9_ref_nonint2_{conds,sat,tau}.py.

## nonint#3 -- "Lemma H (two-anchor host bound) and Prop B"  (referee w9, 24 Sep) -- START
* Read claim (w7_attack_results_full.json 'I did not prove the P7...' idx 3), notes_nonint.md ckpt B/D/E/F,
  nonint2/hostbound_e2e.py. Hand pass of the badness logic + rounding (13/6) + summation: OK so far.
  Side conditions to check: c'=0 case uses |U|>=delta1+delta2; Prop B omits that hypothesis (automatic? 5delta_i<k).
  Plan: w9_ref_nonint3_logic.py (exhaustive membership-vector check), w9_ref_nonint3_arith.py (exact integer max),
  w9_ref_nonint3_e2e.py (fat anchors, adversarial rows), novelty grep 7.97.
## [core#3] entry 1 (checkpoint ~08:45)
* HAND: L+ budgets T1 (d), T1uT2 (2d), T1uT2uT3 (3d) give pairwise lam-light G1..G4 (Gj avoids T(Gi) => Gj notin N[Gi]);
  |I(mu)|<=2lam<=3lam<=t-1; G6 avoids I6uT(G5) (2lam+d) => |G5&G6|<=lam; G7 avoids I7u(G5&G6) (3lam). CORRECT.
  L++: G1 notin B (B=H would give beta=t>2lam+beta... contradiction), G2: T1uS (d+b <= 2d+b), G3: T1uT2uS (2d+b),
  G4: T1uT2uT3 (3d; G4 may lie in B, fine), G5: I5uS (2lam+b), G6: I6uT(G5) (2lam+d, G5 notin B), G7: 3lam. CORRECT.
  L+ is exactly L++ with delta=max, B=empty, beta=0.  Rank never used (rank-free, like Theorem L).
* w9_ref_core3_logic.py PASS: type logic (G_{4+j} avoids I(mu_j), G7 avoids G5&G6) has no covering pair for all 6
  bijections; each of the 7 constraints individually necessary.  Lightness of G1..G4 is NOT used by the logic, only
  to make |I(mu)|<=2lam.
* w9_ref_core3_e2eA.py (arbitrary random families, independent bitmask tau + pysat bad-tuple search; statement-level,
  not recipe-level): seeds 2-5, 16000 families, 5603 L+ hits, 10925 L++ hits (lam=0,1,2), all non-(7,2). PASS.
* ISSUE 1 (side condition dropped): "In particular, lam=delta=floor(eps t) => tau(B) >= t-2eps t" needs
  3floor(eps t) <= t-1 (e.g. eps < 1/3, or eps=1/3 with 3 not dividing t).  notes_core c6 and the cert docstring
  state the floor((t-1)/3) version correctly; the JSON drops it.  Without it the derivation gives nothing for
  1/3 <= eps < 1/2 (where t-2eps t>0).  Searching for an actual counterexample (parts B/C).
* ISSUE 2 (convention, inherited from Theorem L): needs "every AT MOST 7 edges" (recipe repeats edges: e.g. G2=G1
  when |G1|<=lam).  Literal 'every 7 distinct edges' reading: six disjoint singletons, lam=0: t=6, delta=1, 3lam=0,
  3delta=3, 2lam+delta=1 all <=5 -> L+ false.  Same fix as Theorem L.
* NOVELTY/SCOPE: not in note (grep heavy/neighbourhood/N_lam: nothing).  But for rank-k families and lam >= k/4, note
  7.105 (three pairwise b-light edges, rank<=4b => tau<=3b) + the same greedy gives the STRONGER 2delta >= t
  (G1, G2 avoid T1, G3 avoid T1uT2 are three pairwise light edges) -- so L+ adds content only for lam < k/4.

## [dense#1] entry 1 -- checkpoint (hand check + scripts)
* HAND: proof re-derived line by line. Upper half: T = A^{<=r} u {e0} is finite, rank <= r (e <= k <= r), contains the
  anchor, intersecting (A intersecting by the random-disjoint-sets argument, eta<1/2; no u in A has u_0=0 since O is
  edge-free).  tau*(T)>3r/4 => anchored Fano config (anchored two-part thm, refereed w7) with the six non-L rows in A
  (g*, g'' have a <= 2e/3 < e, so they are not the anchor) => floor/ceil rounding of class masses (E0 L-cells stay 0)
  gives integer windows >= load-3 => each window contains an edge w.p. >= 1-eta (monotone f), union bound over 6
  windows (6 eta<1), L-window contains E0 deterministically => bad 7-tuple, contradiction.  OK.
  Lower half: for REAL closed-free w put m_i = ceil(w_i)-1 (0 if w_i=0): m is integer-free and |w| <= |m|+2 (the claim
  writes "integer box w"; harmless since type coordinates are integers -- closed-free region is a union of integer-corner
  boxes).  m_0 <= e-1 (anchor).  (a) m >= D*1: every set of profile m-D*1 is edge-free (else v=u_G+D*1 <= m, v in A by
  HYP since (v-3)^+ = u_G+(D-3)*1 needs D>=3, |v|<=k+2D=r), so |m| <= alpha+2D.  (b) m_O<D: |m| <= e-1+D-1 <= alpha+D-1
  (E0 smallest => alpha >= e-1); m_0<D: |m| <= D-1+n_O <= alpha+D-1 (O edge-free).  tau*(T) >= tau-2D-2.  OK.
  Arithmetic: tau <= 3(k+2D)/4+2D+2 = 3k/4+7D/2+2.  OK.
* ERROR (rounding, minor): special case D=3 gives tau <= tau*(T)+8 <= floor(3(k+6)/4)+8 = floor((3k+50)/4), which equals
  floor(3k/4)+13 when k = 1,2 (mod 4) (e.g. k=2: 14 vs claimed 13).  The stated "floor(3k/4)+12" is NOT proved for
  k = 1,2 mod 4.  Correct: tau <= floor((3k+50)/4) (<= ceil(3k/4)+12).
* w9_ref_dense1_lower.py (exact f by subset enumeration, general shift s in {0,1,3}, D in {s..s+2}, eta in {0,1/7,1/2};
  N<=13; dense/type-closed/random intersecting families): seeds 1-5 x 400 fams: 47,726 hypothesis-satisfying cases
  (3,892 with tau-2D-2>0), 0 failures of tau*(T) >= tau-2D-2; the sharper tau-2D-1 fails in ~4% -> the '+2' is used.
  Mutation (E0 not smallest) never produced a hypothesis-satisfying case; note that at D=0 case (b) is empty, so the
  'smallest edge' hypothesis is used only through D>=3 (forced by the Fano rounding shift s=3).
* w9_ref_dense1_e2e.py (type-closed special case, k=40..1500, exact alpha/tau/tau*, proof's g*/g'' template, LP class
  masses, rounding, explicit vertex sets, brute-force 2-transversal check): first runs 0 failures; Case 2 hit by a
  hand-designed shape (types k(a,1-a), a ~ .12/.5/.85, e ~ .93k, x ~ 1.2k).  Batch running -> w9_ref_dense1_e2e.log.
* NOVELTY: note Cor 7.76 [C] already covers k-uniform two-part type-closed (7,2) families for ANY bipartition, no
  intersecting (+28).  Q's type-closed case is the narrow subclass "one part is a smallest edge, intersecting"; new
  there only: hand proof, better constant, rank<=k non-uniform.  Genuinely new: the quasirandom relaxation (no
  profile/random-labelling transfer in the note; grep 'quasirandom','profile model','random label' -> none).
* SIGNIFICANCE caveat: the advertised example 'random subfamilies of density exp(-c k)' adds nothing -- tau is
  monotone under taking subfamilies, so random subfamilies of a type-closed (7,2) family are already bounded by the
  type-closed case.  No example is given of a family covered by Q but not contained in a type-closed (7,2) family.

## [dense#0] FINAL VERDICT: CONFIRMED_WITH_FIXES (referee w9, 24 Sep)
Re-derived by hand: f monotone (coupling); (i) u notin A => edge-free set of profile (u-s)^+ => |u|<=alpha+sp, and
tau*_cont >= tau_int - p (maximal closed-free boxes of an integer type set are integer: blocking thresholds are type
coordinates or caps; (w-1)^+ is then strictly free); (ii) rounding: a window loses < (#support cells in it) and is an
integer, so >= u-s; union of cells of a uniformly random ordered assignment is uniform, parts independent, f monotone,
union bound 7 eta<1, vertices of cell C lie only in rows of C, bad support => no 2-transversal; (iii) random disjoint
pair of profiles (u-s)^+,(u'-s)^+ (also u=u'); (iv) anchor load = cap => E0-cells on L vanish, rounding stays inside
support => W_L contains E0 deterministically, 6 random rows; Lemma U: in fact tau*(G_r) = min(tau*(G), N-r) exactly;
final chain tau <= tau*(A)+(s+1)p = tau*(A^{<=r}) + RL + (s+1)p <= 3r/4 + RL + (s+1)p.  All correct.
FIXES:
 F1 (quantifier) (b) holds only for r >= |E0|: the anchored two-part theorem needs the anchor (e,0) of rank <= r.  For
    r<|E0| the proof gives nothing (only the unanchored s=13 route, which needs a different A).  w7 already asked for
    this; the w8 statement still says 'for every r'.  Harmless in use (r ~ k >= e).
 F2 (iv) 'A u {e0} intersecting' needs H intersecting and eta<1/2 for the A-A pairs (proof only treats e0 vs A).
 F3 (status) (a) rests on note Theorem 7.75 (= note SECTION 7.77, 640 exact rational duals [C], Astra) -- CERTIFICATE-
    dependent, not a hand proof; everything else ((i)-(iv), Lemma U, conditional transfer, (b)) is FULL_PROOF.
 F4 (constants, optional) a window containing ALL c support cells of a part loses nothing, so s=c-2 suffices when c>=2:
    Fano s=3 is TIGHT (w9_ref_dense0_sens.py: masses 5.99 x4 in the window, 2.01,2.01,2.02 outside, n=30: floor window
    23, rounded 20); 14-cell supports: s=12, constant 26 instead of 28.
 F5 (meaning of Th(p)) only needed for FINITE INTEGER type sets; Th(p) with s=63 is IMPLIED by the 3/4 conjecture for
    p-part type-closed families (bad supports have <=64 cells: complements form an intersecting family on [7]), so it
    is a genuine necessary sub-case; open for p>=3 (note 7.79 two types insufficient, 7.80 only caps 4r/5).
 F6 (significance) the displayed inequality is an identity-level rearrangement (RL is DEFINED as the deficit); the
    content is (i)-(iv).  Deterministic special case = note Cor 7.76.  Attacker's own ckpt 7: random-like families have
    RL ~ gamma* k for every fixed bounded partition, so transfer + Th(p) alone cannot give 3/4.
CHECKS (all exact, 0 failures): w9_ref_dense0_e2e.py seeds 1-4 x 400 families (N 7..12, exact f by 2^N enumeration):
  completeness 1600, intersecting 937, anchored-intersecting 583, 74 soundness premises realised as explicit 7-tuples,
  all brute-force non-2-pierceable.  w9_ref_dense0_typeclosed.py seeds 1-4 x 3000 (N up to 66, s in {3,6,13}, general
  bad supports + adversarial fractional masses): 4515 premises (243 anchored) rounded + realised, 0 failures.
  Sensitivity w9_ref_dense0_sens.py: covering cell pairs -> 208 pierceable tuples detected.
NOVELTY: new vs note (grep 'random label','rank loss' = 0; nearest: Lemma 7.5 (exact extraction obstruction), Cor 7.76
  (deterministic 2-part), 7.125 (union bound for core replacement, different)).

## [dense#1] entry 2 -- FINAL VERDICT: CONFIRMED_WITH_FIXES
* e2e (w9_ref_dense1_e2e.py, seeds 1-8, log w9_ref_dense1_e2e.log): 14,274 type-closed intersecting instances
  (k=40..1500); 1,310 with tau*(T)>3r/4 (198 Case 1, 1,112 Case 2): template criterion OK, LP masses found, rounding
  windows >= load-3, every window contains an edge, explicit 7 edges brute-force NOT 2-pierceable: 0 failures.
  Lower half tau*(T) >= tau-8: 0 failures.  All 1,294 instances with tau > (3k+50)/4 fired (contrapositive holds).
* w9_ref_dense1_boundary.py: instances with tau = floor(3k/4)+13 (k = 1,2 mod 4) exist on which the proof chain does NOT
  fire (9 found, seeds 1-3) -> the proof cannot give '+12' there; each such family has an explicit integer Fano bad
  tuple (MILP, exactly verified), so it is NOT a counterexample to the stated bound -- the bound is merely unproved.
* Fixes: (1) special case: tau <= floor((3k+50)/4) (= floor(3k/4)+13 for k=1,2 mod 4), not floor(3k/4)+12.
  (2) say explicitly that the continuous sup over closed-free boxes is attained at integer boxes (or use
  m_i = ceil(w_i)-1).  (3) drop/replace the 'random subfamilies' example (tau is monotone under subfamilies, so it is
  already covered by the type-closed case).  (4) novelty wording: type-closed case (k-uniform) is a special case of
  note Cor 7.76 [C]; new = hand proof in the anchored intersecting subclass, rank<=k, constant 12.5, and the
  quasirandom relaxation.

## [nonint#4] Staircase lemma for bi-cliques -- referee w9 START (24 Sep)
Hand re-derivation in progress; scripts w9_ref_nonint4_*.py.

## [dense#3] entry 2 -- FINAL VERDICT: CONFIRMED_WITH_FIXES (mathematics correct; significance overstated)
* M1, R1, R2, R3: FULL_PROOF confirmed line by line (entry 1).  Depends only on the anchored 2-part theorem
  (w7 CONFIRMED_WITH_FIXES; its tau*-formula fix is harmless here).
* QUALIFYING REGIME NOW TESTED (attacker's w8_dense_height_check.py never hit it):
  - w9_ref_dense3_m1explicit.py: explicit stated-regime instance caps (16,15,2), types (a,16-a,0), a=1..15, + anchor:
    intersecting, R=18, tau*(G')=14>27/2; T1 template with six (6,10,0) verified.  (caps (16,15,3): R=19, not qualifying.)
  - w9_ref_dense3_m1climb.py seeds 11-14 (160 restarts, ~104k states, exact): 55 distinct stated-regime instances,
    0 template failures; 2872 distinct instances of the WEAKER hypothesis tau*(G'_h)>3R/4, 0 template failures;
    tau*(G'_h) >= tau*(G') in all.  Logs w9_ref_dense3_m1climb_s1{1..4}.log.
  - [NUMERICAL] stated-regime hits occurred ONLY with m=2 and one outside part of cap <= R/8 (e.g. (16,1),(15,1),(2,15));
    max tau*(G')/R elsewhere ~0.70.  So as stated M1 seems to bite only near the 2-part case; hypothesis tau*(G'_h)>3R/4 is
    the useful one.
* FIXES: (1) state M1 with the weaker hypothesis tau*(G'_h) > 3R/4 (the proof uses only this).
  (2) 'Significance' is not a theorem: R1/R2 LOSE x(S), x_s/2 of tau*, M1 is a sufficient condition, and nothing
  proved removes heavy types (a > 2e/3) or unbalanced types without loss; 'reduces target (1) to unbalanced light/mid
  types with caps in (0,2)' should read: 'parts with cap >= 2 can be removed losslessly (R3); M1 settles every G
  whose height-image has tau* > 3/4 of its height-rank; the rest is open'.  (3) 'x_s >= 3/2 imposes no Fano
  constraint' uses anchor load 0 on part s (anchored model; unanchored threshold 7/4).  (4) optional: R2 lifting holds
  up to threshold 2/3; 1/2 is forced only by intersecting.
* NOVELTY: note has no height/coarsening reduction for multi-part type sets (grep 'height','imbalance' -> 7.114 is
  unrelated); 7.75-7.80 are unanchored 2-part/3-part results.  M1 is new but an easy corollary; R1-R3 elementary.
## [nonint#2] entry 1 -- findings so far
* GAP (literal statement FALSE): (0),(1),(2) as stated admit c<=delta, e.g. (k,s,c,delta)=(13,0,0,1), (25,1,0,2);
  then a K1-row can avoid U entirely (U1 n U = C1, |C1|=c<=delta) and K1-row, K2-row, core row are pairwise disjoint
  (nu=3, not (7,2)). 100 such instances with k<40 (w9_ref_nonint2_conds.py (A)); SAT/MILP find the (1,3,3) bad tuple.
  Proof error: case 2 uses |XnU|>=c-a delta inside a PRODUCT; invalid when c-a delta<0.
  FIX: add c>=delta+1 (already needed for tau). Exact check: c>=delta+1 & (0)-(2) => c>5delta => 5delta<k (0 exceptions
  k<40; by hand: (2) with (a,b)=(1,5) needs (c-delta)(c-5delta)>s^2/4>=0). Then all factors c-a delta (a<=5) are >0, and
  X is nonempty for a<=6 (needed in case 1 when X n U may be empty, and for j=0).
* Exact family k=140n: all conditions + c>5delta hold for every n>=1 (independent Fraction check); margin in (1) a=1 is 3.
* Threshold "delta<=~0.058k" is conservative: continuous optimum equals (5-2delta)/7 up to delta~0.0711k
  (binding: (a,b)=(1,1) cross condition, (6-8d)^2 = 5(5-2d)^2/4).
* SAT (independent encoding, double-lex, Glucose4, models re-verified): (7,2) HOLDS for (7,4,5,0),(9,4,6,1),(11,5,7,1),
  (12,6,9,1),(12,6,8,1),(9,5,7,1),(14,8,11,1),(17,8,12,2),(18,8,13,2); BAD for (7,3,5,1) [(2,4,1)], (12,6,9,2) [(1,3,3)].
  Sweep k<=13 over all corrected instances: all HOLD so far (log w9_ref_nonint2_sweep_1_13.log).
## [core#2] entry 1 (checkpoint). HAND RE-DERIVATION: proof CORRECT.
  t:=3lam+1 <= tau (tau may be infinite; only 'every set of <=3lam points is avoided by an edge' is used) =>
  >=4 distinct nonempty edges.  |I(mu)| <= 2lam <= t-1; |I6 u {g}| <= 2lam+1 <= 3lam (needs lam>=1, the ONLY use);
  g in G5\G6 => G6 != G5 => |G5&G6| <= lam (the ONLY use of the GLOBAL codegree bound beyond G1..G4);
  |I7 u (G5&G6)| <= 3lam.  Type logic (4 constraints C5,C6,C7,C567) re-derived and certified:
  w9_ref_core2_logic.py PASS (universal model over all 128 types, all 6 matching->row bijections; each of the 4
  constraints necessary; arithmetic chain).  Repeats among G5..G7 / G1..G4 harmless (bad tuple of <=7 edges).
  Real-valued lam>=1 also fine.
  ISSUES found so far (agree with w7 LINE-BY-LINE entry 1, re-derived independently):
  (I1) convention: needs 'every subfamily of AT MOST 7 edges' (note's convention, cf. 7.105 statement).  Literal
       'every 7 distinct edges': six pairwise disjoint singletons have |E&F|=0<=1=lam, (7,2) vacuous, tau=6>3.
  (I2) corollary 'two edges share >= ceil(tau/3)' false for tau in {1,2} (H={{1},{2}}, or |H|=1); true for tau>=3.
  (I3) SIGNIFICANCE/NOVELTY: note 7.105 (rank<=4b, any three distinct edges pairwise <=b => tau<=3b) applied with
       b=max(lam, ceil(k/4)) gives, for every rank-k family, tau <= 3max(lam, ceil(k/4)).  Hence Theorem L is new
       ONLY when lam < ceil(k/4) (rank > 4lam) and then yields tau <= 3lam < 3ceil(k/4): it says nothing new about
       a rank-k counterexample H itself in the regime tau > 3ceil(k/4) (there 7.105 even gives alpha(Gamma_b)<=2,
       so chi(Gamma_lam) >= |H|/2 >= tau/2, stronger than the chromatic corollary tau/(3lam)).  Its genuine use is
       for LIGHT SUBFAMILIES (lam = eps*t << k/4), as in the attacker's L+/L++.
  Scripts running: w9_ref_core2_e2e.py (exhaustive adversarial e2e: PG(2,3) 57276 tuples, PG(2,5), K_6^2, K_8^2 pass
  so far), w9_ref_core2_sat.py (monotone-strengthened CEGAR; far faster than w7's: n=7 lam=1 T=3 UNSAT in 2507 cuts/5s).
## [nonint#4] FINAL VERDICT: CONFIRMED_WITH_FIXES (referee w9, 24 Sep)
Hand re-derivation. (i) Staircase: if g1<=a d1, g2<=b d2 (a,b>=1, a+b=6), choose a distinct K1-rows (distinct
d1-holes covering G n U1; C(k+d1,d1)>=a when d1>=1; for d1=0 repeat the one row -- allowed by the note's 'at most
seven, repetition allowed' convention, line 2409) and b K2-rows likewise. U1 n U2 empty => no point hits a K1-row and a
K2-row, so a piercing pair is p in U1\cup holes1, q in U2\cup holes2, both outside G. Bad. CORRECT.
(ii) K1 u K2 (7,2) iff 5 max(d1,d2) < k: one-cluster 7-tuples have a common point (6d<k+d); mixed (a,b>=1,a+b=7)
bad iff a holes cover U1 (a d1 >= k+d1) or b holes cover U2, max a=6 -> 5d1>=k. CORRECT (statement's 'delta' must
be read as max(d1,d2), or d1=d2).
(iii) Max fatness 5d=k-1: a=max(1,ceil(g1/d)) works for 0<g1<=5d and g1=0<g2<=5d (then g2 <= k-g1 <= (6-a)d using
g1>=(a-1)d+1). GAP in the written proof: boundary g1=k (a=6, b=0 not allowed) and g1=0,g2=k need 'G in K1 resp. K2,
hence not other' -- the only place 'other' is used, not said; also d=0 (k=1) divides by zero (trivial: G must meet
U1 u U2, so G=U1 or U2). tau(K1 u K2)=d1+d2+2 (a transversal needs d_i+1 points in U_i). CORRECT after fix.
SHARPENING (FULL_PROOF, referee): if 5d_i<k and G nonempty, K1 u K2 u {G} is (7,2) IFF the staircase holds for G
(b=0 tuples: common point of <=6 K1-rows + a point of G; a,b>=1: uncovered points exist since (a-1)d1<=4d1<k).
CHECKS [C] w9_ref_nonint4_check.py (log .log; pysat CaDiCaL, all rows explicit, witnesses brute-force re-checked):
 (A) 106 (k,d1,d2) cases k<=11: (7,2) iff 5max(d)<k, 0 mismatches. (B) 13 settings k<=12, w=2 outside points,
 all 1713 G-types: staircase-violated <=> exact bad, 0 mismatches. (C) k=1,6,11,16,21 (d=0..4): all 1705
 other-edge types killed by the proof's explicit tuple (brute-force pair check). (D) tau=d1+d2+2 on 7 cases.
 Sensitivity w9_ref_nonint4_mut.py: a+b=5 / strict '<' / a+b=7 variants give 21-47 mismatches (k=10,12).
NOVELTY: elementary, not in the note (grep bi-clique/staircase/two complete clusters: none); nearest note item is
 the six-wise intersection-chain bound q<=floor((k+4)/5) (note ~l.9284) and Lemma 7.87(3) -- same 'edge disjoint
 from a complete cluster' trick with one cluster. SIGNIFICANCE small: max-fat case has tau=(2k+8)/5, far from 3k/4;
 no consequence for the fat-core problem below maximal fatness (attacker's own Prop C has tau~0.70k at d=0.05k).
* [core#5] entry 1 (checkpoint). w9_ref_core5_check.py (B,C,D,E) results: no-Fano CONFIRMED (hand proof + LP==Lemma 7.63
  + threshold F(s)=3(1-s)/2 exactly for s<=2/5); GT*, D4, nu, tau*>3/4 hold on 2301 grid pts of the open triangle
  {9/8<x<9/7, 11/8-x<s<1-2x/3}; explicit integer tetrahedral 4a+3b tuples (k=20,40,50,100) have 0 two-transversals.
  E: 30 of the note's 42 minimal two-type functions kill W (none Fano), e.g. fn#40 = D(s,t)=6s/5+t (note 7.73
  six-versus-one DISJOINT construction). => tetrahedral is NOT the only / simplest killer.
  NEW OBSERVATION: 'link rule' L_m: m edges with no common point + 1 edge disjoint from their union is bad (m<=6).
  In W: m a-edges (each pt in <=m-1) + disjoint b-edge fits iff s >= (m-(m-1)x)... i.e. m >= (x-s)/(x-1).
  m=6 kills iff s>=6-5x; m=5 (a bad SIX-tuple) kills near x->9/7. Adding L6 to the attacker's rules drops the W-family
  sup from 6/7 to 10/13 (x=15/13, s=3/13). Checking explicitly next (check_F).
## [core#3] entry 2 (checkpoint ~09:10)
* Attacker certs re-run: w6_core_thmLplus_cert.py PASS (813 inst., 62646 tuples; count differs from claimed 622/48510
  -- script's default trial count differs from the one quoted, harmless); w6_core_thmLpp_cert.py PASS (1544/46062 as claimed).
* Parts B/C (actual (7,2) families: greedy maximal random, K6^4, K8^5, K9^5, x+K8^7 and random subfamilies):
  L+ and L++ hold everywhere, but t<=5 so only lam<=1 is exercised (hypothesis 3lam<=t-1) -- weak evidence, as expected;
  the statement-level part A is the meaningful test.  NOTE: FKW parity family with m=1 (k=4,n=8) is NOT (7,2)
  (explicit bad 7-tuple found; note l.75: parity family is (7,2) only for m>=3), so no small family lives in the
  counterexample regime.
* eps-line counterexample search (w9_ref_core3_epscegar.py, SAT + lazy (7,2) cuts, t=3,d=1,B empty, n=7,8, sizes 1..4):
  did not terminate (>650k single-tuple cuts in 10 min); stopped. INCONCLUSIVE -> eps-line without side condition
  is UNPROVED (neither proved nor refuted).
* DOMINATION REMARK (hand, from note 7.105, hand-proved in the note): rank<=k, b=ceil(k/4), 3b<=t-1 (i.e. exactly the
  counterexample regime t>=3ceil(k/4)+1).  For lam>=b: G1 (size>lam), G2 avoiding T(G1), G3 avoiding T(G1)uT(G2) are
  pairwise lam-light, rank<=4lam, so 7.105 gives tau<=3lam<t unless 2delta>=t.  For lam<b: N_lam[E] contains
  N_b[E], so delta(lam)>=delta(b)>=ceil(t/2).  Hence in the counterexample regime delta(lam)>=ceil(t/2) for EVERY lam
  with 3max(lam,b)<=t-1, strictly stronger than L+'s min(ceil(t/3), t-2lam) (<= ceil(t/3) < t/2).
  L++ analogue: G1 notin B, G2 avoids T(G1)uS, G3 avoids T(G1)uT(G2)  =>  beta >= t-delta whenever 2delta<=t-1
  (B_lam contains B_b, so also for lam<b), vs L++'s beta >= t-2max(lam,delta).  So for rank-k families in the
  counterexample regime L+/L++ are DOMINATED by 7.105; their only independent content is rank-freeness / the regime
  t <= 3k/4 (where 7.105's hypothesis rank<=4b with 3b<t fails).
* [core#5] entry 2 -- FINAL REPORT. VERDICT: CONFIRMED_WITH_FIXES (the maths is correct; the significance is overstated).
  Script: w9_ref_core5_check.py (log w9_ref_core5_check.log, 91 s, all PASS). Sections B (Fano), C (local rules on
  the region), D (explicit tetrahedral tuples), E (the note's 42 functions), F (link rule).
  CORRECT: tau* = 2x-2+2s (checked against note Thm 7.71 formula); GT* strict, no D4 7-multiset, nu<=2, tau*>3/4 on
  the whole open triangle R={9/8<x<9/7, 11/8-x<s<1-2x/3} (2301 exact grid points); no Fano tuple; not (7,2) (explicit
  integer 4a+3b tetrahedral tuples, k=20,40,50,100, brute force finds 0 two-transversals).
  FIXES: (1) no-Fano has a 3-line HAND proof valid for EVERY s<1-2x/3 (no 'close to' needed): three concurrent lines
  of a Fano tuple put every vertex in <=2 of their edges, so the per-part sum is <=2x. But 3 a-edges need 3(1-s)>2x in Q
  and 3 b-edges need the same in P, and the dual Fano plane is not 2-colourable. So FULL_PROOF, not CERTIFICATE. The
  threshold is exact: F(s)=3(1-s)/2 for s<=2/5. (Attacker's w6_core_twotype_nofano.py falls back to a float test
  when the rationalised dual is <= x, so '128 exact duals' is not guaranteed.) (2) The tetrahedral support works iff
  s>=(8-6x)/5, which is a STRICTLY larger set than tau*>3/4 (s>11/8-x): 'exactly where' is wrong. (3) sup 6/7 is not
  attained; x>=9/7 with s<4-3x gives tau*<6-4x<=6/7 (checked).
  SIGNIFICANCE CORRECTIONS: (a) W(7/5,0) IS note Prop 7.55 (4/5), with the same monochromatic-line proof. W is its
  one-parameter deformation that escapes D4. (b) W is a two-fixed-type family, already killed by note Thm 7.71.
  (c) 'All local rules hold' is FALSE once the note's OWN six-wise-intersecting link rule is included (note sec 7.87
  proof, line ~2461: the edges disjoint from any edge E are 6-wise intersecting). At all four certified sample points W
  is not even (6,2): 5 a-edges with no common point plus 1 b-edge disjoint from their union (explicit integer
  tuples at k=20,40,100 with 0 two-transversals). L_m fits iff m >= (x-s)/(x-1). (d) Adding L6 to the attacker's rules
  cuts the W-family barrier from 6/7 to 10/13 ~ 0.769 (sup at x=15/13, s=3/13; grid max 553/720). (e) 30 of the note's
  42 minimal two-type functions kill W, none of them Fano. The 10 Fano-support functions all fail, which independently
  confirms no-Fano. So the diagnosis 'missing = tetrahedral two-cloud with a shared core' is misleading: the simplest
  missing rule is L6, which is the note's 6-vs-1 construction D(s,t)=6s/5+t. (f) 'oracle Lemma T fails' is NUMERICAL
  (see [core#7]). draft_sec9's 'Lemma T holds' applies only to that oracle form, since the static tetrahedral support
  kills W. (g) The barrier covers only tools whose proofs exhibit a bad tuple of the listed kinds in H itself.
  INSIGHT: an H has no Fano tuple whenever its edges 2-colour into two 3-wise intersecting classes (Fano is not
  2-colourable in the good-triple 3-graph). W is exactly this with class = type.
* [nonint#3 ckpt 1] w9_ref_nonint3_logic.py: exhaustive membership-vector check of {A,G1..G6} (82 vectors, all
  realisations of free bits, outside points in/out of A): 0 pierced pairs; 4 label mutations all pierced -> logic OK.
  w9_ref_nonint3_arith.py (exact ints, n<=160, d<40, all x1+x2<=n): Lemma H 0 violations (sharp constant 26 < 38);
  hypothesis |U|>=d1+d2 genuinely needed (fails e.g. n=0,d=39); Prop B 0 violations, sharp constant 14 (<=25 claimed;
  notes say 24; both valid). Prop B's missing hypothesis |U|>=d1+d2 is AUTOMATIC: 6 K1-rows + 1 K2-row is bad
  when 5 d_i >= k, so (7,2) forces 5 d_i < k, d1+d2 < 2k/5 < k+s.  Cor H2 (35/48) and N' (9k/5-8) arithmetic OK.
  w9_ref_nonint3_tight.py: with Prop C's conditions, tightness 7s = 5k-2d-7 holds up to d/k ~ 0.070 (analytic root of
  19-284x+236x^2 = 0.0711, cross condition a=b=1), so the claimed range [0,0.058k] is conservative; exact family
  k=140n: Lemma H bound - tau(H[U]) = 33/12 exactly. Tightness depends on Prop C (nonint#2, separate claim).
  NOVELTY so far: note 7.97 ("Why this full-core construction stops at 5/7") has the same tuple, anchors already
  protruding, and the 5/7 ceiling for complete core + 2 thin anchors (continuous model). CONTEXT Lemma A_E is the
  same labelling with anchor inside U. New: arbitrary host (tau(H[U]) replaces complete core), fat clusters, integer consts.
* [nonint#3 ckpt 2 -- FINAL] VERDICT: CONFIRMED_WITH_FIXES (Lemma H, Prop B, Cor H2, N' special case are FULL_PROOF;
  tightness is conditional on Prop C = nonint#2).
  More scripts: w9_ref_nonint3_e2e.py (fat protruding cluster anchors, random non-contiguous balanced classes, ALL row
  combinations when <=3000: 654 instances, 1.18M tuples, 0 non-bad); w9_ref_nonint3_propC_sat.py (+ _small.log;
  plain pysat/CaDiCaL encoding, no symmetry breaking, bad tuples re-verified by brute force): (7,4,5,0) and (9,4,6,1)
  (7,2) [UNSAT all 36 compositions mod mirror]; (7,3,5,1) bad (j,a,b)=(2,4,1); (12,6,9,2) bad (1,3,3) -- both fail
  Prop C's conditions, consistent.  7.98 m=1 family (|V|=11, tau=5 exact) makes the N' special case tight at d=0:
  tau = (5|V|+5)/12 (7.98 family is (7,2) with two disjoint anchors C1,C2 inside V).
  FIXES: (1) Prop B: add 'automatically |U|>=d1+d2 since (7,2) forces 5d_i<k (6 K_i-rows + 1 K_j-row)'.
  (2) 'more generally' is imprecise: the plain case allows anchors of any size; state with anchor families F_i
  (single edge, d_i=0, or C(U_i,k)); only U1 n U2 = empty (resp. A1 n A2 n U = empty) is used.  (3) Dependency: not
  literally Lemma A_E (which needs E inside U) -- the anchor-protruding version is note 7.97's own argument; the
  proof is self-contained anyway.  (4) Tightness range: with Prop C's conditions 7s=5k-2d-O(1) holds up to d~0.071k
  (not only 0.058k).  (5) Constants 38/25 valid but loose (26/14 suffice, n<=160).  (6) Tightness of Lemma H is only
  along the ratio |U|/k~12/7 with d/|U|<=~0.041; for d=0 all |U| by rescaling (rank-free lemma).
  NOVELTY: the tuple, protruding anchors and the 5/7 ceiling (Prop B at d=0, continuous) are note 7.97; host
  generalisation = replace 'core rows' by 'rows of H[U] avoiding the blocks' (only property used); fat clusters and
  exact integer constants new. Modest, as the attacker says. No progress on 3/4 by itself.
## [nonint#2] entry 2 -- REPORT. VERDICT: CONFIRMED_WITH_FIXES
* (7,2) part: hand proof re-derived line by line and correct UNDER c>=delta+1 (=> c>5delta => 5delta<k). Literal
  statement (conditions (0)-(2) only) is FALSE for c<=delta: (13,0,0,1), (25,1,0,2) etc. have nu=3. Fix: add c>=delta+1
  (or c>5delta) to the (7,2) hypotheses; also state implicit 2c<=k+s, c<=k.
* Case-level test w9_ref_nonint2_cases.py (k=3..8, ALL s,c,d incl. degenerate, every pattern (j,a,b), exact SAT per
  pattern): 13220 pattern decisions, 8332 bad, 0 violations of the per-case implications of the proof.
* Whole-family SAT (w9_ref_nonint2_sat.py / _sweep.py): all 43 corrected instances k<=13 HOLD; also (14,8,11,1),
  (15,9,12,1), (17,8,12,2), (18,8,13,2) HOLD. (16,10,13,1),(21,14,17,1) killed unfinished. The attacker's "(14,8,11,1)
  UNSAT" (listed as done though notes ckpt F say running) is independently CONFIRMED.
* Exact family k=140n: conditions verified for all n (Fractions); tau=s+1=98n exact (atom-level); Gamma=K1xK2 and
  h(A,K2)=delta+1 brute-forced on small instances (w9_ref_nonint2_tau.py; (6,3,4,1) shows c-delta>s is needed).
  MILP (HiGHS, NUMERICAL) finds no bad tuple at n=1,2; at k=140,delta=7 s=98 (c=119) is BAD (verified (6,1,0) tuple),
  so s=97 is optimal for this construction at k=140.
* Threshold "delta<=~0.058k" conservative: (5-2delta)/7 attained up to delta~0.0711k.
* Caveats: "fat core" is in the PEELING sense (every member has h>delta); a lower bound on the best ORIENTATION/hybrid
  cost (what Theorem A actually uses) is not proved (peeling-stuck does not imply every orientation is expensive).
  "essentially sharp at 3/4" OVERCLAIMS: the construction gives fat families only up to (5-2delta)/7 < 5k/7; Prop B
  caps this construction type there. Novelty: new vs note (grep fat/fatten/biclique: none); it is a direct
  fattening of note 7.97 (delta=0 recovers 7.97 exactly), same proof skeleton plus the branch-2 count in case 1.
## [core#2] entry 2 (checkpoint). Scripts done + REFEREE IMPROVEMENTS.
  e2e: w9_ref_core2_e2e.py seeds 1,2: PASS, 40 families each (PG(2,3),PG(2,5),K_6^2,K_8^2,K_9^3 + random mixed
  sizes, ~16/40 with rank>4lam), 5.26M + 5.17M exhaustive-adversarial 7-tuples, none <=2-pierceable.
  SAT (w9_ref_core2_sat.py, monotone-strengthened CEGAR, all edge sizes, at-most-7 convention; sanity SAT cases
  K_5^3 (lam2,T3), K_6^4 (lam3,T3), T=2 lam1 found and brute-force re-verified):
     UNSAT: lam=1 T=3 n=6,7,8 (n=8: 19032 cuts 81s; w7 left n=8 unfinished); lam=1 T=4 n<=8; lam=2 T=4 n<=8;
     lam=2 T=5 n=7; lam=2 T=7 n<=8; lam=3 T=4 n<=8 (8: 10983 cuts); lam=3 T=5 n=8.  n=9 lam=1 T=3 / lam=2 T=4,
     n=10 lam=1 T=3 still running.  => largest tau seen: lam=1:2, lam=2:3, lam=3:3 (n<=8). Constant 3 never near.
  (R1) THEOREM L- (referee, FULL_PROOF): same hypotheses => tau <= 3lam-1.  Proof: |H|<=6 => tau<=2.  Else any 7
     distinct edges have a 2-transversal {x,y}, so >=4 of them pass through one point x; use those as G1..G4.
     All six pairwise intersections contain x, so |I(mu)| <= 2lam-1; with t=3lam: G5 avoids I5 (2lam-1), G6 avoids
     I6+{g} (2lam), G7 avoids I7+(G5&G6) (3lam-1 = t-1).  Lemma Q logic.  Certificate w9_ref_core2_star.py (running).
     lam=1 => tau<=2, SHARP (triangle; also 2 disjoint edges fail lam... triangle has lam=1,tau=2).  So the claim's
     'sharpness open' is settled at lam=1: constant 3 is NOT attained there; general sharp constant still open.
  (R2) CASE A (referee, FULL_PROOF, w9_ref_core2_logic.py check 4): if some 4 distinct edges have no point in >=3 of
     them, then C567 is unnecessary and budget 2lam suffices: tau <= 2lam.  (Dangerous {5,6,7}-points are exactly
     those in <=1 of G1..G4 whose complement-triple has a common point; check 5.)  So a family with tau > 2lam
     has EVERY 4 edges with a point in 3 of them ('case B'); case B not closed.
## [core#3] entry 3 -- FINAL REPORT (referee w9). Verdict: CONFIRMED_WITH_FIXES.
1. L+ : FULL_PROOF (hand re-derived; rank-free; corollary of L++ with delta=max, B=empty).  Needs the "every AT MOST
   seven edges" convention (repeats occur); literal distinct-7 reading false for |H|<=6 (six disjoint singletons).
2. L++: FULL_PROOF (hand re-derived; every budget checked: d+b, 2d+b, 3d, 2lam+b, 2lam+d, 3lam; G4 may lie in B).
   Type logic independently re-certified (w9_ref_core3_logic.py, all 6 bijections, each constraint necessary).
   Statement-level test w9_ref_core3_e2eA.py: 16000 random families, 10925 L++ / 5603 L+ hypothesis hits, all
   non-(7,2) by independent SAT.  Complete families K_6^4, K_8^5, K_9^5 (w9_ref_core3_K95.py): tau(N_lam[E]) =
   t (lam<2k-n) else min(k-lam,t); B=H whenever delta<min(k-lam,t) -> 'satisfied trivially' confirmed.
3. FIX: the "in particular" line needs the side condition 3floor(eps t) <= t-1 (eps<1/3 suffices); correct form:
   if d=floor(eps t) and 3d<=t-1 then tau(B_{d,d}) >= t-2d >= (1-2eps)t.  Without it (1/3<=eps<1/2) UNPROVED;
   counterexample search inconclusive.
4. SCOPE/NOVELTY: not in the note as stated.  But for rank-k families with 3ceil(k/4)<=t-1 (the whole counterexample
   regime) note 7.105 + the same lazy greedy + monotonicity of N_lam in lam give delta(lam)>=ceil(t/2) and
   beta>=t-delta (2delta<=t-1), which strictly dominate L+ (delta>=min(ceil(t/3),t-2lam)) and L++ (beta>=t-2max).
   So L+/L++ add nothing for a hypothetical counterexample beyond what 7.105 already yields; their independent value is
   rank-freeness (and the attacker's lazy T-set greedy, which is the reusable idea).  Significance should be downgraded.
## [core#2] entry 3 (checkpoint). w9_ref_core2_star.py (seed 1, log w9_ref_core2_star_s1.log) so far PASS:
  PG(2,3) 67392, PG(2,5) 233280, K_5^2 3300, K_8^3 (TIGHT tau=3lam=6, avoided sets of size exactly 3lam-1) 29636
  tuples; K_9^3, K_12^4, 80 random mixed-size families pending.  SAT n=9 lam=1 T=3 (>120k cuts), n=9 lam=2 T=4,
  n=10 lam=1 T=3 unfinished (moot for lam=1 now: R1 proves tau<=2 for all linear (7,2) families).
## [core#2] FINAL REPORT (referee w9). Verdict: CONFIRMED_WITH_FIXES (statement + proof correct under the at-most-7
  convention; fixes are convention/corollary/significance; referee strengthens the constant to 3lam-1).
  * w9_ref_core2_star.py seed 0 COMPLETE (log w9_ref_core2_star_s0.log): PASS on PG(2,3), PG(2,5), K_5^2, K_8^3,
    K_9^3, K_12^4 (K_8^3 and K_12^4 TIGHT tau=3lam) and 80 random mixed-size families (6 with tau=3lam exactly);
    ~1.35M exhaustive-adversarial tuples.  => R1 (tau <= 3lam-1) = FULL_PROOF + CERTIFICATE.
  * Remaining SAT runs (n=9 lam=1 T=3, n=9 lam=2 T=4, n=10 lam=1 T=3) killed unfinished; lam=1 cases are moot by R1.
  Summary of issues: (I1) at-most-7 convention required (6 disjoint singletons); (I2) 'share >= ceil(tau/3)' needs
  tau>=3 (and becomes ceil((tau+1)/3) by R1); (I3) for a rank-k family, 7.105 with b=max(lam,ceil(k/4)) already
  gives tau<=3max(lam,ceil(k/4)); Theorem L is new only for lam<ceil(k/4), i.e. for light SUBFAMILIES, never for
  the counterexample itself in the regime tau>3ceil(k/4); (I4) sharpness 'open' -> settled at lam=1 (tau<=2,
  triangle), constant 3 not attained; R2: tau<=2lam unless every 4 edges have a point in 3 of them.
  * addendum: SAT n=9 lam=1 T=3 UNSAT (124070 cuts, 1977s) finished before kill; star seed 1 (w9_ref_core2_star_s1.log) random part also PASS (80 families, 9 with tau=3lam, 1004450 tuples).
## [templates#1] entry 0 -- START (referee w9, 24 Sep). Claim: Theorem 2UB (two up-boxes, any number of parts). Lens: line-by-line logic.

## [templates#2] entry 0 -- START (referee w9, 24 Sep). Claim: Theorem H2 (<=2 heavy parts, arbitrary closed
## type set, any number of light parts). Lens: line-by-line logic. Reading templates_handproofs.md sec 0,5,
## tmpl/verify_h2.py, note 7.63/7.75 definitions of tau*.
## [templates#1] entry 1 -- hand re-derivation (checkpoint)
Line-by-line pass of templates_handproofs.md sec.4 DONE: every inequality re-derived by hand. tau* formula
re-derived from note Lemma 7.56 (up-box = sliced box with h=x; sum-blockers all cost N-1; {i},{i} pair gives
max(x_i-g_i,x_i-h_i)=x_i-min). Q_b = note Lemma 7.57 M_{4,3}; V = note's V (args swapped); Lemma V (i),(ii)
checked by hand. All steps correct. Observations: (a) Lemma 0 at I and J is redundant (K!=I and L!=J already
force K=L outside {I,J}); (b) the 'g_I=1' parenthesis is unnecessary; (c) case i=K covers K=J (a_K<=1-a_L
still holds). No gap found so far. Next: independent exact end-to-end script w9_ref_templates1_e2e.py.

## [templates#1] entry 1 (referee w9, 24 Sep ~09:50). Claim: Theorem 2UB (two up-boxes, any #parts).
  Read templates_handproofs.md sec.0 + sec.4, notes_templates.md sec.8, tmpl/verify_twoupbox.py, note 7.58-7.62,
  7.63(Lemma 7.63 = Fano capacity), 7.57 (M_{4,3} = Q_b), 7.73/7.75 (Thm 7.73), 7.11.
  Hand re-derivation (line by line): tau* formula = note Lemma 7.56 with h=x (sum-blockers all collapse to N-1);
  I!=J; F1; F2; admissibility (a_J<=1-g_I<7(1-g_I)/4<x_J); Q_b facet at I,J and i notin{I,J}; K!=I, L!=J, K!=L;
  g_L+h_K>3/2; V at a_i=0 / i=K / i notin{K,J} / i=J!=K (L=I and L!=I subcases). ALL STEPS CHECK. Remarks:
  Lemma 0 at I,J is redundant (K!=I, L!=J already exclude K=L in {I,J}); in the i=J, L!=I subcase the bound
  3g_L/4+5g_I/4+h_J/2-1/2 > 3/8+3g_I/4 uses h_J>1-g_I (F1): correct.
  Novelty: p=3 is a special case of note Thm 7.73 [C] (sliced boxes with upper bounds h=x; note needs tau*>3/4
  strict); p>=4 not in the note (Prop 7.66 is only a decision procedure; 7.11 fine-subdivision family is NOT an
  up-box union). Next: independent exact e2e script w9_ref_templates_2ub.py (Lemma 7.56 tau*, explicit cell
  masses, brute-force Venn check) + exhaustive grids + adversarial slack minimisation.
## [templates#0] entry 1 (checkpoint, reading). Claim: hand proofs TT, Gap-Pair, 7.75', one-sided |I|<=2
  (templates_handproofs.md secs 0-3). Hand re-derivation of TT (Lemma 0, steps 1-4), Gap-Pair (P1,P2, Q_b/Q_a
  facets, R1,R2, V facets), 7.75' and sec.3 done line by line: no algebra error found so far.
  Q_b = note's M_{4,3} (Lemma 7.57); V = note 7.73's V with args swapped; H = homogeneous. Constructions not new.
  Potential gaps to check: (a) 7.75' proof never says H nonempty (needs N>=7/4 from tau*<=N-1); with H empty the
  "below/above H" split and attainment of b fail. (b) sec.3 "fully human" relies on handback 8.4 (|I|>=3) whose
  hand vertex argument is in the handback (not the draft, which is [C]).
  Scripts planned: w9_ref_templates0_{vsupport,gappair_fm,tt_milp,tt_exact,closed2,onesided}.py

---
## templates#0 (lens LINE-BY-LINE LOGIC) -- checkpoint 1 (reading + hand re-derivation)
Claim: templates_handproofs.md sections 0-3 (Lemma V, Theorem TT, Gap-Pair, Theorem 7.75', one-sided |I|<=2).
Hand re-derivation done line by line:
* Lemma V (ten cells): (i) no covering pair OK (b0-cell/b1-cell W-edges from different perfect matchings of K4
  share a vertex); (ii) masses (1,0):5/4, (0,1):1, (2,1):3 OK; combination = V(s,t)=max(s+t,5s/4+t/2) OK.
* Q_b from Lemma 7.63: max(s,t,3t/2,s+t/2,s+3t/4) = max(3t/2,s+3t/4) OK.
* TT steps Lemma 0, (1)-(4): all correct. Only cosmetic: final bound "> 1/8" is actually "> 3/8".
* Gap-Pair: P1,P2,R1,R2 and all four V facets re-derived; correct.
* 7.75': correct, but ONE MISSING LINE: must note tau* <= N-1 so N >= 7/4 and H is nonempty; otherwise
  "below H" and "above H" overlap (a type in (4x/7,1-4y/7) is both) and a<=b is not guaranteed.
* One-sided |I|<=2: correct (tau*=min(sum d, X-1) formula, admissibility claim, Gap-Pair mapping with
  a'=1-theta_B, b'=theta_A; zero loads on other parts trivial). Relies on 8.4 (|I|>=3) for "fully human".
Next: independent exact scripts w9_ref_templates0_*.py.
## [templates#1] entry 2 -- scripts (checkpoint)
w9_ref_templates1_e2e.py: independent EXACT check (tau* via note Lemma 7.56 all-subset blockers; H/Q/V verified
by explicit cell masses + exact loads/capacities + brute Venn pair check; p=2..7; ~1/3 instances pushed to
tau*=3/4 exactly). Smoke runs 4x300 PASS (Qb/Qa/V all used; V ~8%). Sanity: tau* in [0.70,3/4): canonical
pair fails 25/196 (non-vacuous); mutation (fill own heavy part instead of e_J/e_I): 29/98 fail -> the
canonical choice matters. Background: seeds 11-14 x 20000 (w9_ref_templates1_e2e_s*.log); adversarial
climb w9_ref_templates1_climb.py (log _climb_s1.log). Novelty: note has no up-box / two-convex-component
result beyond 3 parts (note l.19 lists 'two arbitrary convex components over >2 parts' as open) -> NEW
(special case of that open item; p=3 subsumed by note Thm 7.73 [C] for tau*>3/4, hand proof new).
## [templates#1] entry 2 (~10:10). Scripts (all exact):
  w9_ref_templates_2ub.py (e2e: Lemma-7.56 tau*, canonical a,b membership from the definition, EXPLICIT per-part
    rational cell masses for H/Qb/Qa (Fano line complements) and V (ten-cell support), brute-force row loads,
    capacities, pairwise non-covering of all used cells) -> seeds 11-13 x 4000 running (w9ref_logs/).
  w9_ref_templates_2ub_grid.py (EXHAUSTIVE integer grids, every heavy pair, equality tau*=3/4 included):
    PASS p2 D28 (465216 pairs, V 5842), p4 D6 (50558), p4 D7 (168924, V 272), p5 D4 (52624), p6 D3 (4950);
    p2 D84, p3 D12, p3 D14 running.  Min template slack 0 occurs (tight, allowed).
    OBSERVATION: every V-case seen has K=J and L=I; the proof's K!=J / L!=I subcases look VACUOUS (checking).
  w9_ref_templates_2ub_tau.py: 2UB tau* formula == note Lemma 7.56 == brute residual search, 1725/1133 inst, 0 mismatch.
  w9_ref_templates_2ub_mut.py (mutations: thr 0.70, fill own part, drop V/Qa/Qb) running.

## templates#0 -- checkpoint 2 (scripts) and VERDICT: CONFIRMED_WITH_FIXES
Scripts (mine, exact Fractions unless noted):
* w9_ref_templates0_support.py: V support 10 cells, no covering pair (incl. equal pairs); explicit masses give
  loads (s,t) with mass exactly V(s,t) on a 25x25 grid; float LP says V is also the min over this support;
  Q_b and H agree with Lemma 7.63; Q_b achieved exactly by u=max(0,s-3t/4) on comp(L) + 3t/2 on the other six. PASS.
* w9_ref_templates0_gap.py: Gap-Pair by own exact Fourier-Motzkin: all 64 (Q_b facet x Q_a facet x V facet)
  violation systems force margin <= 0. ALSO with (H1),(H2) weak (sharpening: strictness not needed).
  Mutation test w9_ref_templates0_gap_mut.py: dropping V/Q_a/Q_b leaves 1/2/3 of 16 systems open; dropping H1/H2
  leaves 12/64 open, dropping G all 64 -> check is non-vacuous and every ingredient is used.
  7.75' end-to-end (independent residual-enumeration tau*): 12.8k instances with tau*>=3/4 (783 at equality),
  hom 9892 / Qb 1219 / Qa 419 / V 37, 0 failures.
* w9_ref_templates0_tt.py (seeds 1-3, logs w9_ref_templates0_tt_s*.log): tau* by brute-force residuals (matches
  the formula every time), instances pushed exactly onto tau*=3/4 (12.7k of 12.9k tested are equality cases);
  TT holds in all; proof internals (both Q facets everywhere once H fails; K!=L, a_L+b_K>3/2; V) asserted. PASS.
* w9_ref_templates0_onesided.py: |I|=2 one-sided boxes, p=2..4, 60k tested (13k at equality): admissibility claim
  1-theta_B<=x_A, Gap-Pair hypotheses and the template all hold. (tau* here via the free-residual formula.)
Fixes required:
 (F1) Thm 7.75' proof: add "tau* <= N-1 gives N >= 7/4, so H is nonempty; hence a < 1-4y/7 <= 4x/7 < b".
      Without it, "below H" and "above H" can overlap (e.g. x=y=3/4, C={1/2}) and a<=b is not guaranteed.
 (F2) TT step (4): the last slack is > 3/8, not "> 1/8" (harmless understatement).
 (F3) "one-sided box theorem is fully human" is conditional on 8.4 (|I|>=3), which was refereed separately
      (two referees CONFIRMED_WITH_FIXES); say so. Dependencies to cite besides Lemma 7.63: the two-type tau*
      formula (note 7.73, hand) and the endpoint/gap bounds (note 7.76, hand).
 Optional: Gap-Pair holds with (H1),(H2) weak (FM-certified); TT and 7.75' allow tau* = 3/4 (confirmed).
Novelty: note proves 7.10 (87 duals), 7.71 (125+101 duals), 7.75 (640 duals) by certificate; note has hand
Lemma 7.53 (intersecting two intervals, one-vs-six) and first half of Lemma 7.74 only. TT, Gap-Pair, 7.75'
hand proofs and the explicit 10-cell V support are new relative to the note.

## [templates#2] entry 1 -- checkpoint. HAND RE-DERIVATION of H2 (templates_handproofs.md sec 5): every line CORRECT.
Checked: (0) no-heavy type -> H needs only t<=4x/7 (N>=7/4 not even needed). C_2 empty: then C_1=C closed, min
attained, t_1>4x_1/7 strict -> tau*<=d_1<3/4 (text says "min_{C_1}"; attainment follows since C_1=C there).
(1) valid with theta_i=inf (types in C_i have t_i>=theta_i). Attainment: inf=4x_1/7 -> limit t0 in C, t0 light on
Lambda (hyp.), t0 not heavy at 2 since x1+x2>=7/4 from (1) with d_i<=3x_i/7 -> H. F1 and no double-heavy OK.
Case A: d_2<3x_2/7<3theta_2/4 -> d_1>3(1-theta_2)/4>=3b0_1/4; 3b0_1/2<=6x_1/7; part 2 identity
 (1-th1)+3th2/4 = th2+3(1-th1)/4 - (th1+th2-1)/4 OK; light parts OK.  Case B symmetric OK.
Case C: residual correct (C_1 dies at 1; C_2\S dies at some l since u_l<x_l-lambda_l<=b_l; S dies at 2 with
 u_2 = inf_S b_2 - eps); cost d_1+Lam0+rho*+O(eps). S empty -> d_1+Lam0<=d_1+1-th1<1-th1/2<3/4 OK.
 b* in closure(S) subset C, b*_2>=theta_2 so b* in C_2, b*_l<=x_l-lambda_l.  Claim's closed S' version also works
 (max over S' >= sup over S).  All V margins re-derived: part1 > th2/2-1/4 and >(1-th1)/4; part2 > th1/2-1/4 and
 > -1/2+3th1/4+th2/2+Lam0/4 > 1/4; light: survivor + 7/4*4x/7. Strictness sources fine under tau*>=3/4 (equality).
Templates independently recomputed from supports (w9_ref_templates2_supports.py, dual-vertex enumeration, exact):
 H=7s/4, Q_b=max(3t/2,s+3t/4), V=max(s+t,5s/4+t/2) EXACT (and minimal); V support has no covering pair. PASS.
ISSUE (significance): "one-sided |I|<=2 is a special case" is literally false: one-sided box families can contain
 types heavy at a light part (e.g. x_A=x_B=13/10, th=4/5, x_L=1/5, type (4/5,0,1/5) has a_L=x_L>4x_L/7).
 FIX: restrict to C'=C cap {light on Lambda} (closed); tau*(C')>=min(d_A+d_B, x_A+x_B+4x_Lam/7-1)>=3/4 (hand, below),
 then H2 applies.  (Gap-Pair sec 3 proves the case anyway.)
## [templates#0] entry 2 (checkpoint, scripts; my files are w9_ref_templates0_{vsupport,fm,gappair_fm,tt_exact,
  tt_milp,closed2,onesided}.py -- the other templates0 files (tt.py, gap.py, gap_mut.py, support.py) belong to a
  parallel referee on the same key).
  * vsupport: V ten-cell support has no covering pair; masses (1,0):5/4,(0,1):1,(2,1):3 exact; combination mass
    == V(s,t) on 625 grid pts (and LP min mass == V exactly, so V is optimal for that support); Q_b == Lemma 7.63
    mass == note's M_{4,3} (Lemma 7.57); explicit Q_b realisation OK.  PASS.
  * gappair_fm: COMPLETE exact FM certificate (strict ineqs, Fractions): all 64 failure systems infeasible.
    Sensitivity: dropping H1/H2/G/a>=0/b<=1 makes systems feasible; dropping a<=b does NOT (a<=b unnecessary);
    G weakened by 1/1000 -> 59 feasible (G is sharp).  CERTIFICATE.
  * tt_exact (x ranges over ALL R^p exactly for each (a,b)): grid p=2 den24, p=3 den12 (8281 pairs), p=4 den6
    (7056), random sparse p=4 (3000), p=5 (1500): 0 counterexamples; tau* formula == brute residual enumeration.
    Non-vacuity: dropping any one of Ha,Hb,Qb,Qa,V yields counterexamples on the p<=3 grids.
  * closed2 (7.75', exact tau* by formula == brute; follows the written proof): 3x60000 random finite C,
    44.7k with tau*>=3/4 (429 with tau*=3/4 exactly): H 21952, Q_b 20751, Q_a 1952, V 60; 0 failures.
  * onesided (sec.3 |I|=2, light parts m<=2): 3x200000, ~400k with tau*>=3/4, ~4.1k non-homogeneous: claim
    1-th_B<=x_A holds, Gap-Pair hypotheses hold, template found every time; |I|=1 never has tau*>=3/4 w/o hom.
  * tt_milp (NUMERICAL, HiGHS; complete relaxation with p=5 retained parts, sums<=1): p=2,3 gamma*=0;
    sanity: drop V -> gamma*=1/8 at x=(11/8,11/8), a=e1, b=e2 (the handback's example); p=4,5 running.

## [templates#2] (BREAK-IT lens, second referee) entry 0 -- START 24 Sep. Claim: Theorem H2. Read sec.0/5/6 of
## templates_handproofs.md, tmpl/verify_h2.py, the line-by-line referee's w9_ref_templates2_* (finite random +
## climbs). Hand re-derivation of every inequality of sec.5: all correct (details in final entry). Plan: my scripts
## w9_ref_templates2brk_*.py: (a) EXPLICIT Venn-level realisation (cell masses, brute pairwise non-covering),
## (b) GRID type-closed families (all lattice types in unions of boxes -> massive ties/boundary values),
## (c) random tie-breaking of argmins/maximisers, (d) push tau* onto 3/4 exactly, (e) adversarial climbs,
## (f) mutation/necessity tests (3rd heavy part, tau*<3/4, b0 instead of b*), (g) scope of "one-sided |I|<=2".
## [templates#1] FINAL VERDICT: CONFIRMED (FULL_PROOF stands; editorial fixes only)
Hand: every line of templates_handproofs.md sec.4 re-derived; no gap, no dropped side condition, no quantifier
error. Case split for V is exhaustive (a_i=0 / i=K (incl. K=J) / i not in {K,J} (incl. i=I, i=L) / i=J!=K).
Scripts: w9_ref_templates1_e2e.py seeds 11-14 x 20000 = 80000 instances (p=2..7, ~36% at tau*=3/4 exactly,
25,531 heavy pairs; Qb/Qa/V all used, V 2268x) ALL CHECKS PASSED with explicit exact realisations + Venn check;
w9_ref_templates1_climb.py 30 adversarial climbs: sup min-violation = 0 (never positive) -> tight at tau*=3/4.
Controls: below 3/4 the canonical pair fails (25/196); wrong fill direction fails (29/98).
Editorial: (1) Lemma 0 at I,J redundant (K!=I, L!=J force K=L outside {I,J}); (2) g_I=1 parenthesis unneeded;
(3) attacker verify script never checks the H branch and silently skips instances with g_H = 4x_H/7 exactly
(it uses strict heaviness) -- harmless, my script covers H; (4) dependency is only the easy (sufficiency) half of
Lemma 7.63, in fact just note Lemma 7.57's explicit masses + Lemma V; (5) significance: continuous model only;
up-boxes = sliced boxes with upper bound x (no upper bounds), so it does NOT subsume note Thm 7.73 (general
sliced boxes, p=3); it is a special case of the note's open item 'two convex components over >2 parts'.
Novelty: NEW (no up-box/two-component result for p>=4 in the note).
## [templates#0] FINAL REPORT (referee w9, lens BREAK IT). Verdict: CONFIRMED_WITH_FIXES (all fixes cosmetic).
  * tt_milp p=4 gamma*=0, p=5 gamma*=6e-13 (complete 5-retained-part relaxation, NUMERICAL): no TT counterexample.
  * Every step of TT, Gap-Pair, 7.75', sec.3 re-derived by hand: no error. No counterexample found anywhere
    (exact x-complete TT tests p<=5, exact Gap-Pair FM certificate, 44.7k closed two-part sets, ~4.1k
    non-homogeneous one-sided |I|=2 instances; equality tau*=3/4 cases included).
  FIXES: (F1) 7.75' proof should say: tau*<=N-1 gives N>=7/4, so H=[1-4y/7,4x/7] is nonempty; only then are
    'below H'/'above H' well defined and a,b attained with b>4x/7 strict (with H empty, b=inf could equal 4x/7
    unattained).  (F2) Remark (c) mislabels: W(x,s) is the notes_core c7 family (tau* -> 6/7), not note s7.55;
    note Prop 7.55 (header s7.57) is the 4/5 instance x=y=7/5, types e1,e2.  V does kill W(x,s) whenever
    tau*>=3/4 (part Q needs s>=5/3-4x/3, implied by tau*>=3/4 <=> s>=11/8-x as x>=7/8).  (F3) Gap-Pair: a<=b is
    not needed (FM), G is sharp (weakening by 1/1000 breaks it).  (F4) sec.3 'fully human' is correct only with
    the HANDBACK's 8.4 (hand product-vertex argument), not draft_sec8's [C] FM version; the |I|=1 merging text
    is superfluous (case vacuous).  (F5) handback 8.4 sentence 'For |I|<=2 ... follows from note's
    computer-assisted Theorems 7.75 and 7.73' can now be replaced by sec.3 (tau*>=3/4 allowed).
  NOVELTY: constructions are the note's (H; Q_b = M_{4,3}, Lemma 7.57; V = 7.73's V with args swapped); the gap
    pair (a,b) and (H1),(H2),(G) are note Lemma 7.74's first half.  New: the short hand chains (TT for any p,
    incl. intersecting 7.10 and non-intersecting 7.71; Q_b,Q_a,V on the gap pair for 7.75), the explicit ten-cell
    V support, and equality tau*=3/4.  Cor 7.76 goes through with <=10 parent cells.
## [templates#1] FINAL REPORT (referee w9, ~10:35). Verdict: CONFIRMED (FULL_PROOF; minor presentation remarks only).
  * Hand: every step re-derived (see entry 1). No dropped side condition, rounding or quantifier error found; the
    statement holds for EVERY heavy choice (I,J), with tau* = 3/4 allowed.
  * CERTIFICATE-level checks (exact, independent of attacker code):
    - w9_ref_templates_2ub.py seeds 11,12,13 x 4000 instances (p=2..6; ~150 with tau*=3/4 exactly): explicit cell
      masses, loads, capacities, pairwise non-covering all verified; ALL CHECKS PASSED (w9ref_logs/*e2e*).
    - w9_ref_templates_2ub_grid.py EXHAUSTIVE: p2 D28 (465216 heavy pairs), p3 D12 (713008), p3 D14 (1509978),
      p4 D6 (50558), p4 D7 (168924), p5 D4 (52624), p6 D3 (4950): ALL PASS, min slack 0 attained (tight).
      (p2 D84 still running at report time; see its log.)
    - w9_ref_templates_2ub_tau.py: tau* formula == note Lemma 7.56 == brute residual search (0 mismatches).
    - w9_ref_templates_2ub_climb.py: 80 adversarial restarts, min best-template slack -> 0+, never negative,
      every endpoint re-checked exactly: PASS.
    - w9_ref_templates_2ub_mut.py (1500 inst): mutations DO fail -> checker is sensitive and every ingredient is
      needed: thr 0.70 (41 fails), filling at own heavy part (439), menu without V (31), without Qa (20), without Qb (147).
  * Presentation remarks (no effect on validity):
    (R1) Lemma 0 at I and J is redundant: K!=I and L!=J already exclude K=L in {I,J}.
    (R2) K!=J forces L=I (h_K>1/2 => h_J<1/2 => g_I>1/2, and g_L>1/2 => L=I).  So the subcase 'i=J!=K, L!=I' is
         VACUOUS; the subcase 'i=J!=K, L=I' is REAL: w9_ref_templates_2ub_KneJ.py, x=(143,69,86)/100,
         g=(96,0,0)/100, h=(0,40,58)/100, tau*=3/4, (I,J)=(0,1): Qb fails at K=2, Qa at L=0, V feasible.
         Exhaustive grids never hit it (the window is narrow: needs g_I>9/10), all grid V-cases have K=J, L=I.
    (R3) Lemma-0-at-J parenthetical (g_I=1) is convoluted: g_I=1 forces g_J=0=a_J, so 2x_J<3a_J is impossible.
  * NOVELTY: p=2 is inside note 7.75 (closed two-part sets); p=3 is a special case of note Thm 7.73 [C] (sliced
    boxes with h=x; note needs tau*>3/4 strictly).  p>=4 is NEW (note Prop 7.66 is only a decision procedure).
    Significance should say "two UP-boxes (lower-bound boxes, upper bound = capacity)": incomparable with 7.73
    (more parts, fewer box shapes); general two-convex-component case over >=3 parts stays open (note line 19).
## [templates#2] entry 2 -- checkpoint. TEST-COVERAGE GAP in the attacker's check: tmpl/verify_h2.py never reaches
the survivor step with b* != b0 (patched copy counting it: seed 3, 3000 instances, 295 V-case, b*!=b0 in 0) --
its generator puts too little light mass on the argmins, so (2)/S are only tested in the trivial b*=b0 case.
Referee hand example where the survivor step is genuinely needed: x=(32/25,32/25,9/100),
a0=(9/10,1/20,1/20), a1=(91/100,9/100,0), b0=(1/20,9/10,1/20), b1=(2/25,23/25,0): tau*=19/25, Case C,
a0_l+b0_l=1/10>9/100 so b0 not in S, b*=b1, V(a0,b1) feasible.  Directed test w9_ref_templates2_surv.py running.
Scripts: w9_ref_templates2_supports.py (PASS), w9_ref_templates2_e2e.py (random+climb; logs *_e2e_s11/12,
*_e2eV_s21/22.log running).
## [templates#2] FINAL VERDICT: CONFIRMED_WITH_FIXES (statement and proof correct; fixes are to significance/wording/tests)
Scripts/logs (all PASS): w9_ref_templates2_supports.py(.log); w9_ref_templates2_e2e.py -> *_e2e_s11/s12.log
(1500 random tau*>=3/4 + 15 slack-minimising climbs each; ~7000 total instances incl. H/Qb/Qa/V), *_e2eV_s21/s22.log
(V-focused: ~6700 V-case evaluations, 12 with b*!=b0); w9_ref_templates2_surv.py (seed example + 13621 directed
instances, 13359 V-case, 61 evaluations with b*!=b0; min V slack 0 only at a light part via closed S, allowed).
Fixes: (F1) one-sided |I|=2 is NOT literally a special case (types heavy at a light part exist); add the
restriction C'=C cap{a_l<=4x_l/7}: a u free for C' but not C has u_A+u_B+sum min(u_l,4x_l/7)<1, cost >
x_A+x_B+4x_Lam/7-1 > 3/4, so tau*(C')>=3/4 and H2 applies. (F2) "C_2 empty: min_{C_1}" -- attained because
C_1=C there (say so). (F3) attacker's verify_h2.py never tests b*!=b0 (0/295 V cases, seed 3); the claim that the
logs check the survivor bound (2) is vacuous in practice -- replace/augment with the directed test.
(F4) Case A/B feasibility can be tight (slack 0, e.g. theta_2=2x_2/3 exactly): templates need only <=, fine.
Novelty: note has 7.71/7.73 (two FIXED types, [C]), 7.75 (two parts, [C]), 7.80 (three parts of 4r/5, [C]); no
arbitrary-type-set statement over >2 parts; handback v2 lists |H|=2 as open ("face reduction"). NEW.
## [templates#2] (BREAK-IT) entry 1 -- checkpoint.
* Hand re-derivation of sec.5: every step correct (attainment, (1), F1, no double-heavy, Case A/B Q_b/Q_a facets in
  parts 1,2 and light parts, Case C facts, residual (C_1 at part 1, C_2\S in Lambda, S at part 2), S-empty contradiction,
  (2), V facets part 1/part 2/light).  Closed S of the statement vs strict S of the proof: harmless (S_strict c S_closed,
  so the closed maximiser has rho >= rho_strict; S_strict nonempty by the S-empty argument).
* Scripts: w9_ref_templates2brk_lib.py (branch-and-bound cutoff tau*, cross-checked vs brute; EXPLICIT cell-mass
  realisations of H/Qb/Qa/V with pairwise non-covering + row loads + capacity checked exactly),
  w9_ref_templates2brk_run.py (grid families = all lattice types in unions of boxes; random with forced ties and
  boundary values 4x/7, 2x/3; push to tau*=3/4 exactly; random tie-breaking; strict S; climbs; mutations).
  OWN BUG found+fixed: my first tau* allowed a cut 'below 0' (cost x_i, kills all) -> tau* underestimated (conservative:
  only fewer instances tested); rerun started.
* w9_ref_templates2brk_note779.py: note Prop 7.79 family: tau*=483/640 reproduced; all 168 subfamilies with <=2 heavy
  parts have tau* <= 33/64 < 3/4 (consistent with H2 + 7.79); best pair slack -3/640 (note: violation >= 1/640). PASS.
* SCOPE: one-sided |I|=2 families are NOT literally special cases: x=(1,1,1/2), boxes a_1>=3/5, a_2>=3/5 contains
  (3/5,0,2/5), heavy at part 3, so |H(C)|=3.  Repair (hand): C'=C cap {a_l<=4x_l/7, l notin I} is closed, heavy only in
  {A,B}, contains (thA,1-thA,0),(1-thB,thB,0), and any residual killing C' costs >= min(dA+dB, xA+xB-1) >= 3/4.
  Grid check in w9_ref_templates2brk_onesided.py (example tau*(C)=tau*(C')=4/5, recipe Qb slack 1/16).
## [templates#2] (BREAK-IT) entry 2 -- checkpoint (results so far, all exact).
* grid families (all lattice types in unions of boxes, p=2..5): s11 787 inst / s12 826 inst (630 pushed to tau*=3/4
  exactly), H/Qb/Qa/V all hit (V 93, b*!=b0 22), min slack 0 (Qb,Qa), V min 1/240. ALL PASS.
* random (ties, 4x/7 and 2x/3 boundary values, p up to 6, random tie-breaking, strict S): >26k inst so far, PASS.
* V-focus (Case C): >13k inst, V 1645, b*!=b0 42, Lam0>0 807; mutation b0 instead of b* fails 3/1645 (b* needed);
  Q_a/Q_b on (a0,b*) fail in ALL Case-C instances (V needed). PASS.
* SHARPNESS (w9_ref_templates2brk_sharp.py): climbs maximising tau* among no-light, <=2-heavy instances where the
  recipe fails reach 0.7494; where the WHOLE two-type menu (H, Qb, V over all ordered pairs) fails reach 0.7482.
  So 3/4 is sharp for H2 even without homogeneous types; no failing instance at tau*>=3/4.
* one-sided scope: 233 random one-sided |I|=2 grid families with tau*>=3/4, 63 with types heavy outside I; the
  restriction C' kept tau*>=3/4 and the recipe on C' succeeded in all. Hand bound for C': a residual killing the
  A-box part of C' either cuts A below thA or violates the sum condition r_A+r_B+sum_L min(r_L,4x_L/7) < 1, cost
  > xA+xB-1+4X_L/7; hence tau*(C') >= min(dA+dB, xA+xB-1) >= 3/4.
  * addendum: grid p2 D84 KILLED unfinished (too large, ~10^11 pair ops); not needed (p2 D28 exhaustive + note 7.75 cover p=2).

## [typeclosed#1] entry 0 -- START (referee w9, 24 Sep, lens LINE-BY-LINE LOGIC). Claim: GGP / GGP-mass / Corollary HL
## (notes_typeclosed.md 09:20 entry + GGP-mass paragraph; tc4/ggp_check*.py, ggpm_check.py).
## [templates#2] (BREAK-IT) FINAL VERDICT: CONFIRMED_WITH_FIXES (theorem + proof correct; fixes are scope/presentation)
* No counterexample. Exact runs (all logs w9_ref_templates2brk_*.log): grid s11/s12 1613 inst; rand s21/s22 64.9k;
  V-focus s31/s32 27.4k (V case 31.7k incl. pushed, b*!=b0 1290, Lam0>0 19.5k); wide capacities (one heavy part
  tiny, x in [1/5,9/5]) s41/s42 56.5k. ~26k+ instances exactly at tau*=3/4 per pair of seeds. Every template verified
  by explicit cell masses (pairwise non-covering, loads, capacity). Min slack 0 attained for Qb, Qa AND V (V tight at a
  light part, a0_l+b*_l=x_l: allowed). Intermediate claims (1),F1,no double-heavy,Case-C facts,S!=empty,(2) never failed.
* Necessity: b0 instead of b* fails in 124/31.7k V instances (survivor step needed); Q on (a0,b*) fails in every
  Case-C instance (V needed); 3/4 sharp even without homogeneous types (failing instances up to tau*=0.7494 recipe,
  0.7482 whole two-type menu).
* Fixes: (F1) significance "one-sided |I|<=2 are special cases" is false verbatim (x=(1,1,1/2), boxes a_1,a_2>=3/5
  contain (3/5,0,2/5), heavy at part 3); add the restriction C'=C cap {a_l<=4x_l/7} with tau*(C')>=min(dA+dB,
  xA+xB-1)>=3/4 (hand, checked on 233 grid families). (F2) order: "C_2 empty => tau*<=d_1<3x_1/7" uses attainment of
  theta_1, which follows from 'no type heavy nowhere' (a non-attained limit would be light everywhere) -- say so.
  (F3) M2/Th(p): keep the strict/weak convention consistent (H2 is proved for tau*>=3/4, which suffices for either).
* Novelty: note has no heavy-part classification; Thm 7.75 (two parts, [C], strict) is re-proved by hand with >=;
  the <=2-heavy-part statement over arbitrarily many light parts is NEW. Consistent with note Prop 7.79 (its 168
  subfamilies with <=2 heavy parts all have tau*<=33/64; tau*=483/640 reproduced) -- w9_ref_templates2brk_note779.py.

## [typeclosed#1] entry 0 -- START (referee w9, 24 Sep). Claim: Generalised Gap-Pair lemma GGP, GGP-mass, corollary HL.
* Read notes_typeclosed.md (09:20 GGP entry, 09:50 HL + GGP-mass, Thm L/L+), attacker scripts tc4/ggp_check*.py,
  ggpm_check.py, vsupport_check.py (V capacity only float-grid-checked there).
* Hand re-derivation of every line of the GGP proof (mass-1 and mass versions): all steps check (details in entry 1).
* Plan: w9_ref_typeclosed1_fm.py (exact strict Fourier-Motzkin over all 64 failure combinations, both versions;
  hypothesis-necessity probes), w9_ref_typeclosed1_supports.py (exact covers for Fano Q-templates and V support at
  region vertices + exact simplex), w9_ref_typeclosed1_e2e.py (HL end-to-end on random finite type sets, exact tau*).

## [typeclosed#0] (BREAK-IT lens) entry 0 -- START 24 Sep. Claim: THEOREM L+ (at most two parts carry super-heavy
## types; pencil or V(a,c)). Read notes_typeclosed.md sec ~11:00-11:50, note 7.63 (Lemma 7.63), 7.73 (V fn), 7.77 (Thm 7.75).
## Hand re-derivation of steps (0)-(3) and both identities: all correct so far (identities expand exactly; every
## strictness is available: e_j+e_k>=tau*>3/4 strict, x_j>3/4 strict). Plan: independent exact scripts
## w9_ref_typeclosed0_*.py: explicit (non-LP) V and pencil cell measures + brute non-covering check; own exact tau*
## (threshold enumeration); literal e2e of the proof on random / grid / boundary-tie finite families, p=2..5.

## [typeclosed#0] entry 0 -- START (referee w9, 24 Sep). Claim: THEOREM L+ (other parts 2/3-light => tau*>3/4 gives
## pencil or V(a,c)). Lens: LINE-BY-LINE LOGIC. Read notes_typeclosed.md sec L/L+, GGP, note 7.63/7.73/7.75,
## tc4/vsupport_check.py. Hand re-derivation of steps (0)-(3): every inequality and both identities re-derived
## by hand and CORRECT (details in final entry). V support (10 cells) re-derived by hand: primal masses
## (t<=s/2: t/2 on each mixed cell + 4-subsets of W∪{z} for demand (s-t)^4,(s-2t); t>=s/2: s/4 on mixed,
## s/2 on W, t-s/2 on {0,1}) and dual weights (w_c=1/2, w_W=1/4, w_z=0 -> s+t; w_c=1/4, w_a=1/4 -> 5s/4+t/2).
## Scripts to write: w9_ref_typeclosed0_{sym,e2e}.py.

## [typeclosed#2] entry 0 -- START (referee w9, 24 Sep, lens LINE-BY-LINE LOGIC). Claim: residual-regime structure (a),
##   Lemma E+ (b), excess bound (c).  Source: notes_typeclosed.md ~09:50 / ~11:50 / ~10:10 sections.
* Hand re-derivation in progress.  Early observations:
  - (a) second half = note Prop 7.55 (sec 7.57) argument (2-colouring of Fano + pencil <= 2x), applied to super-heavy
    classes instead of parts.  Not new in mechanism.
  - (b) derives E+ from L+ applied to C^(i): L+ needs ALL parts except two to be 2/3-light; C^(i) constrains only part
    i -> valid for p=3 ONLY, not for "any counterexample to Th(p)" with p>=4.
  - (c) first inequality tau*(C) <= tau*(C^(i)) + e_i holds for every p (S_i := C \ C^(i)); the min_i e_i corollary
    needs E+ (p=3).
## [typeclosed#1] entry 1 -- checkpoint. HAND RE-DERIVATION: GGP, GGP-mass and HL all CORRECT line by line.
* Definitions confirmed: Q_b(s,t)=max(3t/2,s+3t/4) (3 b-rows on a Fano line, via Lemma 7.63: row, pencils 3t<=2x /
  2s+t<=2x, total 4s+3t<=4x); V(s,t)=max(s+t,5s/4+t/2), five a-rows (templates_handproofs.md Lemma V, 10-cell support
  re-checked by hand: (2,1) point mass 3, cover argument OK).
* Every displayed inequality of the 09:20 entry re-derived; one alternative for V part j second facet
  (x_j-5a_j/4-b_j/2 > 3/2-a_k-5a_j/4 >= 1/2-a_j/4) also works. Mass variant: every '1' replaced by m_a/m_b/M, all hold.
* Light parts: L implies 5a/4+b/2 = (3a/2)/2+(a+b)/2 <= x, a+3b/4<=a+b, etc.
* EXACT strict-FM certificate w9_ref_typeclosed1_fm.py (log .log): 64 negation systems each infeasible for GGP (G strict
  AND G non-strict), GGP-mass (strict and non-strict), light part L (6 facets). Mutations all become feasible
  (drop H1: 27, drop H2: 36, G>3/4-1/1000: 59, one-sided mass gap: 18/24, H1 with 7+1/100: 18) => constant 3/4 sharp
  for this 3-template chain.
* FIX (minor): G may be NON-STRICT (>= 3/4, resp. >= (3/4)max m); all strictness comes from H1,H2,R1,R2. So at p=2 GGP
  recovers the templates Gap-Pair lemma exactly (which has non-strict G); with strict G as stated it is marginally weaker.

## [typeclosed#2] entry 0 -- START (referee w9, 24 Sep, lens BREAK-IT). Claim: residual-regime structure (a),
## Lemma E+ (b), excess bound (c) (notes_typeclosed.md ~09:50 residual regime, ~11:50 L+/E+, ~10:10 excess bound).
* Read: DEEP_BRIEF, CONTEXT, RESEARCH_LOG tail, notes_typeclosed 400-580, note 7.63/7.65 (Lemma 7.63), 7.79.
* Early hand findings (to be confirmed by scripts w9_ref_typeclosed2_*.py):
  (b) proof "Theorem L+ applied to C^(i)" only works for p=3 (L+ needs ALL BUT TWO parts 2/3-light; C^(i) makes
  only ONE part light). For p>=4 Lemma E+ implies Th(3) (embed a 3-part cex with an unused 4th part) -> not provable
  by L+ alone. (c) inherits the p=3 restriction; N>9/4 needs the (unstated) corner (sigma-eps) argument.
  (a) needs the regime context (3 parts, part 0 4/7-light, no everywhere-light type; exact minimisers).

## [typeclosed#1] entry 1 -- hand re-derivation + exact FM + supports (24 Sep ~10:30)
* HAND: every inequality of the 09:20 GGP proof re-derived (P1,P2; Q_b parts j,k; Q_a parts j,k; V parts j,k under R1,R2;
  other parts from L, incl. 5a/4+b/2 = (a+b)/2+3a/4 <= x and a+3b/4 <= a+b).  Also re-derived GGP-mass with M=max(m_a,m_b)
  replacing 1 everywhere: step(0) b_j+a_k > M; Q_b part j slack > M-m_a; part k slack > 3(M-m_b)/4; V part j
  x_j-a_j-b_j > (M-b_j)/2, x_j-5a_j/4-b_j/2 > (M-b_j)/4; part k x_k-a_k-b_k > (M-a_k)/2, 5a_k/4+b_k/2 slack > 0. All OK.
  (Minor: the notes' V part-j line '> 1/4+b_j/2-3a_j/4' uses the UNdoubled bound x_j > 3/4+b_j-a_k/2; fine.)
* w9_ref_typeclosed1_fm.py [CERTIFICATE, own strict Fourier-Motzkin, Fractions]: for BOTH versions all 64 combinations
  (one violated facet of Q_b, of Q_a, of V in part j or k) + hypotheses are infeasible.  Step(0) claims b_j+a_k>M,
  a_j<b_j, b_k<a_k proved; 'Q_b fails only via R1', 'Q_a only via R2' proved.  No a<=x or M<=1 needed.
  Necessity: dropping G, H1, H2 (or mass<=1 in the mass-1 version) each leaves feasible failing combos (64/27/36/64);
  G's constant 3/4 is sharp for this 3-template menu (3/4-1/1000 already fails, 59 combos).
* w9_ref_typeclosed1_supports.py [CERTIFICATE]: own exact simplex (with primal/dual optimality check) shows the cover
  values of the ACTUAL supports equal the formulas Q_b=max(3t/2,s+3t/4), Q_a, V=max(s+t,5s/4+t/2) on 625 grid points;
  explicit vertex covers printed; V support and Fano support valid (no covering pair).  Mutation control detected.
  => the V capacity dependency (attacker had only a float grid check) is now exactly confirmed as an upper bound
  (sublinear cover function, equality at the 3 region vertices).
## [typeclosed#0] entry 1 -- checkpoint (scripts).
 * w9_ref_typeclosed0_sym.py [exact, sympy]: K1/K2 identities exact; V support (10 cells) pairwise non-covering
   (incl. a cell with itself); explicit primal masses meet loads exactly with total 5s/4+t/2 (t<=s/2) / s+t
   (t>=s/2), masses >=0; dual weights (1/2,1/2,1/4^4,0) and (1/4)^7 feasible => V=max(s+t,5s/4+t/2) EXACT.
   Pencil (e,e,e|d^4), d=x-3e/4: Lemma-7.63 slacks {2x-3e, e/2, 0}, row slack 3e/4 => valid iff e<=2x/3. PASS.
 * w9_ref_typeclosed0_special.py [exact]: L+ proof run literally on heavyparts H3-cex (tiny part EXACTLY 2/3-light,
   so L+ applies; V found, explicit integer Venn realisation brute-forced) and H3*-cex (same); note Prop 7.79
   (pair-free, tau*=483/640) violates the L+ hypothesis for EVERY (j,k) -- necessary consistency check (L+ always
   yields a 2-type tuple) PASSES.
 * w9_ref_typeclosed0_e2e.py running (R=24 seeds 11,12 x3000; R=40 seeds 13,14 x1500; mut seed 15), logs in
   w9ref_logs/typeclosed0_e2e_*.log.
## [typeclosed#0] entry 1 (checkpoint). Scripts (all exact Fractions, no LP):
##  w9_ref_typeclosed0_lib.py: own tau* (threshold enumeration), explicit HAND masses for V (5 a-rows+2 c-rows) and
##   pencil (e,e,e on lines through p0; f on the 4 m-lines: mu=e/4 on the six other points, max(0,f-3e/4) at p0),
##   literal integer realisation (points, rows trimmed to exact profiles, all pattern pairs Venn-checked).
##  w9_ref_typeclosed0_templates.py: 1681 grid pts: V total == max(s+t,5s/4+t/2) EXACTLY, pencil total ==
##   max(3e/2,f+3e/4); 300 literal realisations at the capacity boundary. ALL PASS.  => the V dependency and the
##   pencil/Lemma 7.63 dependency are both re-derived without the note's templates.json.
##  w9_ref_typeclosed0_e2e.py (proof run literally, every step asserted): super 1638+1645 pencil / 1362+1355 V;
##   superonly 6000 V; p2 (vacuous hypothesis, = note Thm 7.75 instances) 5998 pencil + 2 V; mass<=1 stress
##   4220 pencil + 1780 V. ZERO failures. (logs w9ref_logs/w9_ref_typeclosed0_e2e_*.log)

## [typeclosed#1] (BREAK-IT lens) entry 2 -- FILE COLLISION + renamed scripts (24 Sep ~10:40)
* The LOGIC-lens referee of the same key writes w9_ref_typeclosed1_{fm,e2e}.py; my first versions under those names were
  overwritten (theirs are now there; left untouched).  My scripts are now w9_ref_typeclosed1brk_*.py:
  brk_fm.py (+.log), brk_lib.py (own exact simplex/covers/tau*), brk_supports.py, brk_e2e.py (+ logs per mode/seed).
  (My entry 1 above refers to w9_ref_typeclosed1_fm.py/_supports.py: read brk_fm.py / brk_supports.py instead.)
* brk_fm.log: GGP and GGP-mass hold with G strict AND non-strict (agrees with the logic referee's FIX); step(0) and
  'only R1 / only R2' proved; drops G/H1/H2/mass all produce failing combos; constant 3/4 sharp for the 3-template menu.
* Novelty: PCL (notes_heavyparts ~10:45) is the same chain but with light condition <= 4x/7 & a+b<=x and extra Lt; GGP's
  L (<= 2x/3 & a+b <= x) is slightly MORE general.  Note: only p=2 (Thm 7.75 [C], §7.77) and the template functions
  (M_{4,3} = Q in Lemma 7.57; V in §7.75 as V(s,t)=max(s/2+5t/4,s+t), i.e. ARGUMENTS SWAPPED vs the claim's V(a,b)).
  No multi-part light-part statement in the note (grep 'light part', 'half-light', 'x_i/2': nothing relevant).
* Running: brk_e2e.py modes mix/super/edge, seeds 21,22, 15000 trials each (background).
## [typeclosed#1] entry 2 -- checkpoint (dependencies + end-to-end; novelty)
* w9_ref_typeclosed1_e2e.py: exact dual-vertex enumeration (Fano support 16 vertices = note 7.63; V 10-cell support 31
  vertices), brute-force non-covering of both supports, min-mass == claimed Q_b / V / 7s/4 on 3000 rational points.
  HL run literally on random finite (closed) rational type sets, p=2..4, exact tau* by threshold enumeration: seed 1
  (3000 trials): 678 families with tau*>3/4, 2647 (a,b) pairs with G tested, all covered (Qb 579, Qa 98, V 1 at the
  minimiser pair). Seeds 2-5 (40000 trials; even seeds = super-heavy (>2/3 fill) generator to reach the V regime)
  running -> w9_ref_typeclosed1_e2e_s{2..5}.log.
* Attacker scripts re-run: ggp_check 2024 OK, ggp_check2 2415 OK (V in 1530), ggpm_check 16826 OK (reproduced).
  Cosmetic: ggp_check2 imports ggp_check, whose test runs at import (output printed twice).
* V(a,b) vs V(b,a): conclusion also holds with V(b,a) (FM: 0 feasible negations) -- trivially by the (j,a)<->(k,b)
  symmetry of the hypotheses; the statement should still say which type is the five-row type.
* HL near-minimiser step: theta_k may be unattained (limit type exactly 4/7-fill at k is j-heavy); near-minimisers
  suffice because tau*>3/4 is strict -- the attacker says 'near-minimisers', correct.
* NOVELTY: p=2 case = templates Gap-Pair (templates_handproofs sec.2; with non-strict G). HL is a special case of
  templates Theorem H2 (sec.5, 4/7-light, tau*>=3/4 allowed) and of Theorem L / L+ (same day) -- claim itself says
  L+ subsumes HL. GGP proper (local hypotheses: gap only on {j,k}, L elsewhere, no global tau* of {a,b}) is not implied
  by Theorem TT (TT needs tau*({a,b})>=3/4 over ALL part pairs) nor by 2UB; it generalises heavyparts PCL (PCL needs
  4/7-lightness and the extra Lt; GGP derives a_j<b_j, b_k<a_k from step (0)). Not in the note (grep: no multi-part
  gap-pair / light-part lemma; note has only 7.71 [C] two fixed types and 7.74-7.77 two parts).
## [typeclosed#0] (BREAK-IT) entry 2 -- FILE COLLISION NOTE: the other typeclosed#0 referee also uses prefix
##  w9_ref_typeclosed0_ and overwrote my e2e script at 10:18. All MY files are now prefix w9_ref_typeclosed0brk_
##  (lib, templates, e2e, thmL, climb; logs w9ref_logs/w9_ref_typeclosed0brk_*). The entry-1 counts above came from
##  my original e2e (logs renamed to w9_ref_typeclosed0brk_e2e_*.log); re-running with the v2 e2e that asserts the V
##  construction for EVERY witness c (not just the first) -> logs *_e2e2_*.
## NOVELTY FINDING: Theorem L (4/7 version) is the SAME statement as the templates agent's THEOREM H2
##  (templates_handproofs.md sec.5, already refereed CONFIRMED_WITH_FIXES as templates#2; its tuple menu H,Q_a,Q_b,V and
##  its Case-C witness b* from a residual 'part 1 below theta_1, light parts below x_l-a0_l' is the same mechanism as
##  L+'s u). So the |H|<=2 branch was already closed by H2; the genuinely new content of typeclosed#0 is L+ =
##  light threshold 4/7 -> 2/3 plus a shorter proof (pencil-with-request replaces hom-Fano + Q_b/Q_a). Novel vs note: yes.
## [typeclosed#2] entry 1 (checkpoint)
* Scripts: w9_ref_tc2_lib.py (exact Fraction tau* by threshold enumeration, Lemma 7.63 criterion, V, Q_b, pencil),
  w9_ref_tc2_basic.py (all 128 2-colourings of Fano LINES have a monochromatic concurrent triple; note 7.79: tau*=483/640
  reproduced, e=(161,169,153)/640, pairwise sums <= 33/64 < 3/4 < sum=483/640 -> 7.79 IS in the balanced case; E+ and
  (c) hold for it), w9_ref_tc2_random.py (modes c/a/b), w9_ref_tc2_unbal.py.
* (c) excess bound exact random (p=3,4, arbitrary finite C): ~4100 checks + ~5900 S_i-empty equalities, 0 failures;
  ~1/3 tight.  The inequality needs NO 3-class hypothesis (S_i := C \ C^(i)).
* (a) Thm-L setting generator: 37 residual-regime families (theta>2x/3 both), all: exactly-one super-heavy, x_j+x_k>9/4,
  EXHAUSTIVE |C|^7 Lemma-7.63 check -> no Fano tuple; 263 non-residual: Q_b / Q_a with minimisers always valid.
* (b) L+ recipe on C^(i): 601 applications (mostly pencil); b0 runs (no light types) running.
## [typeclosed#0] (BREAK-IT) FINAL VERDICT: CONFIRMED_WITH_FIXES (mathematics correct; fixes = novelty/significance + wording)
* Hand re-derivation: (0) pencil: explicit masses e/4 on the six non-p0 point cells, max(0,f-3e/4) on p0's cell give
  total max(3e/2, f+3e/4) <= x (no need even for Lemma 7.63). (1) free vectors, e<=x/3, x_j+x_k>9/4, x_j,x_k in (3/4,3/2],
  no type in A and B. (2) cost(u) <= 1+x_k-2sigma_k+eps <= 1-x_k/3+eps < 3/4; witness c in B. (3) V facets in light
  parts (a_i<=2x_i/3 is exactly what 5a/4+c/2<=x needs given c<=x-a), part j (x_j+x_k>=3/2), part k (both identities
  expand exactly; strictness from e_j+e_k>=tau*>3/4 and x_j>3/4). Closedness of C is never used (eta handles inf).
  Mass-1 is used only as an upper bound (sum c<=1 also works).
* Exact scripts (prefix w9_ref_typeclosed0brk_): templates (1681 grid + 300 literal realisations; V total ==
  max(s+t,5s/4+t/2) exactly with HAND masses: t>=s/2: s/4 on the 4 mixed cells, t-s/2 on {c,c}, s/2 on W;
  t<s/2: t/2 mixed, (s-2t)/4 on the four 4-sets containing z, s/4+t/2 on W). e2e2 (every witness c checked, literal
  integer realisation + all pattern pairs): super 3323 pencil/2677 V, superonly 6000 V, p2 5996 pencil/4 V,
  mass<=1 4243 pencil/1757 V, gen 5997 pencil/3 V: ZERO failures. Theorem L (4/7) e2e: hom 3106, Q_b 5591, Q_a 301,
  V 2: ZERO failures. Adversarial climbs (max tau* s.t. NO pencil pair and NO V pair among all ordered type pairs):
  best template-free tau* 0.74996 (<3/4, and approaching 3/4: sharp); mutation light cap 0.75/0.8 also found none
  above 3/4 (climb limitation: a zero-capacity part pins the score at 0).
* FIXES: (F1) NOVELTY/SIGNIFICANCE: Theorem L = templates agent's Theorem H2 (templates_handproofs.md sec.5, refereed
  templates#2); the |H|<=2 branch, the residual regime and the two-part hand re-proof of note Thm 7.75 were ALREADY
  closed there. Credit L+ as a strengthening of H2 (light threshold 4/7 -> 2/3) with a shorter proof; cite H2.
  (F2) state tau*>3/4 strictly (H2 allows >=; L+'s pencil request needs strict). (F3) the dependency on templates.json
  fn 38/39 is unnecessary: the explicit V masses above are a 3-line hand proof; include them. (F4) 'closed' can be
  dropped. (F5) the claim's reduction 'Th(3) needs a super-heavy type in every part' is correct (contrapositive with
  j,k = the other two parts).
## [typeclosed#2] entry 1 -- script results so far
* w9_ref_typeclosed2_lib.py (independent exact tau* by threshold enumeration; Lemma 7.63 Fano check with integer
  scaling; V; classes). Sanity: note 7.79 tau* = 483/640 reproduced; Fano tuple found (rows from 3 classes).
* (a) w9_ref_typeclosed2_a.py seed 1 (log _a_s1.log): all 128 2-colourings of Fano LINES have a monochromatic pencil
  (882 3-colourings have none). 400 random 2-class super-heavy families (part 0 4/7-light): exhaustive Fano search
  NONE (as claimed); 25 with tau*>3/4: minimiser pair satisfies R1,R2 (Q_b,Q_a fail), x_j+x_k>9/4. CAVEAT example
  (literal statement): x=(1/2,13/10,13/10), a=(0,1/10,9/10), b=(0,9/10,1/10), l=(1/5,2/5,2/5): minimiser pair fails
  Q_b,Q_a with G true, but l is light everywhere -> hom. Fano. So (a) needs 'no everywhere-light type' (automatic in a
  counterexample). Sharpness: 1652/3000 two-class families heavy (>4/7) but NOT super-heavy have Fano tuples.
* (c) w9_ref_typeclosed2_bc.py seeds 1,2 (logs _bc_s1/_s2): 1641 exact checks of tau*(C) <= tau*(C^(i)) + e_i over
  p=3,4 (877 tight, incl. boundary types c_i=2x_i/3 and types super-heavy in two parts): no failure. 504 no-pencil
  families: tau* <= sum e, N >= 3 sum e, x_i <= 3/2 on hosting parts: no failure. L+ run literally on C^(i) with
  tau*(C^(i))>3/4: 139 cases (134 pencil+requests, 5 V), every tuple verified exactly by Lemma 7.63 / V.
* (b) p=4: note 7.79 + unused 4th part: C^(3)=C, tau*=483/640, three hosting parts -> L+ inapplicable.
  Formal: Lemma E+ for p=4 IMPLIES Th(3) (a 3-part cex + unused part is a 4-part cex with C^(3)=C, tau*>3/4).
## [typeclosed#2] entry 2 (findings)
* (a) full chain: 197 more residual families (w9ref_logs/tc2_a_s7.log), exhaustive no-Fano in all; Q_b/Q_a 1303 OK.
  LITERAL (a) lacks hypotheses tau*>3/4, other parts 4/7-light, and NO everywhere-4/7-light type: w9_ref_tc2_literal_a.py
  x=(1/5,7/5,7/5), a=(0,1/20,19/20), b=(0,19/20,1/20), ell=(1/10,9/20,9/20): tau*=1, minimiser pair fails Q_b,Q_a, yet
  ell is super-heavy nowhere and 7 x ell is a (homogeneous) Fano bad tuple.  Quantifier: "the near-minimiser pair"
  must read "every near-minimiser pair" (or exact minimisers when attained).
* (b) Lemma E+ is proved only for p=3 (L+ needs all parts but two 2/3-light; C^(i) constrains only part i).
  Correct p-part version: for every set I of p-2 parts, C^(I)={c: c_m<=2x_m/3, m in I} has tau*<=3/4, and
  (c) generalises to tau*(C) <= tau*(C^(I)) + sum_{m in I} e_m.
* SIGNIFICANCE overclaim: "what remains open for Th(3) is the balanced case" is NOT established.  The REMARK
  (unbalanced e_j+e_k>3/4) needs a side condition e_i <= a_i <= 2x_i/3 on the S_k-minimiser.  Exact search
  (w9_ref_tc2_unbal.py; logs tc2_unbal_*): 23 unbalanced families with tau*>3/4 AND E+ for all i; the REMARK fails in
  both orientations in 21.  Explicit: w9_ref_tc2_example.py, x=(59/40,13/40,39/40), 7 types, tau*=31/40,
  tau*(C^(i))=(3/10,7/10,39/80), e=(19/40,3/40,37/120), e_0+e_2=47/60>3/4; S_2-minimiser (1/12,1/4,2/3) has a_1=1/4>2x_1/3,
  S_0-minimiser (1,0,0) has a_1=0<e_1.  (Some V pair works in all 21 -> not counterexamples to Th(3); gap is in the
  proof coverage.)  Also: types in two super classes occur (e.g. (0,1/4,3/4) there), so "3 super classes" is a cover,
  not a partition, in the 3-class regime.
## [typeclosed#2] FINAL VERDICT: CONFIRMED_WITH_FIXES
* L+ recipe applied literally to C^(i) (no light types, w9ref_logs/tc2_b0_s5..8.log): 118/118 V witnesses valid, every
  intermediate assertion (A,B nonempty, e_j+e_k>3/4, x_j+x_k>9/4, corner cost<3/4, witness in B) true; earlier runs
  601 (mostly pencil).  (c) exact: ~4100 bound checks, 0 failures.  (a) 234 residual families exhaustively Fano-free.
* Fixes: (1) (a) add hypotheses tau*>3/4, other parts 4/7-light, no everywhere-light type; "every near-minimiser pair".
  (2) (b) and the min_i e_i corollary: p=3 only (general p: sets I of p-2 parts). (3) significance: unbalanced case NOT
  closed (explicit family above). (4) novelty: (a)'s 2-colouring+pencil argument = note Prop 7.55 (sec 7.57).
## [typeclosed#0] FINAL REPORT (referee w9, lens LINE-BY-LINE). Verdict: CONFIRMED_WITH_FIXES (fixes are about wording and scope; the maths is correct).
HAND AUDIT (every line re-derived):
 (0) Pencil: rows e,e,e on one row-Fano line, d=x-3e/4 on the 4 complementary rows; each other line meets L0 in
     one point and has 2 d's, so the Lemma 7.63 slacks are 2x-3e, e/2, 0; rows ok; d>=0. Request u=x-3e/4 has cost
     (3/4)mass <= 3/4 < tau*, so it is not free (tau*>3/4 is strict), so a type c'<=d exists. CORRECT.
 (1) sigma_j >= 2x_j/3 (inf of values > 2x_j/3); A empty => cost e_j+eps <= sigma_j/2+eps <= 1/2+eps. CORRECT.
     (sigma_j-eps,sigma_k-eps,x) is free => e_j+e_k >= tau* > 3/4; x_i >= 3e_i; x_i <= 3sigma_i/2 <= 3/2 => x_i > 3/4.
     CORRECT.
 (2) cost(u) = sum_{i!=k} a_i + e_k + eps <= (1-a_k)+e_k+eps <= 1+x_k-2sigma_k+eps <= 1-x_k/3+eps < 3/4. The witness
     c<=u has c_k <= sigma_k-eps, so c is not in A, so c is in B, and c_k <= 1-c_j <= 1-sigma_j. CORRECT.
 (3) Parts i!=k: c_i <= x_i-a_i, so 5a_i/4+c_i/2 <= x_i/2+3a_i/4 <= x_i iff a_i <= 2x_i/3. For part j:
     a_j <= 1-a_k <= 1-sigma_k <= 1-2x_k/3 < 2x_j/3 because x_j+x_k > 3/2. Part k: both identities are exact (sympy)
     and every bracket is >= 0, with (x_j-3/4)/3 > 0 resp. [e_j+e_k-3/4] > 0 strict, so eta can be chosen below
     min(K1, 4K2/5). CORRECT.
 V support: the 10 cells are pairwise non-covering, and the primal and dual certificates are exact. V = max(s+t, 5s/4+t/2) holds
     for every number of parts, since the support is fixed and the per-part LP is separate. CORRECT.
FIXES / REMARKS (none of them invalidates the proof):
 F1 Notation clash: in step (0) 'e' is the pencil TYPE, and from (1) on e = x - sigma. Rename one of them.
 F2 Unstated standing hypotheses: j != k; C nonempty; types have mass <= 1 (the proof uses mass <= 1 only as an upper
    bound, so rank <= 1 works as well as =1); u ranges over [0,x]. CLOSEDNESS OF C IS NOT USED (only infima and near-
    minimisers), so the statement holds for arbitrary type sets.
 F3 'cost exactly 3/4' in (0) holds only for mass-1 types; for mass m it is 3m/4 <= 3/4 (harmless).
 F4 Significance scope: with p=2 the hypothesis is vacuous, so L+ is a HAND proof of the CONTINUOUS statement of
    note Thm 7.75 (2-type bad tuple: pencil {e,c'} or V {a,c}). The finite corollary floor(3k/4)+28 needs the note's
    rounding step, which is not in the claim. The rounding does carry over: Fano has 7 parent cells and V has 10, both <= 14.
    Theorem L (4/7 version) is a special case of L+, so its separate Q_b/Q_a route is not needed for correctness.
 F5 Consistency check: note Prop 7.79 (pair-free, tau*=483/640) must violate the L+ hypothesis for every (j,k),
    because L+ always outputs a 2-type tuple. It does: all three parts host super-heavy types. The heavyparts H3-cex is covered
    by L+, since its tiny part is EXACTLY 2/3-light, 1/100 = 2(3/200)/3. So the boundary convention '<=' matters there.
NOVELTY: grep of note_644.md (2x/3, super-heavy, pencil, light part, 3a/4 requests) finds no such statement. V
 (note 7.73 V(s,t) with roles mirrored) and Lemma 7.63 are the note's; the corner/request argument and the many-part
 extension are new relative to the note.
SCRIPTS (all exact unless noted): w9_ref_typeclosed0_sym.py (identities, V support primal/dual, pencil slacks) PASS;
 w9_ref_typeclosed0_special.py (H3-cex, H3*-cex -> V realised and brute-forced; 7.79 hypothesis fails for all (j,k)) PASS;
 w9_ref_typeclosed0_e2e.py: 9000 hill-climbed families (R=24: 2x3000, R=40: 2x1500; p=2..4, tau*>3/4 exact),
 with the proof run literally and every assertion checked, for all near-minimisers a and ALL witnesses c. Pencil branch: Lemma 7.63 exact
 plus an LP realisation. V branch: explicit integer Venn realisation at scale 4, rows trimmed to the exact types, no piercing pair
 by brute force. Result: 0 failures (logs w9ref_logs/typeclosed0_e2e_R*.log). MUTATION (third part allowed
 super-heavy): the proof breaks in 17/100 and 19/40 families (e.g. '5/4 facet' failing at the heavy third part),
 which confirms that the hypothesis is used. Attacker's tc4/thmL_fm.py and vsupport_check.py re-run: PASS.
## [typeclosed#1] FINAL VERDICT: CONFIRMED_WITH_FIXES (mathematics correct; fixes are statement precision + novelty wording)
* e2e (exact, w9_ref_typeclosed1_e2e_s{2..5}.log): families with tau*>3/4 tested 1571/9486/1676/9415 (hom Fano
  153/262/157/247); minimiser pairs resolved Qb/Qa/V = 0/0/1418, 7771/1415/38, 0/0/1519, 7699/1437/32; all 78217 (a,b)
  pairs satisfying G covered. Super-heavy seeds exercise the V regime thoroughly. No failure.
* w9_ref_typeclosed1_Lnecessity.py: exact 3-part pair (heavyparts' x=(6/5,6/5,19/60)) with H1,H2,G, 4/7-light part 0,
  3a/2,3b/2<=x_0 but a_0+b_0>x_0: Q_b, Q_a, V(a,b), V(b,a) all fail -> the pair clause of L is necessary for GGP.
* Fixes: (1) G may be non-strict (and then p=2 is exactly the templates Gap-Pair); (2) state the V convention (five
  rows of the k-heavy type a) -- either orientation works; (3) 'types' = nonneg vectors, the mass version needs no
  total-mass bound at all; (4) HL is subsumed by templates Thm H2 (sec.5) and Theorem L -- present HL as a corollary,
  not a separate theorem; (5) cosmetic: ggp_check2 re-runs ggp_check's test on import.
## [typeclosed#2] entry 2 -- significance ('only the balanced case remains open') under test
* The unbalanced case (some e_j+e_k>3/4) is closed in the notes ONLY by the REMARK (~10:25), which needs the extra
  family-dependent hypothesis e_i <= a_i <= 2x_i/3 on the S_k minimiser. w9_ref_typeclosed2_unbal.py (repair
  adversary, seeds 1-3 via the unbal2 import, logs _unbal2_s*.log first lines): 136 unbalanced 3-class families with
  tau*>3/4: REMARK hypothesis held in only 27 (20%), but the capped-corner+V mechanism itself succeeded in 136/136.
  So the significance sentence is an unproved reduction (numerically plausible). Broad sampler _unbal3 running.
* Hand observation: the UNCAPPED corner (x_i-a_i, x_j-a_j, sigma_k-eps) always costs 1+x_k-2sigma_k<3/4, but its
  witness may lie in S_i\S_j, where V(a,c)'s part-k facet (c_k <= e_k) is not implied; capping u_i at sigma_i
  excludes S_i but costs e_i-a_i extra when a_i<e_i. That is exactly the missing case.

## [typeclosed#1] (BREAK-IT lens) FINAL VERDICT: CONFIRMED_WITH_FIXES (math correct; fixes = presentation/novelty)
* No counterexample.  brk_e2e (exact tau*, proof run literally, templates checked by EXACT covers of the actual Fano / V
  supports via own simplex + optimality certificates, not by formulas), 6 runs (mix/super/edge x seeds 21,22; logs
  w9_ref_typeclosed1brk_e2e_*.log): 20700 families with tau*>3/4 (p=2..5); 5143 homogeneous Fano; minimiser pair:
  Q_b 12146, Q_a 2318, V 1113; all 47467 (a,b) pairs in AxB meeting H1,H2,G,L satisfy GGP (V needed 3102 times).
  HL-proof assertions (A,B nonempty; d_j+d_k >= tau*; minimisers satisfy H1,H2,G,L) never failed.
* CERTIFICATES: brk_fm.py (strict FM, all 64 combos, both versions, G strict or not); brk_supports.py (formulas =
  exact cover values of the supports; vertex covers explicit).  V dependency now exact (attacker: float grid only).
* FIXES: (1) G can be non-strict (>= 3/4, >= (3/4)max m) -- agrees with logic referee; p=2 then is exactly the templates
  Gap-Pair lemma.  (2) State the template conventions: V(a,b) = FIVE rows of the k-heavy a, two of b; the note's
  §7.75 V(s,t)=max(s/2+5t/4,s+t) has the arguments swapped.  (3) The JSON proof of HL omits the homogeneous-Fano and
  'one class empty' steps (present in notes 09:20 corollary) -- include them.  (4) Hypotheses 3/4, H1, H2 are each
  necessary for this 3-template chain (FM drop probes), so no cheap strengthening.
* Novelty: p=2 = templates Gap-Pair (hand) = note Thm 7.75 ([C]); multi-part light-part version not in the note; PCL
  (heavyparts) is the same chain with a stronger light hypothesis (<=4x/7), GGP's L (<=2x/3, a+b<=x) is slightly more
  general.  HL is subsumed by Thm L (4/7-light) / L+ (2/3-light) and templates#2's <=2-heavy-part theorem; its value
  now is as the stepping stone / facet computation reused inside L and L+.
## [typeclosed#2] entry 3 -- broad sampler + referee partial repair LEMMA U
* w9_ref_typeclosed2_unbal3.py seeds 1-4 x 20000 (logs _unbal3_s*.log): 20858 unbalanced 3-class families with
  tau*>3/4 (every type super-heavy somewhere): REMARK hypothesis held in only 3916 (19%); capped-corner+V and
  uncapped-corner+V mechanisms each succeeded in ALL 20858. No mechanism failure.
* LEMMA U (referee, FULL_PROOF by hand; exact test w9_ref_typeclosed2_lemU.py seeds 1,2 x 40000: 33254/33254 OK).
  3 parts i,j,k; every type super-heavy somewhere; e_j+e_k > 3/4 (sigma_m = inf over S_m, e = x - sigma).  Let a be an
  S_k-minimiser, b an S_j-minimiser (near-minimisers if not attained).  If a_i + b_i <= x_i then V(s,t) is a bad tuple,
  s = the one with the smaller i-coordinate, t the other.  NO tau* hypothesis.
  Proof. x_j,x_k > 3/4 (x_j+x_k >= 3(e_j+e_k) > 9/4, x <= 3/2); sigma_j,sigma_k > 1/2.
  a_j <= 1-sigma_k <= e_j: since e_j > 3/4-e_k = 3/4-x_k+sigma_k and 2sigma_k-x_k >= x_k/3 > 1/4. Symm. b_k <= e_k.
  V(a,b) part j: a_j+b_j = a_j+sigma_j <= x_j; 5a_j/4+b_j/2 <= x_j/2+3a_j/4 <= x_j (a_j<1/2<2x_j/3).
   part k: a_k+b_k = sigma_k+b_k <= x_k; 5sigma_k/4+b_k/2 <= 5sigma_k/4+(1-sigma_j)/2 <= x_k by the L+ identity
   x_k-5sigma_k/4-(1-sigma_j)/2 = [e_j+e_k-3/4]+(1-sigma_k)/4+(3/2)(sigma_j-2x_j/3) > 0.
  V(b,a) symmetric (J2 identity in part j; part k via a_k <= x_k-b_k and b_k <= 2x_k/3).
  part i: max(s_i+t_i, 5s_i/4+t_i/2) = s_i+t_i when s_i <= 2t_i, true for s = smaller.  []
  So the unbalanced case is closed EXCEPT the residual subcase a_i + b_i > x_i for all (near-)minimiser pairs
  (forces x_i < 1). In random sampling that subcase occurred 526 times, never with tau*>3/4.
  Targeted residual adversary w9_ref_typeclosed2_resid.py running.
* Residual adversary w9_ref_typeclosed2_resid.py seeds 1-3 x 3000 (logs _resid_s*.log): 144 families IN the residual
  subcase (a_0+b_0 > x_0, unbalanced, all 3 classes, tau*>3/4) were realised -> Lemma U alone does not close the
  unbalanced case; every one had SOME V pair (exact). No family without a bad tuple.
## [typeclosed#2] FINAL VERDICT: CONFIRMED_WITH_FIXES
* (a) correct (Lemma 7.63 pencil bound + non-2-colourability, 128 colourings checked; 400 exhaustive Fano searches).
  Fix: state the regime: three parts (or all parts other than j,k 4/7-light), NO everywhere-4/7-light type (else the
  literal statement fails: explicit example above), exact minimisers (attained once theta>2x/3; if theta<=2x/3 a
  near-minimiser gives Q). 'Every near-minimiser pair fails' / 'the minimiser pair fails' rather than 'the pair'.
* (b) correct for p=3. FALSE AS PROVED for p>=4: L+ needs all but two parts 2/3-light, C^(i) makes only one part
  light; indeed Lemma E+ for p=4 IMPLIES Th(3) (3-part cex + unused 4th part), so it cannot follow from L+.
  Correct p-part form: C^(I) = {c: c_m <= 2x_m/3, m in I}, |I| = p-2, has tau* <= 3/4.
* (c) the inequality tau*(C) <= tau*(C^(i)) + e_i is UNCONDITIONAL (any closed C, any i with S_i nonempty) and correct
  (1641 exact checks, 877 tight). Consequences tau*-3/4 <= min e_i, x_i <= 3/2: p=3 only (p>=4: min over |I|=p-2 of
  sum_{I} e_m). N > 9/4 is correct for every p but needs its own (unstated) argument: every type is super-heavy
  somewhere, so the sigma-corner is free: sum e >= tau* > 3/4 and N >= 3 sum e.
* SIGNIFICANCE overclaims: 'what remains open for Th(3) is the balanced case' is NOT proved: the REMARK needs
  e_i <= a_i <= 2x_i/3 (held in only 19% of 20858 sampled unbalanced families). Referee LEMMA U closes the
  unbalanced case when a_i+b_i <= x_i; the residual subcase a_i+b_i > x_i is realisable (144 families) and remains
  open by hand (numerically always killed by a V pair). Correct wording: open = balanced case + unbalanced residual.
* Novelty: note has no 2/3-fill (super-heavy) classification, no Lemma E+/excess bound (grep: none). (a) is an
  elementary corollary of note Lemma 7.63; (b),(c) are new but only as strong as Theorem L+ (attacker, refereed
  separately; its identities K1/K2 re-derived by hand here and exercised in 139 exact L+ runs on C^(i)).
## [heavyparts#2] (BREAK-IT lens) start -- Pair Chain Lemma (PCL, notes_heavyparts ~10:45)
* Read claim + notes_heavyparts; prior referee remarks on PCL at typeclosed#1 (novelty: same chain as GGP/Gap-Pair).
* Plan: w9_ref_heavyparts2_supports.py (exact V cover function from catalogue fn38 witness, exact Q via Lemma 7.63
  criterion), w9_ref_heavyparts2_e2e.py (exact random + boundary families; each sub-claim checked separately),
  w9_ref_heavyparts2_fm.py (hand re-derivation; hypothesis-drop probes).
## [heavyparts#2] entry 0 -- START (referee w9, 24 Sep, lens LINE-BY-LINE LOGIC). Claim: Pair Chain Lemma (PCL) =
##  Gap-Pair with light parts (notes_heavyparts.md ~10:45). Plan: hand audit, exact strict FM over all facet-failure
##  combos (w9_ref_heavyparts2_fm.py), explicit-mass e2e (w9_ref_heavyparts2_e2e.py), hypothesis-drop probes, novelty grep.
## [heavyparts#1] entry 0 -- START (referee w9, 24 Sep, lens LINE-BY-LINE LOGIC). Claim: 'Fano feasibility ignores light
##  parts (reduced model)' (notes_heavyparts ~10:10 'Also:'). Plan: hand audit vs note Lemma 7.63 + free-residual def
##  (note sec.3 l.84), exact script w9_ref_heavyparts1_check.py (independent Fano labelling, independent per-part LP,
##  exact tau* by free-residual blocking maps, reduced vs original), edge cases (zero-H-trace type), scope caveat (non-Fano).
## [heavyparts#1] BRK entry 0 -- START (referee w9, 24 Sep, lens BREAK-IT / counterexample search; parallel to the
##  LINE-BY-LINE session above). Scripts prefixed w9_ref_heavyparts1brk_ (distinct from the logic session's _check).
##  Plan: assignment-level equality full-vs-H-only Fano feasibility (all m^7 row assignments, own Fano labelling, exact),
##  tau* reduced vs original by two independent exact methods, boundary/tiny/zero-trace/zero-capacity generators,
##  mutation (threshold 4/7 -> 4/7+eps, 2/3) to show test power, scope caveat for non-Fano templates (V).

## heavyparts#0 -- Arc-CSP classification (referee w9, lens LINE-BY-LINE LOGIC), 24 Sep
VERDICT: CONFIRMED_WITH_FIXES.  The finite classification is correct; the "iff" needs the totals caveat stated
precisely; the extension in notes_heavyparts ~15:55 ("Fano-free iff EVERY representative triple conflicts") is FALSE.
* w9_ref_heavyparts0_arc.py [exact, independent]: Fano model on F_2^3\{0}, arc test via all concurrent 3-subsets,
  minimal hitting sets by brute force over all 2^7 pattern subsets.  Reproduces 882 arc colourings (profiles
  (2,2,3):504,(1,3,3):252,(1,2,4):126), 15 pattern sets, 78 hitting sets, minimal = {AAB,BBA},{AAC,CCA},{BBC,CCB},
  {AAB,BBC,CCA},{AAC,BBA,CCB}.  ABC never matters.  Script heavy/arc_csp.py minimality loop also re-read: correct.
* Semantics re-derived: with exactly one type per label (each type super-heavy SOMEWHERE, so XXX is always forbidden;
  classes may even share a part or a type may be super-heavy at two parts), pencil feasibility of a line->type map
  = its point patterns avoid F := {patterns P : some part i has sum of P's traces > 2x_i}.  Hence
  conflict  <=>  every map violates a pencil constraint.  Random exact test (3000 draws, N=60): 333 conflict /
  0 pencil-feasible; 676 no-conflict / all pencil-feasible; 0 violations.
* TOTALS CAVEAT IS REAL: 3/676 no-conflict instances have NO Fano tuple because every pencil-feasible map breaks a
  per-part total <= 4x_i.  Explicit: x=(57,26,28), types (45,0,15)[A], (27,18,15)[B], (34,7,19)[C] (sum 60);
  F={AAB,AAC}, no conflict, Fano-free.  So the correct statement is: conflict => Fano-free; no conflict => some
  pencil-feasible map exists, and Fano-free iff every conflict-avoiding arc colouring breaks a part total.
* COUNTEREXAMPLE to the multi-type lift (notes ~15:55 "Fano-free iff for EVERY choice of representatives ...
  conflict"): w9_ref_heavyparts0_multi.py, cross-checked with heavylib.all_fano (exact Fractions).
  x=(46,45,48), A-types a1=(33,0,27), a2=(46,0,14), B-type (16,38,6), C-type (2,15,43), all super-heavy at own part.
  Both rep triples conflict ({AAC,CCA,BBC} and {AAB,AAC,BBC,CCA}), yet a Fano tuple exists (line->type
  (a1,a1,b,a2,c,c,b) in my labelling; totals 148,106,166 <= 184,180,192).  Mechanism: a1a1c overloads C (97>96),
  a2a2c overloads A (94>92), but the MIXED a1a2c is fine (81<=92, 84<=96).  Only the direction
  "Fano-free => every representative triple conflicts or is total-blocked" survives.  (tau* here 5/12, so no threat
  to Th(3), but the proposed "finite case analysis" must use patterns over TYPES, not over classes.)
* H3s-cex re-checked exactly: F={AAC,CCA} = mutual A<->C conflict, 0 pencil-feasible maps.  Claim correct.
* Novelty: note has non-2-colourability (Prop 7.55) and Lemma 7.63 only; arc lemma = typeclosed (ii).  The
  3-colour minimal-forbidden-pattern list appears nowhere in note_644.md or other workspace notes: new but small
  (a finite enumeration), useful bookkeeping only for 3-type super-heavy families.

## [heavyparts#0] BRK entry 0 -- START (referee w9, 24 Sep ~11:00, lens BREAK-IT; parallel to the LINE-BY-LINE session
##  above).  Scripts prefixed w9_ref_heavyparts0brk_ .
* INCIDENT: my first write of w9_ref_heavyparts0_multi.py OVERWROTE the LINE-BY-LINE session's file of that name.
  My version now lives at w9_ref_heavyparts0brk_multi.py; w9_ref_heavyparts0_multi.py was RECONSTRUCTED as an exact
  re-verification of the LINE-BY-LINE counterexample (x=(46,45,48)/60, a1,a2,b,c): reproduced -- both rep triples
  conflict, mixed Fano tuple exists (a1,a1,a2,b,c,b,c in primal labelling), totals 148,106,166 <= 184,180,192, tau*=5/12.
* w9_ref_heavyparts0brk_arccsp.py [exact, primal form rows-on-points, lines {i,i+1,i+3}]: 882 caps, 15 pattern sets,
  minimal unsat sets exactly the claimed 5; ABC never needed.  NEW: each of the 15 pattern sets has a UNIQUE colour
  count vector (e.g. {AAB,AAC,BBC}->(4,2,1), {AAB,..,ABC,BBC}->(3,3,1)), so the full Fano criterion for one type per
  class is a 15-row table: Fano iff some row has all patterns allowed AND n_A a_i+n_B b_i+n_C c_i <= 4x_i for all i.
* w9_ref_heavyparts0brk_random.py: exact brute force (3^7 maps) vs claim (pencil level) vs 15-row table (full).
  seed1 N=300: 0 mismatches either way; 1 totals-killed instance (tau*=.21).  More seeds + climb running.
## [heavyparts#1] entry 1 -- FINDINGS + VERDICT: CONFIRMED_WITH_FIXES (fixes are scope/edge-case wording only)
* Hand audit. (i) Light part j (every type in C has a_j <= 4x_j/7): row <= 4x/7 <= x, line (=pencil in the dual labelling
  used by heavylib) sums <= 12x/7 <= 2x, total <= 4x; all non-strict, equality allowed.  Only the 'if' direction of
  Lemma 7.63 is needed, and even that can be bypassed: the homogeneous parent construction (7 classes of mass x/7,
  every row load 4x/7, total x) + row trimming realises ANY 7 light loads (note Thm P proof, l.97 + trimming l.391).
  Per-part independence of realisations makes Fano(C,x) <=> Fano(C|H,x|H) both ways (restriction; lift = any preimage,
  repeated rows allowed).  (ii) tau*: from note l.84 (u free iff no a <= u).  If u_H is free for C|H then (u_H, x_L) is
  free for C, so sup_C >= sup_{C|H} + X_L, i.e. tau*(C) <= tau*(C|H).  Matches the blocking-map proof (light caps = x_j).
* Script w9_ref_heavyparts1_check.py [exact Fractions, own Fano labelling, own tau*]; logs _s0/_s1: 240 random families
  (p=3,4; |H|=1..3; 3 types; 216 Fano / 24 Fano-free): Fano(C)==Fano(C|H) 240/240, lifted reduced tuples verified in the
  full model, light-trace resampling invariance 240/240, tau*(C|H) >= tau*(C) 240/240 (strict in 94), 8418 constructive
  light-part realisations OK; float HiGHS LP reproduces the 7.63 min-mass formula on 300 random loads (0 mismatches).
* FIX 1 (edge case, dropped side condition): a type with ZERO H-trace (everywhere 4/7-light = homogeneous) has no
  H-valued blocking map; C|H contains the zero vector, has NO free residual, tau*(C|H) = +infinity (sup of empty set).
  'Only increases' holds only with that convention; the reduced model is then degenerate (but such C has a Fano tuple
  directly).  Example: x=(1,1,1), (4/5,1/10,1/10),(0,1/2,1/2): tau*(C)=7/10, tau*(C|H)=+inf.  State 'assume no
  homogeneous type' or adopt the +inf convention.
* FIX 2 (scope): the invariance is FANO-ONLY.  Two-type (non-Fano) bad tuples are NOT light-part invariant (V needs
  a_j+b_j <= x_j at light parts).  Exact example x=(6/5,6/5,19/60), (41/50,0,9/50),(0,41/50,9/50): part 3 light for both;
  full model: 0 of the 42 catalogue functions feasible (any ordered/equal pair), no Fano; reduced model: 60 feasible.
  So 'reduced model' may be used for Fano questions and for the tau* lower bound only, never for FP/pair questions.
* FIX 3 (usage caveat): the reduction is one-way and lossy.  Same example: tau*(C)=41/300 but tau*(C|H)=19/25>3/4, and
  C|H is Fano-free.  So 'reduced instances with tau*>3/4 have Fano tuples' is FALSE (also W-type), i.e. a proof of a
  Fano statement on the reduced model must use more than tau*(C|H)>3/4; and reduced types are sub-stochastic, so
  results assuming sum=1 (e.g. 'Sigma u<1 => free', tau* <= X-1) do not transfer to C|H.
* Novelty: essentially the templates agent's M1 (templates_handproofs.md l.263, 'light-safety') + an elementary
  tau* monotonicity; the note has the homogeneous 4x/7 construction (l.87-97) and Lemma 7.63 but no explicit
  light-part reduction (grep 'light part|reduced model|substochastic': none).  Bookkeeping corollary, correctly labelled.
## [templates#0] (BREAK-IT) resume after usage-limit reset (24 Sep): FINAL REPORT above stands. Re-ran
  w9_ref_templates0_gappair_fm.py (all 64 failure systems infeasible; sensitivity unchanged: drop G -> 64 open,
  G-1/1000 -> 59 open); tt_milp p4 gamma*=0, p5 6e-13 (NUMERICAL); tt_rand5 0 counterexamples. Verdict unchanged:
  CONFIRMED_WITH_FIXES (F1 H nonempty via N>=7/4; F2 Remark (c) label; F3 a<=b unneeded, G sharp; F4 'fully human'
  needs handback 8.4 hand version; F5 update handback 8.4 sentence). Also: TT step (4) slack is >3/8 not >1/8.
## [typeclosed#1] (BREAK-IT lens) entry 3 -- RESUME after usage-limit reset (24 Sep)
* Re-read own entries + FINAL VERDICT above. Checked all brk logs are complete (FINAL lines present for mix/super/edge x
  seeds 21,22; big-family total 4901+4931+4294+4269+1113+1192 = 20700 matches the verdict; brk_fm.log ends DONE).
  No background jobs still running. Verdict unchanged: CONFIRMED_WITH_FIXES.

## [typeclosed#2] entry 4 -- RESUME after usage-limit reset (BREAK-IT lens, 24 Sep)
* Re-ran w9_ref_tc2_literal_a.py (literal-(a) counterexample: tau*=1, Q_b/Q_a fail, ell light everywhere -> homogeneous
  Fano valid, V(a,b) valid) and w9_ref_tc2_example.py (unbalanced family, tau*=31/40, REMARK side condition fails in both
  orientations, 9 V pairs work): both reproduce exactly. Logs resid/unbal3/lemU consistent (0 mechanism failures).
  FINAL VERDICT above (CONFIRMED_WITH_FIXES) stands unchanged.
## [typeclosed#1] entry 3 (LOGIC lens, resumed after usage-limit reset, 24 Sep): re-ran w9_ref_typeclosed1_fm.py (2 s)
##  and w9_ref_typeclosed1_Lnecessity.py -- output identical to the logged certificate (0 feasible negations in all 4
##  GGP/GGP-mass versions; mutations 27/36/59/59/18,24/18; L-pair-clause necessity example reproduced). e2e logs s2..s5
##  intact. Bookkeeping: entry 1 cites 'w9_ref_typeclosed1_supports.py' -- no such file; that support check is inside
##  w9_ref_typeclosed1_e2e.py (first two log lines), and the BREAK-IT referee's is w9_ref_typeclosed1brk_supports.py.
##  Verdict unchanged: CONFIRMED_WITH_FIXES.
## [typeclosed#0] entry R (resume after usage-limit kill, 24 Sep). The FINAL REPORT above was already written. I re-ran
##  w9_ref_typeclosed0_sym.py and _special.py: both PASS. e2e logs R24 s11/s12 and R40 s13/s14 finished with 0 failures;
##  the mutation logs s15/s16 show the expected failures. I re-derived (1)-(3) and both identities by hand once more: correct.
##  The verdict stands: CONFIRMED_WITH_FIXES. Report returned.
## [typeclosed#0] (BREAK-IT) entry 3 -- RESUMED after usage-limit kill (24 Sep). Re-read final verdict above; re-checked
##  all brk logs (e2e2 gen/mass/p2/super/superonly s11,s12; thmL s21-23): zero failures, counts as recorded. climb2 hits
##  with score 0.0 are x_3=0 degenerate instances where a template is feasible at equality (viol=0 means feasible) --
##  NOT counterexamples. Re-verified both part-k identities by hand expansion once more. Verdict unchanged:
##  CONFIRMED_WITH_FIXES (F1 novelty = templates H2; F2 strict tau*; F3 hand V masses; F4 'closed' unused). DONE.
## [templates#1] (BREAK-IT lens, third referee) entry 0 -- START 24 Sep. Prior two referees (line-by-line) CONFIRMED; my scripts will be w9_ref_templates1brk_*.py. Plan: hand re-derivation; independent exact tau* (brute residual / LP over finite type sets); exact Venn realisation; adversarial search for edge cases (boundary 4x/7 ties, g_I=1, |g|=1, x_i<1 parts, p large, degenerate generators, U(g) with g not <= x); check hidden hypotheses (definition of up-box, admissibility of canonical types).

## [typeclosed#2] LINE-BY-LINE session RESUMED after usage-limit kill (24 Sep, ~11:10) -- closing entry
* Re-ran w9_ref_tc2_literal_a.py and w9_ref_tc2_example.py: both reproduce exactly (tau*=1 literal-(a) failure with
  everywhere-light ell; unbalanced 31/40 family with REMARK hypothesis false for both minimisers, V pairs present).
* Hand re-check of the remaining one-liners: (c) lowering v_i to min(v_i, sigma_i-eps) keeps v free for C^(i) (v'<=v),
  blocks S_i (c_i>=sigma_i>v'_i), cost increase <= x_i-sigma_i+eps = e_i+eps; needs only v_i<=x_i. x_i<3/2 (strict):
  x_i>=3/2 => S_i empty (c_i<=1<=2x_i/3) => C^(i)=C, contradicting E+ (p=3). N>9/4: needs 'every type super-heavy
  somewhere' (the pencil-lemma step of L+), then the sigma-corner is free, sum e >= tau* > 3/4, x_m >= 3e_m.
  (a) 'exactly one': c super-heavy at both j,k => c_j+c_k > 2(x_j+x_k)/3 > 3/2 > 1.
* Novelty re-grep: note sec 7.57 (l.1614) already has 'every 2-colouring of the Fano plane has a monochromatic line'
  used with part-colouring; no super-heavy/E+/excess-bound in note_644.md.
* Verdict unchanged: CONFIRMED_WITH_FIXES (see FINAL VERDICT entries above).
## [templates#0] (LINE-BY-LINE, resumed session 24 Sep after usage-limit reset) FINAL CONFIRMATION.
  Re-read templates_handproofs.md secs 0-3 and re-derived every inequality again from scratch (TT Lemma 0,
  steps 1-4; Gap-Pair P1,P2, Q_b/Q_a facets in both parts, R1,R2, all four V facets incl. the "subtract x<3b/2"
  step; 7.75' residual costs x-l and N-1-(b-a); sec.3 claim 1-th_B<=x_A (3/4-9x_A/28) and the Gap-Pair map
  a'=1-th_B, b'=th_A).  No new issue.  Note sec.3 uses only the easy direction tau*<=d_A+d_B (a valid residual),
  so it does not depend on the exact 8.4 tau* formula.  Re-ran: w9_ref_templates0_gap.py (64/64 systems closed,
  7.75' e2e 0 failures), w9_ref_templates0_support.py (PASS), w9_ref_templates0_gappair_fm.py (CERTIFICATE;
  a<=b droppable, G sharp), tmpl/verify_hand_identities.py (ALL IDENTITIES VERIFIED).
  Verdict unchanged: CONFIRMED_WITH_FIXES (F1 H nonempty via N>=7/4 in 7.75'; F2 '>1/8' is '>3/8'; F3 'fully
  human' conditional on the handback's hand 8.4 for |I|>=3; remark (c) label W(x,s) is notes_core's family,
  note Prop 7.55 is the 4/5 instance; sec.3 writes tau*>3/4 though >=3/4 works).
## [templates#1] entry 3 -- RESUME after usage-limit break (24 Sep). FINAL REPORT above stands.
  Re-checked sec.4 by hand once more (F1, F2, admissibility, Q facets via (K2')(i,J) alone, K!=I, L!=J, K!=L,
  g_L+h_K>3/2, all four V cases incl. K=J via a_K<=1-a_L, and i=L inside 'i!=K,J' via a_L<=1). No change.
  Logs: e2e s11-13, climbs s1-s2, grids p2D28/p3D12/p3D14/p4D6/p4D7/p5D4/p6D3 all PASS. p2 D84 grid log is EMPTY
  (run was killed, never finished) -- not needed (p=2 is note 7.75; D28 exhaustive passed). Verdict: CONFIRMED.
## [templates#2] (BREAK-IT) entry 3 -- RESUMED after usage-limit reset (24 Sep). Re-read own entries 0-2 + FINAL VERDICT.
##  All brk logs complete (grid s11/s12, rand s21/s22, V s31/s32, W s41/s42 end 'ALL CHECKS PASSED'; the only nonzero
##  'fail' counters are the intended mutations: mut_b0 35+89 in V-focus, mut_low_tau, mut_QinC). Fresh-seed smoke rerun
##  (seed 77, V focus, 1500 rand + 20 grid + 2 climbs): ALL CHECKS PASSED; note779 check reproduces (168 <=2-heavy
##  subfamilies, max tau* 33/64). Extra hand check: 'C_2 empty => tau*<=d_1<3/4' also needs x_1<7/4, which holds since
##  a type heavy at 1 has 1>=t_1>4x_1/7. Verdict unchanged: CONFIRMED_WITH_FIXES.
## [randomside#2] entry 0 -- START (referee w9, 24 Sep, lens LINE-BY-LINE LOGIC). Claim: Theorem 1* (H_rho, all N, rho).
##  Plan: re-derive reduction (size lemma + monotone coupling), Lemma F (lazy Fano, |F_j|<=15m, heavy fraction, union
##  bound, arithmetic), Lemma P (Janson constants), regime overlap; scripts prefixed w9_ref_randomside2_.
## [randomside#2] (BREAK-IT lens) entry 0 -- START 24 Sep. Separate from the LINE-BY-LINE referee above. Scripts
##  w9_ref_randomside2brk_*.py. Plan: (1) exact small-case tests of the size lemma + coupling; (2) attack Lemma F:
##  |F_j|<=15m claim, 'good k-sets >= C(N-15m,k)/2', union bound, arithmetic with exact lgamma; (3) Lemma P Janson
##  constants; (4) regime overlap (independent scan incl. small s, T=ceil(3k/4) vs (3/4+eps)k); (5) regime (a) dependency.

## randomside#0 (size lemma + monotone coupling) -- referee checkpoint 1 (24 Sep 2026)
Hand re-derivation: (i) OK (u=N-T+D<=N needs D<=T; u>=k automatic when tau>=T is possible since tau<=N-k+1).
(ii) OK with P(L) read as P(ceil L); Markov Pr[M'>=L]<=1/2 needs rho'<=1, true since L<=|H|<=C(N,k) when a
family with tau>=T exists. Downstream [c6] choices D=floor(N/k) (only if N<=Tk) and D=T respect D<=T.
Exact script launched: randomside2/w9_ref_randomside0_check.py (log .log alongside).

## [randomside#0] (LINE-BY-LINE) Size lemma + monotone coupling -- 24 Sep. VERDICT: CONFIRMED_WITH_FIXES (cosmetic only)
* (i) re-derived: u=N-T+D, E e(S)=|H|C(u,k)/C(N,k); S' = S minus one vertex per inside edge is independent, so
  [N]\S' is a transversal: tau <= N-u+e(S) = T-D+e(S); tau>=T => e(S)>=D => |H|>=D C(N,k)/C(u,k). Correct.
  Side condition: C(u,k)>0 needed. Automatic whenever the hypothesis is non-vacuous (tau<=N-k+1 => T<=N-k+1 => u>=k);
  if T>N-k+1 the hypothesis is empty and L must be read as +inf. D=1 is the Turan covering bound (C(N,u)/C(N-k,u-k)=C(N,k)/C(u,k)).
* (ii) re-derived: conditional on M=m, H_rho is a uniform m-subset; (m+1)-set minus a uniform element is a uniform
  m-set and (7,2) is hereditary (either reading of "every 7 edges") => P nonincreasing. L may be non-integer:
  P(L) must mean P(ceil L). Markov actually gives Pr[M'<L]>=1/2 (stronger than stated). rho'<=1/2 automatically since
  L<=min{|H|:tau>=T}<=C(N,k) in the non-vacuous case.
* CERTIFICATE (small-case exact): w9_ref_randomside0_size_coupling.py -- (i) vs exact Turan minima (MILP) for k=2..4,
  N<=9 (k=4: N<=8), all T: 0 violations (e.g. k=3,N=8,T=4: L=5.6, exact 8). (ii) exact P(m) for K_5^(2), K_6^(2), K_5^(3)
  by hereditary DP: P nonincreasing; Pr_rho[(7,2)&M>=L]<=P(ceil L)<=2Pr_rho'[(7,2)] for L in (1/4)Z, 39 rho's: all hold.
* Novelty: both parts are textbook (alteration/deletion method, Alon-Spencer ch.3; G(n,p)<->G(n,M) monotone
  equivalence, JLR sec.1.4). Not in note_644.md (only random construction there is l.289, a union bound for the
  3k/4 lower bound). Useful bookkeeping, not new mathematics. Scope: statement concerns H_rho only.
## [heavyparts#0] (LINE-BY-LINE) entry R -- RESUMED after usage-limit reset (24 Sep). Re-ran w9_ref_heavyparts0_arc.py
##  (882 / 15 / 78 hitting sets / same 5 minimal sets; random exact test 333 conflict all Fano-free, 673+3 no-conflict,
##  the 3 totals-killed instances reproduced incl. x=(57,26,28)) and w9_ref_heavyparts0_multi.py (two conflicting rep
##  triples, mixed Fano tuple (a1,a1,a2,b,c,b,c), totals 148/106/166 <= 184/180/192, tau*=5/12). Verdict unchanged:
##  CONFIRMED_WITH_FIXES (F1 'iff' only modulo per-part totals, stated as: conflict => Fano-free; no conflict =>
##  Fano iff some conflict-free arc colouring meets all 4x_i totals; F2 multi-type lift over classes FALSE; F3 novelty small).

## [randomside#1] entry 0 -- START (referee w9, lens LINE-BY-LINE LOGIC, 24 Sep). Claim: Typed Janson Lemma (TJ).
##  Hand pass done: Janson (JLR 2.14, t=mu; repeated index sets OK), E[I_A I_B]=rho^{2j-|J|}, Ext constancy by
##  Sym(N)-transitivity on realisations of a marginal type, double count mu = P_{s(J)} Ext rho^j, K_j excludes s=0
##  (K_5 = 1546-1 = 1545 checked).  All correct.  ISSUE to test: 'extra data' (quartering of role-0 set E) --
##  marginals MUST be the unrefined set-Venn types; refined marginals are wrong (j=1 counterexample planned).
##  cert_tc_janson.py uses unrefined (merges quarters): consistent.  Novelty: note has no Janson; lemma is the k-set
##  analogue of JLR Thm 3.9 (Phi_G), routine but correct.  Scripts: w9_ref_randomside1_*.py (planned).

## [randomside#1] (BREAK-IT lens) entry 0 -- START 24 Sep. Separate from the LINE-BY-LINE referee above. Scripts
##  w9_ref_randomside1brk_*.py. Plan: (1) exact enumeration of Dbar vs the bound mu^2 K_j/min mu_J on small (N,k,j,Y),
##  incl. types with extra data (chosen quartering) and adversarial types (tiny/zero cells, near-equal roles);
##  (2) exact Pr[X=0] by enumerating all subfamilies of K_N^(k) (tiny N) vs exp(-min mu_J/(2K_j)); (3) mutations:
##  refined marginals (with quartering), FIXED (global) extra data, K_j without sigma -- show each breaks;
##  (4) E_J asymptotics (Stirling direction, rho vs psi) used in 'significance'.
## [templates#1] (BREAK-IT) entry 1 -- checkpoint. Hand re-derivation of sec.4 (every inequality): correct; agrees with
  the two earlier referees (Lemma 0 at I,J redundant; g_I=1 parenthesis unneeded).  NEW complete search:
  w9_ref_templates1brk_milp.py = ROLE-REDUCED MILP (valid for ANY p): keep only role parts {I,J,K,L,M} under all 52
  set partitions (+2 admissibility systems), lump other parts into g_rest,h_rest>=0, keep every (K1'),(K2') among
  roles (conditional on positivity via binaries), drop the rest (relaxation), WLOG x<=2; maximise the strict margin.
  Log w9ref_logs/w9_ref_templates1brk_milp.log: THR=3/4 -> eps* = 1e-6 (= HiGHS tolerance; solutions have eps=0):
  NO counterexample in the relaxation.  Sensitivity: THR=0.74 -> eps*=5.7e-3 (fails); drop V -> 1/8; drop Qa ->
  0.0526; drop Qb -> 0.0909; fill at own heavy part -> 0.15.  [NUMERICAL, complete over all reals and all p]
## [heavyparts#0] BRK entry 1 -- RESUMED after usage-limit reset (24 Sep). Logs of entry 0 intact: random s2/s3 (p=3)
##  and s4 (p=4): 0 mismatches for the claim (pencil level) and for the 15-row full table; totals-killed instances
##  exist but have tau* .43/.37. Climbs s11-s22 (maximise tau* over totals-killed no-conflict families) sit on the
##  boundary; refine from the best float start (s11 r7, tau* .763) collapses to margin 0 at tau*=3/4 exactly
##  (log w9ref_logs/heavyparts0_refine_s1.log). Next: exact MILP (w9_ref_heavyparts0brk_milp.py) for
##  sup tau* over totals-killed no-conflict one-type-per-class families -- does the totals caveat ever bite above 3/4?
## [randomside#1] entry 1 -- scripts run.  w9_ref_randomside1_exact.py (.log): all Venn types, (N,k,j) up to (7,3,3):
##  (a) #tuples = multinomial, (b) Ext constant & P_J*Ext = #tuples, (c) exact Dbar <= mu^2 K_j/min mu_J (and finer
##  per-(J,sigma) form), (d) exact Pr[X=0] <= Janson <= TJ bound: ALL PASS (j=1 tight: ratio 1).  Mutations
##  (w9_ref_randomside1_mut.py/.log): dropping marginals (M1) or K_j=j! (M2) violate the Dbar step -> checker has power.
##  Asymptotics: |ln mu_J - k E_J| ~ 2 ln k for a sample 3-role type (O(ln k), as needed).
##  EXTRA DATA (w9_ref_randomside1_extra.py/.log): two readings.  E1 decoration on a random role (quartering of role
##  0): unrefined set-marginals correct, refined marginals FALSE (Pr=0.5 > e^{-6}).  E2 fixed external structure on
##  [N]: marginals must be refined by it (unrefined FALSE: 0.5 > 0.223).  cert_tc_janson.py = E1 with unrefined
##  marginals: consistent.  => wording fix only.  Verdict leaning CONFIRMED_WITH_FIXES.
## [randomside#2] entry 1 -- hand re-derivation (line by line), before scripts.
* Reduction: size lemma (random u-set, u=N-T+D, delete one vertex per edge) OK; monotone coupling OK
  (Pr_rho[(7,2)&|H|>=L] = sum_{m>=L} Pr[|H|=m]P(m) <= P(ceil L); Markov Pr_{rho'}[Bin>=L]<=1/2). Formal gap G1: for
  |H|<7 '(7,2)' is vacuous/ill-defined; Lemma P's 3 disjoint edges need |H_{rho'}|>=7 (Pr[<7] = e^{-Omega(k)}); Lemma F
  produces 7 distinct edges (pairwise meets <= m < k) so is fine.
* Lemma F: F_j subset U_{a<b<j} G_a&G_b correct (<=1 earlier line + l_j covers <=5 points); <=C(6,2)=15 pairs, so
  |F_j|<=15m; end-game (point p(x) off sigma(x); line through p(x),p(y)) correct. Heavy count
  C(k,m+1)C(N',k-m-1)/C(N',k) <= (ek^2/((m+1)(N'-k)))^{m+1} correct; m+1 >= 2e^2 s + 2 gives base <= N/(2e(N'-k)) <= .1844,
  so <= .034 already for exponent 2 (actual exponent >= 2e^2 ln k). Union bound sum_j C(N,k)^{j-1} <= 7C^6 fine (union over
  all deterministic histories; adaptivity irrelevant). Arithmetic chain re-derived: ln(rho'C(N-15m,k)/2) >= ln D + T k/N
  - kD/N - ln4 - 15mk/(N-k-15m); 15m <= 221.7 s^2... ok; at s=ln k needs ln k >= 31 (hand), fine asymptotically.
  The '+ e^{-T/2}' term has no source in the argument (harmless slack; flag as unexplained).
* Lemma P: Dbar = mu(1 + 3 a2 + 1.5 a1) re-derived (share 2 sets: 3 C(N-2k,k) rho; share 1: 3 C(N-k,k)C(N-2k,k)/2 rho^2),
  JLR 2.14 at t=mu, 1+3a2+1.5a1 <= 5.5 max => exponent (1/11) min(mu, mu/a2, mu/a1) with mu/a2 = M'^2 q1/6,
  mu/a1 = M'/6. Case N<=Tk (NOT vacuous: k^2/ln k < Tk): M' >= (k/s-1)e^{.75s-1}/2, min over s in [4/3, ln k] at s=4/3
  gives M' >= ~.375k => exponent >= k/176 >= k/400. Case N>=Tk: D=T, M'>=T/2, q1>=e^{-1.4}, q2>=e^{-2.8}. OK.
* Game certificates: cert_near2 algebra (zH(m/z) >= m ln(z/m)+m-m^2/z; psi(1+d) <= d ln(1/d)+d+d^2; sum s0=1 so
  L(sigma-1) = kappa sum s1) re-derived OK; one quad per group for j>=3 checked by hand (pencil traces distinct).
  cert_mid chaining (concavity of V_order, tangent of concave psi) OK. Hand proof n>=4.75 (proportional greedy,
  forbidden set <= 3 pairwise intersections each <= 1/a_b) OK.
## [randomside#1] entry 2 -- FINAL. exact run complete incl. j=4 ((7,2,4): 69 types, (6,3,4): 198 types) -- all PASS.
##  VERDICT: CONFIRMED_WITH_FIXES.  Proof correct line by line (Janson JLR 2.14 at t=mu; repeated index sets harmless;
##  rho^{2j-|J|}; Ext constant by Sym(N) transitivity; P*Ext*rho^j = mu; K_j over (J,sigma), J nonempty; J=[j] term
##  = mu).  FIXES (wording): (F1) 'extra data' must be a Sym(N)-equivariant decoration of the tuple (e.g. quartering of
##  a ROLE's set, chosen per object); then mu_J uses UNREFINED set-Venn marginals (refined -> false, E1).  A fixed
##  external structure on [N] is a different situation: replace Sym(N) by its stabiliser and refine marginals by it
##  (unrefined -> false, E2).  (F2) mu_J := (#|J|-tuples of distinct k-sets of [N] with the set-Venn marginal type
##  Y^J) rho^{|J|} = N!/prod m_T! * rho^{|J|}; mu_{[j]} is the unrefined full-type count, which may be < mu when
##  decorations are present (fine: it is what the proof needs).  (F3) 'existence from positive E_J' needs
##  min_J E_J > c > 0 with integer rounding and ln mu_J = k E_J + O(2^j ln k) (checked ~2 ln k for a 3-role type).
##  Novelty: note has no Janson; lemma is the k-set analogue of JLR Thm 3.9 (standard technique), new to project.
## [randomside#2] (BREAK-IT) entry 1 -- hand re-derivation done (no break yet).
##  Re-derived: coupling (P(m) nonincreasing; Markov median), size lemma, Lemma F (F_j within pairwise intersections:
##  <=2 lines never cover PG(2,2); unsafe <=> contains a pencil; heavy fraction with m+1>=3 is <=0.18437^3=0.0063);
##  union bound over histories; P's Janson Dbar = mu(1+3a2+1.5a1) and 2(1+3a2+1.5a1)<=11max(1,a1,a2) (all exact);
##  proportional-greedy hand proof n>=4.75; cert_mid chaining (concavity of e_j (perspective of H), tangent of psi).
##  OBSERVATION: sparse_regimes.py F-check uses minimal m, target e^{-k/100}, NOT the claim's m=ceil(2e^2 s)+1 and
##  e^{-k}; and for k<=1000 F never succeeds (F-range [600k,k^2/ln k] is empty for k/ln k<600) -- the numeric
##  'overlap check' is carried by P (exact Janson evaluation) except at k=1e5. Writing exact check of the stated constants.
## [randomside#1] (BREAK-IT) entry 1 -- exact tests DONE (randomside2/w9_ref_randomside1brk_dbar.py/.log, _prx0.py/.log)
##  T1 per-(J,sigma) inequality c_{J,sigma} <= C_Y^2/P_{sigma(J)} (exact integers; = rho-free form of the proof's key step):
##   0 failures over 17 (N,k,j,extra) cases, N<=7, j<=4, all exact types incl. chosen extra data Q subset A_0 (|Q|=1,2);
##   max ratio exactly 1 (tight at J=[j], sigma=id).  T2 Dbar <= mu^2 K_j/min mu_J on a rho grid: 0 failures.
##  T5 exact Pr[X=0] (all subfamilies of K_N^(k), N<=6) vs exp(-min mu_J/(2K_j)) and vs raw Janson: 0 violations (11 cases).
##  MUTATIONS (must break, do break): M1 REFINED marginals (J-part carries the extra data): T1 fails (e.g. 246 pairs at
##   N=6,k=3,j=3,|Q|=1); final bound FALSE: j=1, config (G,Q subset G,|Q|=2), N=5,k=4,rho=.1: true Pr[X=0]=.5905 >
##   refined bound e^{-1.5}=.2231.  M2 FIXED (global) extra data Z with marginal forgetting Z: j=1, N=6,k=3,Z=3-set,
##   |G&Z|=3, rho=1/2: true Pr[X=0]=1/2 > e^{-5}=.0067.  M3 K'_j=2^j-1 (no sigma): Dbar bound fails in every case.
##  => the lemma is correct AS PROVED only with (a) extra data CHOSEN as part of the configuration (existential), and
##     (b) mu_J = UNREFINED counts of the random sets' J-parts (orbits under Sym(N)); fixed global data needs orbits
##     of Stab(data). Statement's 'non-random extra data such as a quartering of E may be included' must say this.
## [heavyparts#1] (LINE-BY-LINE) entry R -- RESUMED after usage-limit reset (24 Sep). Re-read note Lemma 7.63 (l.1782:
##  rows <= x_i, Fano-line sums <= 2x_i, total <= 4x_i, per part, iff). Re-ran w9_ref_heavyparts1_check.py with FRESH
##  seed 2 (N=150): all asserts pass (131 Fano / 19 Fano-free; Fano(C)==Fano(C|H) 150/150; tau*(C|H)>=tau*(C), strict
##  in 55; 5382 constructive light realisations; LP 7.63 cross-check 0/300 mismatches); FIX-1/FIX-3 examples reproduce
##  (7/10 vs +inf; 41/300 vs 19/25). Hand re-check of FIX-3: part 3 light since 9/50 <= 76/420; Fano-free in both
##  models because a line of three a-rows needs 123/50 <= 12/5 (false), same for b, and every 2-colouring of the Fano
##  plane has a monochromatic line.
##  ADDITIONAL WORDING GAP (proof of the tau* part): the proof says 'every H-valued blocking map of C is still a blocking
##  map after deletion'. That is the inclusion that does NOT give the inequality. tau*(C|H) >= tau*(C) needs the reverse
##  inclusion: every blocking map of C|H (necessarily H-valued, since it must pick a part with positive trace) is a
##  blocking map of C, with the same cost because light parts are unused (cap x_j, cost 0) and X_C - X_{C|H} = X_L.
##  Both inclusions are trivial, so the two sets are in cost-preserving bijection and the result holds. Only the
##  sentence needs fixing.
##  FINAL VERDICT unchanged: CONFIRMED_WITH_FIXES (F1 zero-H-trace/homogeneous type -> +inf convention; F2 Fano-only
##  scope, pair/V questions NOT light-invariant; F3 one-way lossy, reduced types sub-stochastic; F4 proof sentence
##  cites the wrong inclusion). Novelty: = templates M1 'light-safety' + trivial tau* monotonicity; not in note.
## [randomside#1] (BREAK-IT) entry 2 -- FINAL. VERDICT: CONFIRMED_WITH_FIXES (fixes = scope wording; no counterexample
##  to the lemma as proved).  Extra checks (randomside2/w9_ref_randomside1brk_sig.py/.log): (a) exact ln N!/prod M_T! is
##  below k*E_J by O(#cells ln k) (e.g. -35 at k=1e5 with 8 cells), type-class lower bound holds => 'significance' needs a
##  FIXED margin E_J >= delta > 0 and k >= k0(delta, #cells) (with the staircase margin 1e-4 and up to 64 cells, k0 is
##  astronomically large but finite); (b) ln C(xk,k) <= k psi(x) (right direction for rho >= 1/C(xk,k)); (c) the 4
##  certified TC types have all 10 role pairs distinct (min symmetric-difference mass >= 1.0); symmetric Fano types
##  always have distinct lines (each line is in 2 quads missing any other line).  Hand: Janson (JLR 2.14, t=mu) is valid
##  for repeated index sets (Harris/Laplace proof never uses distinct Gamma_A); K_5=1545, K_7=130921 (s>=1).
##  FIXES: F1 'extra data' must be CHOSEN with the configuration (X counts (tuple,data) pairs) and mu_J must be the
##  UNREFINED counts of J-parts of the random sets (Sym(N)-orbits; for J=[j] this is the tuple count, < mu when data
##  has multiplicity).  Refined marginals or FIXED global data (with Sym(N) marginals) make it FALSE (M1, M2 above).
##  cert_tc_janson.py/tc_janson.py do it right (quarters merged).  F2 significance: positivity with uniform margin, k>=k0.
##  NOVELTY: none in note_644.md (grep 'janson': 0 hits); mathematically the k-set/typed analogue of JLR Thm 3.9
##  (Pr[G(n,p) has no copy of G] <= exp(-Theta(Phi_G)), Janson-Luczak-Rucinski 1990) with an explicit constant. Routine.
## [randomside#2] entry 2 -- scripts + FINAL VERDICT: CONFIRMED_WITH_FIXES (fixes are bookkeeping/wording only)
* w9_ref_randomside2_arith.py (mpmath dps 60, claim's own m, D, T; log w9_ref_randomside2_arith.log): Lemma F exact
  inequality (15m<=.4k, heavy<=.034, rho'C(N-15m,k)/2 >= 6lnC(N,k)+ln7+k) holds on all of [600k,k^2/ln k] for
  k = 1e6..1e16 (worst margin at N ~ k^2/ln k: +1.0 at k=1e6, +16.3 at 1e16) but FAILS near N=k^2/ln k for k=1e4 (-3.5),
  1e5 (-0.6). The hand-simplified condition at s=ln k fails at k=1e13 (-0.012), holds at 3e13 (ln k=31.03, +0.33):
  the stated 'ln k >= 31' is exactly right. Lemma P: ln(J/(k/400)) = +2.12 uniformly (J ~ k/48) on [k^2/ln k, 1e8 k^2].
* w9_ref_randomside2_reduction.py (EXHAUSTIVE, exact Fractions; log ..._reduction.log): all families on (N,k) =
  (5,2),(6,2),(5,3),(6,3): size lemma, P(m) monotone, Pr_rho[(7,2)&tau>=T] <= P(ceil L) <= 2Pr_{rho'}[(7,2)] for every T
  and rho in {1/20..19/20}: 0 violations (max ratio 0.50). Janson: exact Dbar <= mu(1+3a2+1.5a1) and exact
  Pr[X=0] <= Janson bound at (6,2); Dbar inequality at (7,2),(9,3) (Pr[X=0] printed as 0 there = NOT computed, nE>20).
* w9_ref_randomside2_lazyfano.py (own Fano labelling; log ..._lazyfano.log): safe-set census 1,7,21,28,7; 1154 random lazy
  constructions: F_j inside union of pairwise meets, |F_j|<=15m, final 7-tuple never 2-pierceable; mutation without
  F_j-avoidance gives 206 pierceable tuples (test has power).
* w9_ref_randomside2_game.py: cert_near2 strategy re-evaluated with own quad solver/entropy code at d=0.03..1e-75:
  min_j e_j - psi(1+d) = d*(0.155..0.2000) > 0 (cert's interval bound 0.118 is consistent); proportional greedy on
  sampled triangle-first orders, n in [4.75,200]: min_j a_j - (n-3/4) >= 0.1357. cert_mid start point total is
  1.78 - 5e-10 (no gap with cert_near2's d<=0.03).
* FIXES/REMARKS: (R1) Lemma P needs |H_{rho'}|>=7 to turn 3 disjoint edges into a bad 7-set unless '(7,2)' for |H|<7 is
  read as '2-pierceable'; add Pr[Bin(C(N,k),rho')<7] <= e^{-Omega(k)} (probably the unexplained e^{-T/2}). (R2) the
  e^{-T/2} term in Lemma F has no source there. (R3) 'overlap checked numerically k=500..1e5' refers to sparse_regimes.py,
  whose targets are weaker (exponent k/100, optimised m) than the hand statement (exponent k); with the hand constants F
  starts to hold only from k~1e6 -- irrelevant for the asymptotic theorem, but the sentence should say so. (R4) the
  sub-case N<=Tk of Lemma P is the operative one on [k^2/ln k, 3k^2/4] (not vacuous); its bound M'>=~.375k at s=4/3
  holds. (R5) factor-2 bookkeeping of the coupling in (b),(c) is loose but every regime gives <= 2/k for k>=k_eps.
* NOVELTY: note has only Lemma 7.5 (random subfamilies of K_{7k/4-1}, a richness-type union bound, opposite purpose);
  no theorem that H_rho above (3/4+eps)k is whp not (7,2). New relative to the note. Significance modest: random-like
  families are not extremal candidates; superseded in strength by Theorem 1-static ([c10]-[c11], additive constant).
## [heavyparts#1] BRK entry 1 -- RESUMED after usage-limit reset (24 Sep). Found my earlier logs: brk_exact s11-s14
##  (1000 exact instances, thr 4/7): A_fail=0 (assignment-level full==H-only over ~5.15M assignments), B_fail=0,
##  M1/M2 tau* methods agree everywhere; mutation power: thr 29/50 -> 2677 A_fails, thr 2/3 -> 13379 A_fails.
##  Now running w9_ref_heavyparts1brk_lift.py (lossless lift / non-Fano scope / integrality).
## [heavyparts#2] BRK entry 1 -- RESUME (referee w9 BREAK-IT, 24 Sep, after usage-limit restart).  Found prior
##  scripts in w9_ref_heavyparts2/ (supports, fm, fm2, e2e; logs: 0 counterexamples, Lt probes empty) but no verdict.
##  Hand re-derivation of every PCL step done: all correct.  Observation: Lt at A,B is REDUNDANT (b_A<=1-b_B<1-4x_B/7
##  < 4x_A/7 because G+H1+H2 give x_A+x_B>7/4).  Writing independent scripts w9_ref_heavyparts2brk_*.py (own strict FM,
##  LP cover re-check of V/Q, exact boundary sampling, hypothesis weakening to 2/3-light).
## [randomside#2] (BREAK-IT) entry 2 -- scripts + FINAL VERDICT: CONFIRMED_WITH_FIXES (no counterexample; gaps cosmetic)
##  w9_ref_randomside2brk_fano.py (log w9ref_logs/..._fano.log): 64 safe sets (1,7,21,28,7); unsafe<=>contains pencil;
##   <=1 prev line + l_j never covers (F_j inside pairwise intersections); any two safe sigmas miss a common line
##   (=> no 2-transversal, incl. x=y); lazy construction run on 300 explicit random families (k=3,4): 296 produced
##   7-tuples, all brute-force verified bad, |F_j|<=sum|G_a&G_b| held; heavy-fraction chain exact on k<=8.
##  w9_ref_randomside2brk_sparse.py (mpmath 300 digits, STATED constants m=ceil(2e^2 s)+1, target e^{-k}, P target
##   min(..)/11>=k/400): ln k=25,30,31,32,40,70,230: F passes on all of [600k,k^2/ln k] (worst margin +8.2 at s=ln k,
##   ln k=25), P passes on [k^2/ln k, 1e40 k^2] (worst ln(J/(k/400)) = +0.821 = ln(400/176): true rate e^{-k/176}).
##   The stated 'sufficient' condition 0.375s-0.06>=ln(77.2s)+lnln(ek) is -1.51 at ln k=25, +0.008 at 30 (crude but
##   valid; never produced a false positive).
##  w9_ref_randomside2brk_near.py: cert_near2 strategy re-implemented (own quad solve), feasible, all 7 steps evaluated
##   at d=1e-2..1e-3000 (adaptive precision): min_j e_j - psi(1+d) ~ 0.200 d > 0 (binding step 6).
##  FIXES: F1 the e^{-T/2} term in (b) has no source (bound is 2e^{-k}); F2 sparse_regimes.py does not test the claim's
##   Lemma F constants (other m, target e^{-k/100}) and F-range is empty for k/ln k<600 -> numeric 'overlap' was carried
##   by P; replace by the exact check above; F3 P under distinct-edge convention also needs |H|>=7 (Pr[Bin<=6] tiny, mean
##   >=3k/8); F4 label: (a) rests on computer certificates (cert_near2, cert_mid) + sketched rounding constant C0 ->
##   FULL_PROOF+CERTIFICATE, not pure FULL_PROOF; F5 k_eps astronomically large (overlap (a)/(b) needs c_eps k/ln k>=600,
##   c_eps ~ eps/(8(C0+3))). Novelty: note_644 has only the random-subfamily construction at N=7k/4-1 (l.289); no H_rho theorem.
## [heavyparts#2] (LINE-BY-LINE) entry 1 -- RESUMED after usage-limit reset (24 Sep). Scripts of entry 0 survive in
##  w9_ref_heavyparts2/ (supports, fm, fm2, e2e + logs). Re-ran supports.py and fm.py: identical output (exact V cover
##  = max(s+t, 5s/4+t/2), Q cover = max(3a/2, 3a/4+b), 64 violation combos all FM-infeasible, G/heavy non-strict too).
##  Hand audit done: every inequality of the notes_heavyparts proof re-derived, correct. Found: (a) Lt is REDUNDANT
##  (derivable from H1,H2,G,sums); (b) the CLAIM's condensed proof ('V facets follow from x_A>1/2+a_A/2+b_A and the
##  symmetric bound') is incomplete at B: the symmetric bound x_B>1/2+b_B/2+a_B does not give 5b_B/4+a_B/2<=x_B when
##  3b_B>2+2a_B; the notes file uses the other bound x_B>1/4+b_B+a_B/2 there (correct). Writing w9_ref_heavyparts2_logic.py.
## [heavyparts#1] BRK entry 2 -- FINAL (BREAK-IT lens). VERDICT: CONFIRMED_WITH_FIXES (no counterexample; the core statement is correct)
* w9_ref_heavyparts1brk_exact.py [exact Fractions, own cyclic Fano labelling (rows = points, constraints on lines),
  two independent exact tau* methods M1 blocking maps / M2 grid of free residuals]; logs _s11.._s14: 1000 instances
  (p=2..5, m=1..4, 35% of light traces exactly ON 4x/7, zero traces, zero/tiny capacities, sub-stochastic types):
  assignment-level Fano(all parts) == Fano(H only) on ~5.15M assignments, 0 failures; tau*(C|H) >= tau*(C) 0 failures
  (strict in 270; 45 cases jump from <=3/4 to >3/4); M1==M2 everywhere.  POWER: threshold 29/50 -> 2677 failures,
  2/3 -> 13379 failures, so the test detects any threshold above 4/7 (4/7 is exactly the pencil bound 3*4/7<=2 slack
  and the total bound 7*4/7=4 tight).
* w9_ref_heavyparts1brk_lift.py (log _lift.log) [exact]:
  (i) CLASS-LEVEL LOSSLESSNESS (new, complements the line-by-line referee's per-instance 'lossy' remark): every
      sub-stochastic reduced instance is the reduction of a stochastic one with the SAME tau* and the SAME Fano
      assignment set: add one part of capacity >= max(7/4, 1+X_H) and pad each type by 1-sum(a) (<=1<=4X_l/7, light;
      blocking there costs >= X_H so it is never used).  150/150 exact matches.  So any statement 'P(reduced) =>
      Fano' is equivalent to the stochastic statement; the reduction neither loses nor gains truth as a class.
  (ii) SCOPE (second explicit example, in addition to the logic referee's V example): note's six-versus-one non-Fano
      construction (l.2012: 6a/5+b<=x) with x=(1,3/10,1), a=(3/5,0,2/5), b=(1/5,8/35,4/7): part 3 is 4/7-light (b_3 ON
      the boundary); feasible after deleting part 3, infeasible before (6a_3/5+b_3 = 184/175 > 1); Fano sets equal (63).
      So light-part deletion is valid for Fano questions only.
  (iii) INTEGRALITY caveat: at finite scale a 4/7-light part is not automatically free: 7 rows of load 1 in a 2-point
      part (7 <= 8) have no Fano-downset realisation (3 points suffice).  Harmless in the continuous model / at
      suitable multiples, but the reduction is a continuous-model statement (O(1) rounding per part at finite k).
  Also: H3-cex tiny part C is HEAVY (1/100 > 4(3/200)/7), so it is not deletable under this lemma (as the attacker says).
* Fixes (agree with the line-by-line referee): F1 zero-H-trace (everywhere-light, homogeneous-Fano) type -> tau*(C|H)=+inf
  convention or exclude; F2 Fano-only scope; F3 proof sentence cites the H-valued-maps-of-C => maps-of-C|H inclusion,
  the inequality needs the reverse one (the two sets coincide, cost preserved, so the claim stands); F4 (new) state it
  as a continuous-model lemma (iii).  Novelty: = templates M1 'light-safety' (templates_handproofs.md l.263) + trivial
  tau* monotonicity; not in the note (note has only the homogeneous 4x/7 construction, Thm P l.87, and Lemma 7.63).
## [heavyparts#2] (LINE-BY-LINE) entry 2 -- FINAL. VERDICT: CONFIRMED_WITH_FIXES (fixes = proof-text/wording; math correct)
* Hand re-derivation (every step of notes_heavyparts ~10:45): P1 x_A-a_A > 3/4-(x_B-b_B) > 3(1-b_B)/4 >= 3b_A/4 (uses
  H1 strictly, sum_beta); P1' mirror. Q_alpha at A: 4b_A+3a_A<=4x_A <=> x_A-a_A >= b_A-a_A/4, from P1 and b_A<=a_A;
  at B 3a_B<=2x_B (Lt), 4b_B+3a_B<=4x_B (P1'); the pencil facet a+2b<=2x is implied by the other two; row facets implied.
  V(beta,alpha) at A: x_A > 1/4+a_A+b_A/2 (G,R2,sum_beta) and x_A > 1/2+a_A/2+b_A (with R1) give both facets.
  At B: x_B > 1/4+b_B+a_B/2 (G,R1,sum_alpha) gives 5b_B/4+a_B/2 <= x_B; x_B > 1/2+b_B/2+a_B (with R2) gives a_B+b_B<=x_B.
  Light parts: trivial (5/4*4/7+1/2*4/7 = 1).  All correct.
* Exact covers re-derived independently (w9_ref_heavyparts2_supports.py: all dual vertices of the fn38 support and of
  the Fano support; Fano cover == Lemma 7.63 in 3000 exact random loads): Q = max(3a/2, 3a/4+b), V = max(s+t, 5s/4+t/2)
  (s = 5-row type).  Matches the claim's facet lists.  Note Lemma 7.63 uses non-strict <=, as does the claim.
* Exact FM (w9_ref_heavyparts2_fm.py, re-run today): all 64 (Q_a facet, Q_b facet, V facet) violation combos infeasible;
  also with G non-strict and with G+heavy non-strict. Sub-claims: Q_a fails only via A1 (3a_A>2x_A), Q_b only via B1.
  Necessity: dropping H1, H2, sum_alpha, sum_beta or G each gives exact rational counterexamples (fm2.log).
* w9_ref_heavyparts2_logic.py (+.log, FM and HiGHS agree on every system):
  (i) Lt is REDUNDANT: 7b_A<=4x_A and 7a_B<=4x_B follow from H1,H2,G,sums (hand: x_B > b_B+3a_B/4 > 4x_B/7+3a_B/4).
  (ii) the lemma holds with Lt and all box constraints (a_i<=x_i) dropped.
  (iii) CLAIM-TEXT GAP (cosmetic): 'V facets at A and B follow from x_A>1/2+a_A/2+b_A and the symmetric bound' is
      false at B: symmetric bound x_B>1/2+b_B/2+a_B does not imply 5b_B/4+a_B/2<=x_B (exact witness x=(1,9/8),
      alpha=(1,0), beta=(0,1): satisfies R1,R2,H1,H2,Lt,sums and the symmetric bound, violates B2; it violates G).
      Fix: use x_B > 1/4+b_B+a_B/2 (G+R1+sum_alpha) for that facet, as notes_heavyparts.md does.
  (iv) at a 4/7-light part only V's a+b<=x can fail (witness a=b=4x/7); the lemma's light-part remark is exact.
* e2e (explicit cover functions, not the claimed formulas): 24000 random/RR/lightfree instances (entry-0 logs) + 1000
  new today (seed 7): 0 failures.
* Novelty: NOT new. Identical to templates agent's HEAVY-PAIR LEMMA (notes_templates.md l.197, with D non-strict) and a
  special case of typeclosed GGP (notes_typeclosed.md l.404: light condition max(3a/2,3b/2,a+b)<=x is WEAKER than
  PCL's a,b<=4x/7 & a+b<=x; GGP also derives Lt, step (0)). p=2 case = Gap-Pair (-> note Thm 7.75). The note itself
  has no multi-part Gap-Pair statement (grep 'Gap-Pair|Heavy-Pair|pair chain': none); ingredients = note Lemma 7.63
  + fn38/39 V support.  Attacker's own significance statement already says it duplicates Heavy-Pair/GGP: accurate.
## [templates#1] (BREAK-IT) entry 2 -- EXACT CERTIFICATE for all p.  w9_ref_templates1brk_cert.py: same role
  reduction as the MILP (roles I,J,K,L,M under all 52 set partitions + 2 admissibility systems; others lumped
  into g_rest,h_rest; only role-part (K1'),(K2') kept; note role parts automatically have x<=2 since I,J heavy
  (x<7/4) and a template failure needs x<7/4), every disjunction enumerated (positivity pattern, K1' branch,
  failing facet): 37614 leaf linear systems, EACH refuted by an exact Motzkin certificate (HiGHS -> rationalised ->
  verified in Fractions).  Log w9ref_logs/w9_ref_templates1brk_cert_34.log: uncertified 0.  => independent
  CERTIFICATE that 2UB (canonical pair, every heavy (I,J)) holds for every number of parts.  Mutation/threshold
  controls running (cert_074.log, cert_mut_*.log).
## [heavyparts#2] BRK entry 2 -- checkpoint (exact FM + sharpness)
* w9_ref_heavyparts2brk_fm.py (own strict FM, 10 Q facets incl. implied ones, 4 V facets; log in w9_ref_heavyparts2/):
  MAIN: 0 feasible failure combos (G strict and non-strict).  Q_alpha failable only via 3a_A>2x_A, Q_beta only via
  3b_B>2x_B; V failable only at {A:a+b>x, B:a+b>x, B:5b/4+a/2>x} and at NONE under R1&R2.  Orientation V(alpha,beta)
  also works (0 combos).  Lt at A,B REDUNDANT (FM: b_A>4x_A/7 infeasible with the other hyps; b_A<=a_A derivable).
  Drops H1/H2/suma/sumb/G each give feasible failure combos (36/36/48/64/196): all used hyps are needed.
  Light part: 4/7-light & a+b<=x => all 7 facets hold; without a+b<=x only a+b>x fails (claim's remark CORRECT).
  2/3-light & a+b<=x => all facets hold too (so PCL extends to 2/3-light = typeclosed GGP condition).
* w9_ref_heavyparts2brk_sharp.py: 3/4 is SHARP for the 3-template menu: exact family x_A=3/2-d, a=(1,0),
  b=(2/3-d,1/3+d), x_B=7/12+d, gap=3/4-d, all hyps except G hold, Q_alpha,Q_beta,V all infeasible (exact + LP) for
  d=1/100,1/1000,1e-6.
## [templates#2] entry 3 (LOGIC lens, RESUMED after usage-limit reset, 24 Sep). FINAL VERDICT above stands: CONFIRMED_WITH_FIXES.
* Re-derived sec.5 line by line once more by hand: C_2-empty (C_1=C closed, min attained, heavy strict), (1), attainment via
  x_1+x_2>=7/4, F1, no double-heavy, Case A/B facets (part-2 identity uses F1), Case C facts, residual kills everything,
  S-empty contradiction, (2), all six V margins and light parts (5/4*4/7+1/2*4/7=1). No gap. Any argmin a0 works (only a0_1=theta_1
  and Lam0<=1-theta_1 are used). C_2={b in C: b_2>=theta_2} is closed, so the statement's closed S has an attained maximiser.
* Logs re-checked: own e2e s11/s12, e2eV s21/s22, supports all end 'ALL CHECKS PASSED'; attacker verify_h2_s3/4/5 V counts
  2164+2091+2095=6350 as claimed; BREAK-IT referee logs all PASS.
* Re-ran: w9_ref_templates2_supports.py PASS; w9_ref_templates2_surv.py seed 7: 72105 tau*>=3/4 instances, 187 with b*!=b0,
  ALL PASS (min V slack 0 at a light part, allowed). NEW independent w9_ref_templates2_resume_check.py (brute assignment tau*,
  literal recipe with asserts of (1),F1,S!=empty,(2)): seed example tau*=19/25, V(a0,b*) slacks (23/200,31/100,11/400),
  V(a0,b0) fails at light part (-1/100), Q_b/Q_a(a0,b*) fail; random seeds 1,2: 5002 instances tau*>=3/4, ALL PASS.
  (Own bug caught: first tau* allowed cutting a part at a 0 coordinate; fixed.)
* [heavyparts#0 BRK e1, cont.] OWN BUG FOUND AND FIXED: my tau_star (w9_ref_heavyparts0brk_random.py, _climb.py)
  allowed blocking a type at a part where its trace is 0 (impossible: need u_i < a_i, u_i >= 0). Visible on the
  H3s-cex: buggy 741/1000 vs correct 821/1000 (heavylib restricts to a_i>0 correctly). Fixed (positive-trace maps
  only); random s2/s3 re-run (_fix logs): claim mismatches still 0, totals-killed tau* .4303/.3786. The float climb
  logs s11-s22 used the buggy tau_f (under-estimates tau*): superseded by the MILP below.
* w9_ref_heavyparts0brk_milp.py (big-M MILP, HiGHS; zero-trace indicator binaries so invalid blocking maps are
  switched off; EPS=1e-4 strictness): sup tau* over one-type-per-class super-heavy families with NO conflict and NO
  Fano tuple (pure totals obstruction). p=3, sums=1: OPTIMAL 0.66653 (x~(1/4,1/4,3/2), a=(1/6,0,5/6),
  b=(0,1/6,5/6), c=(0,0,1), F=empty); p=3 sums<=1: OPTIMAL 0.66657. Optima rounded at D=1e6 and re-certified
  EXACTLY (admissible, super-heavy, no conflict, 0 of 3^7 maps feasible, exact tau* 333267/500000). NUMERICAL:
  the totals caveat only bites at tau* <~ 2/3 < 3/4 for p=3.  p=4 (first run, x4<=4) hit time limit (incumbent
  .6666, dual bound 1.0); rerunning with x4<=7/4 (a part with no heavy type is light and reduces to p=3, sum<=1,
  by the heavyparts#1 light-part reduction; tau*(C)<=tau*(C|H)).
## [templates#1] (BREAK-IT) entry 3 -- controls + sharpness.  Certificate checker is NON-VACUOUS: same enumeration
  with THR=37/50 leaves 607/37614 leaves uncertified; mutations at THR=3/4: drop V 156, drop Qa 172, drop Qb 450,
  fill at own heavy part 192 uncertified (logs w9ref_logs/w9_ref_templates1brk_cert_{074,mut_*}.log).
  Observation: the role reduction is in fact EXACT, not just a relaxation: a relaxed solution becomes a genuine
  family by adding one rest part with x=2 carrying g_rest,h_rest (all hypotheses touching it hold automatically:
  x-g>=1, never heavy, never a template failure, N>=7/4).  w9_ref_templates1brk_sharp.py turns the THR=0.74 MILP
  optima into EXACT witnesses (independent brute tau*): e.g. x=(2863/1650,7/825,2), g=(821/825,0,0),
  h=(0,7/825,0): tau*=37/50, heavy pair (0,1), canonical a,b admissible, Q_b,Q_a,V all fail.  (Also the trivial
  one: single type e_1 with x_1=87/50.)  So the 3/4 hypothesis is sharp for the recipe (as for the theorem).

## randomside#0 -- referee FINAL (24 Sep 2026). VERDICT: CONFIRMED (minor fixes, cosmetic)
Script randomside2/w9_ref_randomside0_check.py (log w9_ref_randomside0_check.log), exact Fractions:
 * EXHAUSTIVE over all k-uniform families for (N,k)=(5,2),(6,2),(5,3),(6,3) (2^20 families): (i) min|H| s.t.
   tau>=T is >= L for every T (tight at many T); P(m) nonincreasing; chain
   Pr_rho[(7,2)&tau>=T] <= Pr_rho[(7,2)&|H|>=L] <= P(ceil L) <= 2Pr_{rho'}[(7,2)] holds at 41 rational rho per T. 0 violations.
 * k=2, all N<=40, all T: Turan-exact min vs L: 0 violations.  MILP-exact Turan numbers (7,3),(8,3),(9,3),(8,4),(9,4),
   (10,4) all T, (10,5) T<=3: 0 violations (run stopped in (10,5) T=4).
Fixes: read P(L) as P(ceil L); state 1<=T<=N-k+1 (else C(N-T+D,k) may vanish; claim vacuous); D integer.
Caveat for users: at rho' the expected #edges in a fixed (N-T+D)-set is D/2, so tau(H_rho') is typically only
~T-D/2; the downstream analysis at rho' must defeat (7,2) from SIZE alone (Lemmas F/P do; Theorem 1's dense
game argument would need re-checking if ported, since it uses tau near T -- 'not redone' in notes, fine).
Novelty: standard (deletion method; G(n,p)-vs-G(n,m) coupling for monotone properties, cf. JLR Prop 1.12); not in the note
(note uses random subfamilies only for the lower bound, line 289).
## [heavyparts#2] BRK entry 3 -- FINDINGS + VERDICT: CONFIRMED (FULL_PROOF stands; remarks are simplifications/scope)
* w9_ref_heavyparts2brk_e2e.py (PRIMAL cover LPs via HiGHS on the Fano support and the fn38 V support, rows 0,1 =
  two-row type, independent of the closed forms; plus exact Fraction formula check): modes gen/edge/multi/l23 x seeds
  11,12, 3000 instances each (24000): 0 counterexamples, 0 LP-vs-formula mismatches; edge mode reaches V in ~9%.
  (multi and l23 give identical counts: expected, light parts never decide the template and consume the same RNG.)
* Hand re-derivation: every step of the notes_heavyparts ~10:45 proof checks (P1, P1', Q facets, V at A/B under
  R1&R2, light parts).  The JSON proof summary omits that the Q_alpha facet 4b_A+3a_A<=4x_A needs b_A<=a_A (in the
  notes; follows from H2+Lt, or from H1+H2+G+sums without Lt).
* Remarks (no error): (1) Lt at A,B is redundant (G+H1+H2 => x_A+x_B>7/4 => b_A<1-4x_B/7<4x_A/7); (2) light
  condition can be 2/3-light & a+b<=x (exactly 'all three templates fit at j') = typeclosed GGP; (3) A!=B implicit;
  (4) V(alpha,beta) works equally; (5) 3/4 sharp for the menu (entry 2 family).
* Novelty: not in note_644.md (no multi-part gap-pair/light-part lemma; note has p=2 Thm 7.75 [C], V in 7.75,
  Q = M_{4,3} Lemma 7.57); within workspace it DUPLICATES templates Gap-Pair/Heavy-Pair and typeclosed GGP (GGP is
  slightly more general).  Significance sentence ('H2/L close |H|<=2') rests on those theorems, refereed separately.
* [heavyparts#0 BRK e1, cont.] p=4, sums<=1, x4<=7/4: MILP OPTIMAL 0.66657 (same extremal shape: x~(1.4,.2,.4,*),
  all mass on part A, F=empty, every count vector killed by the A-total; exact re-certification at D=1e6: no conflict,
  0/3^7 maps, tau*=333283/500000). x4>7/4 => part 4 light for every type => reduce to p=3 sums<=1 (0.66657).
  So for p<=4 the totals-only obstruction lives at tau* <~ 2/3 (NUMERICAL, float MILP + exact spot certificates).
  The p=3 EPS=1e-6 run returned a degenerate x_B=0 'solution' violating super-heaviness (EPS below HiGHS feasibility
  tolerance): discarded, EPS=1e-4 is the meaningful run. p=5 sums<=1 running (log _milp_p5_le1).
  Heaviness note: arc_csp.py reproduces (882/15/5 minimal sets). Novelty: note 7.55 (l.1614) = the 2-colour
  special case (monochromatic line); the 3-colour minimal-conflict list is not in the note.
## [templates#1] (BREAK-IT) FINAL REPORT. Verdict: CONFIRMED (FULL_PROOF stands; now also an independent CERTIFICATE).
  * Hand: every step of templates_handproofs.md sec.4 re-derived; tau* formula re-derived from note Lemma 7.56
    (h=x: every sum blocker costs N-1; single blockers x_i-g_i; pair combination max/sum).  No error.
  * EXACT CERTIFICATE (all p): w9_ref_templates1brk_cert.py, 37614 leaf systems, all refuted by exactly verified
    Motzkin certificates (log w9ref_logs/w9_ref_templates1brk_cert_34.log).  Role reduction is exact (rest part x=2).
    Controls non-vacuous (THR 37/50: 607 uncertified; drop V/Qa/Qb/fill-own: 156/172/450/192).
  * NUMERICAL: w9_ref_templates1brk_milp.py complete MILP: eps*=0 at 3/4 (tolerance 1e-6); 0.74 -> 5.7e-3.
  * EXACT edge-case e2e: w9_ref_templates1brk_edge.py seeds 21-24 x 1500 = 6000 instances (5995 at tau*=3/4 exactly;
    H 2604, Qb 1685, Qa 1319, V 461; modes g_I=1, |g|=1, g at capacity, coords exactly 4x/7, multi-heavy, tails,
    p up to 9, window g_I>9/10): explicit cell masses + non-covering supports: ALL CHECKS PASSED.
  * Sharpness: exact witnesses at tau*=37/50 where canonical recipe fails (w9_ref_templates1brk_sharp.py).
  * Remarks (no effect on validity): the statement should say "for EVERY heavy pair (I,J)" (proof gives it);
    Lemma 0 at I,J redundant; g_I=1 parenthesis unneeded; attacker's verify_twoupbox.py never exercises H and
    never pushes to tau*=3/4 (my edge runs and the earlier referees' do).  Novelty: p>=4 new vs note (7.62/7.73 [C]
    are p=3 sliced boxes with tau*>3/4; 7.11 obstruction is not an up-box union).
* [heavyparts#0 BRK e1, cont.] p=5 sums<=1 x<=7/4: time limit, incumbent 0.66657 (same extremal), dual bound 1.39 --
  NOT closed. CONTROL (CONTROL=1: drop the no-conflict block, keep Fano-free): MILP optimum 0.99985, exact re-check
  tau*=19997/20000, F={BBC,BCC} (mutual B<->C conflict with a tiny part B, the H3 mechanism). So the MILP's tau*
  modelling has full power and the ~2/3 ceiling is specific to the totals-only obstruction.
## [heavyparts#0] BRK FINAL VERDICT: CONFIRMED_WITH_FIXES (agrees with the LINE-BY-LINE session).
  Finite enumeration (882 / 15 / 5 minimal conflict sets, ABC irrelevant) reproduced by 3 independent scripts incl.
  the attacker's; pencil-level 'no Fano <=> conflict' 0 mismatches in 2100 exact random families (p=3,4).
  F1 the 'iff' holds only modulo per-part totals (explicit totals-killed families exist; corrected full criterion =
     15-row table, 0 mismatches).  NEW (NUMERICAL): the totals-only obstruction has sup tau* ~ 2/3 for p<=4
     (MILP optimal, exact spot certificates), so for tau*>3/4 the pencil-level classification is exact there.
  F2 the lift to several types per class is FALSE (LINE-BY-LINE cex, re-verified): 'finite case analysis' must be
     over types (row-level patterns), not over classes.
  F3 tau* computations must restrict blocking maps to positive traces (my own bug; heavylib is correct).
  F4 novelty small: note 7.55 is the 2-colour case; the 3-colour minimal-conflict list is new bookkeeping.
