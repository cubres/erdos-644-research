; benchmark generated from python API
(set-info :status unknown)
(declare-fun a_7 () Real)
(declare-fun a_11 () Real)
(declare-fun a_13 () Real)
(declare-fun a_14 () Real)
(declare-fun a_15 () Real)
(declare-fun a_19 () Real)
(declare-fun a_21 () Real)
(declare-fun a_22 () Real)
(declare-fun a_23 () Real)
(declare-fun a_25 () Real)
(declare-fun a_26 () Real)
(declare-fun a_27 () Real)
(declare-fun a_28 () Real)
(declare-fun a_29 () Real)
(declare-fun a_30 () Real)
(declare-fun a_31 () Real)
(declare-fun a_35 () Real)
(declare-fun a_37 () Real)
(declare-fun a_38 () Real)
(declare-fun a_39 () Real)
(declare-fun a_41 () Real)
(declare-fun a_42 () Real)
(declare-fun a_43 () Real)
(declare-fun a_44 () Real)
(declare-fun a_45 () Real)
(declare-fun a_46 () Real)
(declare-fun a_47 () Real)
(declare-fun a_49 () Real)
(declare-fun a_50 () Real)
(declare-fun a_51 () Real)
(declare-fun a_52 () Real)
(declare-fun a_53 () Real)
(declare-fun a_54 () Real)
(declare-fun a_55 () Real)
(declare-fun a_56 () Real)
(declare-fun a_57 () Real)
(declare-fun a_58 () Real)
(declare-fun a_59 () Real)
(declare-fun a_60 () Real)
(declare-fun a_61 () Real)
(declare-fun a_62 () Real)
(declare-fun a_63 () Real)
(declare-fun b_3 () Real)
(declare-fun b_5 () Real)
(declare-fun b_6 () Real)
(declare-fun b_7 () Real)
(declare-fun b_9 () Real)
(declare-fun b_10 () Real)
(declare-fun b_11 () Real)
(declare-fun b_12 () Real)
(declare-fun b_13 () Real)
(declare-fun b_14 () Real)
(declare-fun b_15 () Real)
(declare-fun b_17 () Real)
(declare-fun b_18 () Real)
(declare-fun b_19 () Real)
(declare-fun b_20 () Real)
(declare-fun b_21 () Real)
(declare-fun b_22 () Real)
(declare-fun b_23 () Real)
(declare-fun b_24 () Real)
(declare-fun b_25 () Real)
(declare-fun b_26 () Real)
(declare-fun b_27 () Real)
(declare-fun b_28 () Real)
(declare-fun b_29 () Real)
(declare-fun b_30 () Real)
(declare-fun b_31 () Real)
(declare-fun b_33 () Real)
(declare-fun b_34 () Real)
(declare-fun b_35 () Real)
(declare-fun b_36 () Real)
(declare-fun b_37 () Real)
(declare-fun b_38 () Real)
(declare-fun b_39 () Real)
(declare-fun b_40 () Real)
(declare-fun b_41 () Real)
(declare-fun b_42 () Real)
(declare-fun b_43 () Real)
(declare-fun b_44 () Real)
(declare-fun b_45 () Real)
(declare-fun b_46 () Real)
(declare-fun b_47 () Real)
(declare-fun b_48 () Real)
(declare-fun b_49 () Real)
(declare-fun b_50 () Real)
(declare-fun b_51 () Real)
(declare-fun b_52 () Real)
(declare-fun b_53 () Real)
(declare-fun b_54 () Real)
(declare-fun b_55 () Real)
(declare-fun b_56 () Real)
(declare-fun b_57 () Real)
(declare-fun b_58 () Real)
(declare-fun b_59 () Real)
(declare-fun b_60 () Real)
(declare-fun b_61 () Real)
(declare-fun b_62 () Real)
(declare-fun b_63 () Real)
(assert
 (>= a_7 0.0))
(assert
 (>= a_11 0.0))
(assert
 (>= a_13 0.0))
(assert
 (>= a_14 0.0))
(assert
 (>= a_15 0.0))
(assert
 (>= a_19 0.0))
(assert
 (>= a_21 0.0))
(assert
 (>= a_22 0.0))
(assert
 (>= a_23 0.0))
(assert
 (>= a_25 0.0))
(assert
 (>= a_26 0.0))
(assert
 (>= a_27 0.0))
(assert
 (>= a_28 0.0))
(assert
 (>= a_29 0.0))
(assert
 (>= a_30 0.0))
(assert
 (>= a_31 0.0))
(assert
 (>= a_35 0.0))
(assert
 (>= a_37 0.0))
(assert
 (>= a_38 0.0))
(assert
 (>= a_39 0.0))
(assert
 (>= a_41 0.0))
(assert
 (>= a_42 0.0))
(assert
 (>= a_43 0.0))
(assert
 (>= a_44 0.0))
(assert
 (>= a_45 0.0))
(assert
 (>= a_46 0.0))
(assert
 (>= a_47 0.0))
(assert
 (>= a_49 0.0))
(assert
 (>= a_50 0.0))
(assert
 (>= a_51 0.0))
(assert
 (>= a_52 0.0))
(assert
 (>= a_53 0.0))
(assert
 (>= a_54 0.0))
(assert
 (>= a_55 0.0))
(assert
 (>= a_56 0.0))
(assert
 (>= a_57 0.0))
(assert
 (>= a_58 0.0))
(assert
 (>= a_59 0.0))
(assert
 (>= a_60 0.0))
(assert
 (>= a_61 0.0))
(assert
 (>= a_62 0.0))
(assert
 (>= a_63 0.0))
(assert
 (>= b_3 0.0))
(assert
 (>= b_5 0.0))
(assert
 (>= b_6 0.0))
(assert
 (>= b_7 0.0))
(assert
 (>= b_9 0.0))
(assert
 (>= b_10 0.0))
(assert
 (>= b_11 0.0))
(assert
 (>= b_12 0.0))
(assert
 (>= b_13 0.0))
(assert
 (>= b_14 0.0))
(assert
 (>= b_15 0.0))
(assert
 (>= b_17 0.0))
(assert
 (>= b_18 0.0))
(assert
 (>= b_19 0.0))
(assert
 (>= b_20 0.0))
(assert
 (>= b_21 0.0))
(assert
 (>= b_22 0.0))
(assert
 (>= b_23 0.0))
(assert
 (>= b_24 0.0))
(assert
 (>= b_25 0.0))
(assert
 (>= b_26 0.0))
(assert
 (>= b_27 0.0))
(assert
 (>= b_28 0.0))
(assert
 (>= b_29 0.0))
(assert
 (>= b_30 0.0))
(assert
 (>= b_31 0.0))
(assert
 (>= b_33 0.0))
(assert
 (>= b_34 0.0))
(assert
 (>= b_35 0.0))
(assert
 (>= b_36 0.0))
(assert
 (>= b_37 0.0))
(assert
 (>= b_38 0.0))
(assert
 (>= b_39 0.0))
(assert
 (>= b_40 0.0))
(assert
 (>= b_41 0.0))
(assert
 (>= b_42 0.0))
(assert
 (>= b_43 0.0))
(assert
 (>= b_44 0.0))
(assert
 (>= b_45 0.0))
(assert
 (>= b_46 0.0))
(assert
 (>= b_47 0.0))
(assert
 (>= b_48 0.0))
(assert
 (>= b_49 0.0))
(assert
 (>= b_50 0.0))
(assert
 (>= b_51 0.0))
(assert
 (>= b_52 0.0))
(assert
 (>= b_53 0.0))
(assert
 (>= b_54 0.0))
(assert
 (>= b_55 0.0))
(assert
 (>= b_56 0.0))
(assert
 (>= b_57 0.0))
(assert
 (>= b_58 0.0))
(assert
 (>= b_59 0.0))
(assert
 (>= b_60 0.0))
(assert
 (>= b_61 0.0))
(assert
 (>= b_62 0.0))
(assert
 (>= b_63 0.0))
(assert
 (let ((?x221 (+ a_7 a_11 a_13 a_14 a_15 a_19 a_21 a_22 a_23 a_25 a_26 a_27 a_28 a_29 a_30 a_31 a_35 a_37 a_38 a_39 a_41 a_42 a_43 a_44 a_45 a_46 a_47 a_49 a_50 a_51 a_52 a_53 a_54 a_55 a_56 a_57 a_58 a_59 a_60 a_61 a_62 a_63)))
 (= ?x221 121800.0)))
(assert
 (let ((?x224 (+ b_3 b_5 b_6 b_7 b_9 b_10 b_11 b_12 b_13 b_14 b_15 b_17 b_18 b_19 b_20 b_21 b_22 b_23 b_24 b_25 b_26 b_27 b_28 b_29 b_30 b_31 b_33 b_34 b_35 b_36 b_37 b_38 b_39 b_40 b_41 b_42 b_43 b_44 b_45 b_46 b_47 b_48 b_49 b_50 b_51 b_52 b_53 b_54 b_55 b_56 b_57 b_58 b_59 b_60 b_61 b_62 b_63)))
 (= ?x224 121800.0)))
(assert
 (let (($x227 (= a_56 0.0)))
 (let (($x226 (= a_7 0.0)))
 (or $x226 $x227))))
(assert
 (let (($x229 (= b_24 0.0)))
 (let (($x226 (= a_7 0.0)))
 (or $x226 $x229))))
(assert
 (let (($x231 (= b_40 0.0)))
 (let (($x226 (= a_7 0.0)))
 (or $x226 $x231))))
(assert
 (let (($x233 (= b_48 0.0)))
 (let (($x226 (= a_7 0.0)))
 (or $x226 $x233))))
(assert
 (let (($x226 (= a_7 0.0)))
 (or $x226 (= b_56 0.0))))
(assert
 (let (($x238 (= a_52 0.0)))
 (let (($x237 (= a_11 0.0)))
 (or $x237 $x238))))
(assert
 (let (($x240 (= b_20 0.0)))
 (let (($x237 (= a_11 0.0)))
 (or $x237 $x240))))
(assert
 (let (($x242 (= b_36 0.0)))
 (let (($x237 (= a_11 0.0)))
 (or $x237 $x242))))
(assert
 (let (($x233 (= b_48 0.0)))
 (let (($x237 (= a_11 0.0)))
 (or $x237 $x233))))
(assert
 (let (($x237 (= a_11 0.0)))
 (or $x237 (= b_52 0.0))))
(assert
 (let (($x248 (= a_50 0.0)))
 (let (($x247 (= a_13 0.0)))
 (or $x247 $x248))))
(assert
 (let (($x250 (= b_18 0.0)))
 (let (($x247 (= a_13 0.0)))
 (or $x247 $x250))))
(assert
 (let (($x252 (= b_34 0.0)))
 (let (($x247 (= a_13 0.0)))
 (or $x247 $x252))))
(assert
 (let (($x233 (= b_48 0.0)))
 (let (($x247 (= a_13 0.0)))
 (or $x247 $x233))))
(assert
 (let (($x247 (= a_13 0.0)))
 (or $x247 (= b_50 0.0))))
(assert
 (let (($x258 (= a_49 0.0)))
 (let (($x257 (= a_14 0.0)))
 (or $x257 $x258))))
(assert
 (let (($x260 (= b_17 0.0)))
 (let (($x257 (= a_14 0.0)))
 (or $x257 $x260))))
(assert
 (let (($x262 (= b_33 0.0)))
 (let (($x257 (= a_14 0.0)))
 (or $x257 $x262))))
(assert
 (let (($x233 (= b_48 0.0)))
 (let (($x257 (= a_14 0.0)))
 (or $x257 $x233))))
(assert
 (let (($x257 (= a_14 0.0)))
 (or $x257 (= b_49 0.0))))
(assert
 (let (($x233 (= b_48 0.0)))
 (or (= a_15 0.0) $x233)))
(assert
 (let (($x270 (= a_44 0.0)))
 (let (($x269 (= a_19 0.0)))
 (or $x269 $x270))))
(assert
 (let (($x272 (= b_12 0.0)))
 (let (($x269 (= a_19 0.0)))
 (or $x269 $x272))))
(assert
 (let (($x242 (= b_36 0.0)))
 (let (($x269 (= a_19 0.0)))
 (or $x269 $x242))))
(assert
 (let (($x231 (= b_40 0.0)))
 (let (($x269 (= a_19 0.0)))
 (or $x269 $x231))))
(assert
 (let (($x269 (= a_19 0.0)))
 (or $x269 (= b_44 0.0))))
(assert
 (let (($x279 (= a_42 0.0)))
 (let (($x278 (= a_21 0.0)))
 (or $x278 $x279))))
(assert
 (let (($x281 (= b_10 0.0)))
 (let (($x278 (= a_21 0.0)))
 (or $x278 $x281))))
(assert
 (let (($x252 (= b_34 0.0)))
 (let (($x278 (= a_21 0.0)))
 (or $x278 $x252))))
(assert
 (let (($x231 (= b_40 0.0)))
 (let (($x278 (= a_21 0.0)))
 (or $x278 $x231))))
(assert
 (let (($x278 (= a_21 0.0)))
 (or $x278 (= b_42 0.0))))
(assert
 (let (($x288 (= a_41 0.0)))
 (let (($x287 (= a_22 0.0)))
 (or $x287 $x288))))
(assert
 (let (($x290 (= b_9 0.0)))
 (let (($x287 (= a_22 0.0)))
 (or $x287 $x290))))
(assert
 (let (($x262 (= b_33 0.0)))
 (let (($x287 (= a_22 0.0)))
 (or $x287 $x262))))
(assert
 (let (($x231 (= b_40 0.0)))
 (let (($x287 (= a_22 0.0)))
 (or $x287 $x231))))
(assert
 (let (($x287 (= a_22 0.0)))
 (or $x287 (= b_41 0.0))))
(assert
 (let (($x231 (= b_40 0.0)))
 (or (= a_23 0.0) $x231)))
(assert
 (let (($x299 (= a_38 0.0)))
 (let (($x298 (= a_25 0.0)))
 (or $x298 $x299))))
(assert
 (let (($x301 (= b_6 0.0)))
 (let (($x298 (= a_25 0.0)))
 (or $x298 $x301))))
(assert
 (let (($x252 (= b_34 0.0)))
 (let (($x298 (= a_25 0.0)))
 (or $x298 $x252))))
(assert
 (let (($x242 (= b_36 0.0)))
 (let (($x298 (= a_25 0.0)))
 (or $x298 $x242))))
(assert
 (let (($x298 (= a_25 0.0)))
 (or $x298 (= b_38 0.0))))
(assert
 (let (($x308 (= a_37 0.0)))
 (let (($x307 (= a_26 0.0)))
 (or $x307 $x308))))
(assert
 (let (($x310 (= b_5 0.0)))
 (let (($x307 (= a_26 0.0)))
 (or $x307 $x310))))
(assert
 (let (($x262 (= b_33 0.0)))
 (let (($x307 (= a_26 0.0)))
 (or $x307 $x262))))
(assert
 (let (($x242 (= b_36 0.0)))
 (let (($x307 (= a_26 0.0)))
 (or $x307 $x242))))
(assert
 (let (($x307 (= a_26 0.0)))
 (or $x307 (= b_37 0.0))))
(assert
 (let (($x242 (= b_36 0.0)))
 (or (= a_27 0.0) $x242)))
(assert
 (let (($x319 (= a_35 0.0)))
 (let (($x318 (= a_28 0.0)))
 (or $x318 $x319))))
(assert
 (let (($x321 (= b_3 0.0)))
 (let (($x318 (= a_28 0.0)))
 (or $x318 $x321))))
(assert
 (let (($x262 (= b_33 0.0)))
 (let (($x318 (= a_28 0.0)))
 (or $x318 $x262))))
(assert
 (let (($x252 (= b_34 0.0)))
 (let (($x318 (= a_28 0.0)))
 (or $x318 $x252))))
(assert
 (let (($x318 (= a_28 0.0)))
 (or $x318 (= b_35 0.0))))
(assert
 (let (($x252 (= b_34 0.0)))
 (or (= a_29 0.0) $x252)))
(assert
 (let (($x262 (= b_33 0.0)))
 (or (= a_30 0.0) $x262)))
(assert
 (let (($x272 (= b_12 0.0)))
 (let (($x319 (= a_35 0.0)))
 (or $x319 $x272))))
(assert
 (let (($x240 (= b_20 0.0)))
 (let (($x319 (= a_35 0.0)))
 (or $x319 $x240))))
(assert
 (let (($x229 (= b_24 0.0)))
 (let (($x319 (= a_35 0.0)))
 (or $x319 $x229))))
(assert
 (let (($x319 (= a_35 0.0)))
 (or $x319 (= b_28 0.0))))
(assert
 (let (($x281 (= b_10 0.0)))
 (let (($x308 (= a_37 0.0)))
 (or $x308 $x281))))
(assert
 (let (($x250 (= b_18 0.0)))
 (let (($x308 (= a_37 0.0)))
 (or $x308 $x250))))
(assert
 (let (($x229 (= b_24 0.0)))
 (let (($x308 (= a_37 0.0)))
 (or $x308 $x229))))
(assert
 (let (($x308 (= a_37 0.0)))
 (or $x308 (= b_26 0.0))))
(assert
 (let (($x290 (= b_9 0.0)))
 (let (($x299 (= a_38 0.0)))
 (or $x299 $x290))))
(assert
 (let (($x260 (= b_17 0.0)))
 (let (($x299 (= a_38 0.0)))
 (or $x299 $x260))))
(assert
 (let (($x229 (= b_24 0.0)))
 (let (($x299 (= a_38 0.0)))
 (or $x299 $x229))))
(assert
 (let (($x299 (= a_38 0.0)))
 (or $x299 (= b_25 0.0))))
(assert
 (let (($x229 (= b_24 0.0)))
 (or (= a_39 0.0) $x229)))
(assert
 (let (($x301 (= b_6 0.0)))
 (let (($x288 (= a_41 0.0)))
 (or $x288 $x301))))
(assert
 (let (($x250 (= b_18 0.0)))
 (let (($x288 (= a_41 0.0)))
 (or $x288 $x250))))
(assert
 (let (($x240 (= b_20 0.0)))
 (let (($x288 (= a_41 0.0)))
 (or $x288 $x240))))
(assert
 (let (($x288 (= a_41 0.0)))
 (or $x288 (= b_22 0.0))))
(assert
 (let (($x310 (= b_5 0.0)))
 (let (($x279 (= a_42 0.0)))
 (or $x279 $x310))))
(assert
 (let (($x260 (= b_17 0.0)))
 (let (($x279 (= a_42 0.0)))
 (or $x279 $x260))))
(assert
 (let (($x240 (= b_20 0.0)))
 (let (($x279 (= a_42 0.0)))
 (or $x279 $x240))))
(assert
 (let (($x279 (= a_42 0.0)))
 (or $x279 (= b_21 0.0))))
(assert
 (let (($x240 (= b_20 0.0)))
 (or (= a_43 0.0) $x240)))
(assert
 (let (($x321 (= b_3 0.0)))
 (let (($x270 (= a_44 0.0)))
 (or $x270 $x321))))
(assert
 (let (($x260 (= b_17 0.0)))
 (let (($x270 (= a_44 0.0)))
 (or $x270 $x260))))
(assert
 (let (($x250 (= b_18 0.0)))
 (let (($x270 (= a_44 0.0)))
 (or $x270 $x250))))
(assert
 (let (($x270 (= a_44 0.0)))
 (or $x270 (= b_19 0.0))))
(assert
 (let (($x250 (= b_18 0.0)))
 (or (= a_45 0.0) $x250)))
(assert
 (let (($x260 (= b_17 0.0)))
 (or (= a_46 0.0) $x260)))
(assert
 (let (($x301 (= b_6 0.0)))
 (let (($x258 (= a_49 0.0)))
 (or $x258 $x301))))
(assert
 (let (($x281 (= b_10 0.0)))
 (let (($x258 (= a_49 0.0)))
 (or $x258 $x281))))
(assert
 (let (($x272 (= b_12 0.0)))
 (let (($x258 (= a_49 0.0)))
 (or $x258 $x272))))
(assert
 (let (($x258 (= a_49 0.0)))
 (or $x258 (= b_14 0.0))))
(assert
 (let (($x310 (= b_5 0.0)))
 (let (($x248 (= a_50 0.0)))
 (or $x248 $x310))))
(assert
 (let (($x290 (= b_9 0.0)))
 (let (($x248 (= a_50 0.0)))
 (or $x248 $x290))))
(assert
 (let (($x272 (= b_12 0.0)))
 (let (($x248 (= a_50 0.0)))
 (or $x248 $x272))))
(assert
 (let (($x248 (= a_50 0.0)))
 (or $x248 (= b_13 0.0))))
(assert
 (let (($x272 (= b_12 0.0)))
 (or (= a_51 0.0) $x272)))
(assert
 (let (($x321 (= b_3 0.0)))
 (let (($x238 (= a_52 0.0)))
 (or $x238 $x321))))
(assert
 (let (($x290 (= b_9 0.0)))
 (let (($x238 (= a_52 0.0)))
 (or $x238 $x290))))
(assert
 (let (($x281 (= b_10 0.0)))
 (let (($x238 (= a_52 0.0)))
 (or $x238 $x281))))
(assert
 (let (($x238 (= a_52 0.0)))
 (or $x238 (= b_11 0.0))))
(assert
 (let (($x281 (= b_10 0.0)))
 (or (= a_53 0.0) $x281)))
(assert
 (let (($x290 (= b_9 0.0)))
 (or (= a_54 0.0) $x290)))
(assert
 (let (($x321 (= b_3 0.0)))
 (let (($x227 (= a_56 0.0)))
 (or $x227 $x321))))
(assert
 (let (($x310 (= b_5 0.0)))
 (let (($x227 (= a_56 0.0)))
 (or $x227 $x310))))
(assert
 (let (($x301 (= b_6 0.0)))
 (let (($x227 (= a_56 0.0)))
 (or $x227 $x301))))
(assert
 (let (($x227 (= a_56 0.0)))
 (or $x227 (= b_7 0.0))))
(assert
 (let (($x301 (= b_6 0.0)))
 (or (= a_57 0.0) $x301)))
(assert
 (let (($x310 (= b_5 0.0)))
 (or (= a_58 0.0) $x310)))
(assert
 (let (($x321 (= b_3 0.0)))
 (or (= a_60 0.0) $x321)))
(assert
 (let ((?x402 (+ b_3 b_5 b_7 b_9 b_11 b_13 b_15 b_17 b_19 b_21 b_23 b_25 b_27 b_29 b_31 b_33 b_35 b_37 b_39 b_41 b_43 b_45 b_47 b_49 b_51 b_53 b_55 b_57 b_59 b_61 b_63)))
 (let ((?x401 (+ a_7 a_11 a_13 a_15 a_19 a_21 a_23 a_25 a_27 a_29 a_31 a_35 a_37 a_39 a_41 a_43 a_45 a_47 a_49 a_51 a_53 a_55 a_57 a_59 a_61 a_63)))
 (= (+ ?x401 ?x402) 103600.0))))
(assert
 (let ((?x401 (+ a_7 a_11 a_13 a_15 a_19 a_21 a_23 a_25 a_27 a_29 a_31 a_35 a_37 a_39 a_41 a_43 a_45 a_47 a_49 a_51 a_53 a_55 a_57 a_59 a_61 a_63)))
 (let ((?x408 (- 121800.0 ?x401)))
 (or (and (>= ?x408 18200.0) (<= ?x408 54586.0)) (and (>= ?x408 57660.0) (<= ?x408 57660.0)) (and (>= ?x408 60914.0) (<= ?x408 61054.0)) (and (>= ?x408 64155.0) (<= ?x408 75845.0)) (and (>= ?x408 78946.0) (<= ?x408 79086.0)) (and (>= ?x408 82340.0) (<= ?x408 82340.0)) (and (>= ?x408 85414.0) (<= ?x408 121800.0))))))
(assert
 (let ((?x506 (+ b_3 b_6 b_7 b_10 b_11 b_14 b_15 b_18 b_19 b_22 b_23 b_26 b_27 b_30 b_31 b_34 b_35 b_38 b_39 b_42 b_43 b_46 b_47 b_50 b_51 b_54 b_55 b_58 b_59 b_62 b_63)))
 (let ((?x505 (+ a_7 a_11 a_14 a_15 a_19 a_22 a_23 a_26 a_27 a_30 a_31 a_35 a_38 a_39 a_42 a_43 a_46 a_47 a_50 a_51 a_54 a_55 a_58 a_59 a_62 a_63)))
 (= (+ ?x505 ?x506) 103600.0))))
(assert
 (let ((?x505 (+ a_7 a_11 a_14 a_15 a_19 a_22 a_23 a_26 a_27 a_30 a_31 a_35 a_38 a_39 a_42 a_43 a_46 a_47 a_50 a_51 a_54 a_55 a_58 a_59 a_62 a_63)))
 (let ((?x511 (- 121800.0 ?x505)))
 (or (and (>= ?x511 18200.0) (<= ?x511 54586.0)) (and (>= ?x511 57660.0) (<= ?x511 57660.0)) (and (>= ?x511 60914.0) (<= ?x511 61054.0)) (and (>= ?x511 64155.0) (<= ?x511 75845.0)) (and (>= ?x511 78946.0) (<= ?x511 79086.0)) (and (>= ?x511 82340.0) (<= ?x511 82340.0)) (and (>= ?x511 85414.0) (<= ?x511 121800.0))))))
(assert
 (let ((?x572 (+ b_5 b_6 b_7 b_12 b_13 b_14 b_15 b_20 b_21 b_22 b_23 b_28 b_29 b_30 b_31 b_36 b_37 b_38 b_39 b_44 b_45 b_46 b_47 b_52 b_53 b_54 b_55 b_60 b_61 b_62 b_63)))
 (let ((?x571 (+ a_7 a_13 a_14 a_15 a_21 a_22 a_23 a_28 a_29 a_30 a_31 a_37 a_38 a_39 a_44 a_45 a_46 a_47 a_52 a_53 a_54 a_55 a_60 a_61 a_62 a_63)))
 (= (+ ?x571 ?x572) 103600.0))))
(assert
 (let ((?x571 (+ a_7 a_13 a_14 a_15 a_21 a_22 a_23 a_28 a_29 a_30 a_31 a_37 a_38 a_39 a_44 a_45 a_46 a_47 a_52 a_53 a_54 a_55 a_60 a_61 a_62 a_63)))
 (let ((?x577 (- 121800.0 ?x571)))
 (or (and (>= ?x577 18200.0) (<= ?x577 54586.0)) (and (>= ?x577 57660.0) (<= ?x577 57660.0)) (and (>= ?x577 60914.0) (<= ?x577 61054.0)) (and (>= ?x577 64155.0) (<= ?x577 75845.0)) (and (>= ?x577 78946.0) (<= ?x577 79086.0)) (and (>= ?x577 82340.0) (<= ?x577 82340.0)) (and (>= ?x577 85414.0) (<= ?x577 121800.0))))))
(assert
 (let ((?x631 (+ b_9 b_10 b_11 b_12 b_13 b_14 b_15 b_24 b_25 b_26 b_27 b_28 b_29 b_30 b_31 b_40 b_41 b_42 b_43 b_44 b_45 b_46 b_47 b_56 b_57 b_58 b_59 b_60 b_61 b_62 b_63)))
 (let ((?x630 (+ a_11 a_13 a_14 a_15 a_25 a_26 a_27 a_28 a_29 a_30 a_31 a_41 a_42 a_43 a_44 a_45 a_46 a_47 a_56 a_57 a_58 a_59 a_60 a_61 a_62 a_63)))
 (= (+ ?x630 ?x631) 103600.0))))
(assert
 (let ((?x630 (+ a_11 a_13 a_14 a_15 a_25 a_26 a_27 a_28 a_29 a_30 a_31 a_41 a_42 a_43 a_44 a_45 a_46 a_47 a_56 a_57 a_58 a_59 a_60 a_61 a_62 a_63)))
 (let ((?x636 (- 121800.0 ?x630)))
 (or (and (>= ?x636 18200.0) (<= ?x636 54586.0)) (and (>= ?x636 57660.0) (<= ?x636 57660.0)) (and (>= ?x636 60914.0) (<= ?x636 61054.0)) (and (>= ?x636 64155.0) (<= ?x636 75845.0)) (and (>= ?x636 78946.0) (<= ?x636 79086.0)) (and (>= ?x636 82340.0) (<= ?x636 82340.0)) (and (>= ?x636 85414.0) (<= ?x636 121800.0))))))
(assert
 (let ((?x687 (+ b_17 b_18 b_19 b_20 b_21 b_22 b_23 b_24 b_25 b_26 b_27 b_28 b_29 b_30 b_31 b_48 b_49 b_50 b_51 b_52 b_53 b_54 b_55 b_56 b_57 b_58 b_59 b_60 b_61 b_62 b_63)))
 (let ((?x686 (+ a_19 a_21 a_22 a_23 a_25 a_26 a_27 a_28 a_29 a_30 a_31 a_49 a_50 a_51 a_52 a_53 a_54 a_55 a_56 a_57 a_58 a_59 a_60 a_61 a_62 a_63)))
 (= (+ ?x686 ?x687) 103600.0))))
(assert
 (let ((?x686 (+ a_19 a_21 a_22 a_23 a_25 a_26 a_27 a_28 a_29 a_30 a_31 a_49 a_50 a_51 a_52 a_53 a_54 a_55 a_56 a_57 a_58 a_59 a_60 a_61 a_62 a_63)))
 (let ((?x692 (- 121800.0 ?x686)))
 (or (and (>= ?x692 18200.0) (<= ?x692 54586.0)) (and (>= ?x692 57660.0) (<= ?x692 57660.0)) (and (>= ?x692 60914.0) (<= ?x692 61054.0)) (and (>= ?x692 64155.0) (<= ?x692 75845.0)) (and (>= ?x692 78946.0) (<= ?x692 79086.0)) (and (>= ?x692 82340.0) (<= ?x692 82340.0)) (and (>= ?x692 85414.0) (<= ?x692 121800.0))))))
(assert
 (let ((?x742 (+ b_33 b_34 b_35 b_36 b_37 b_38 b_39 b_40 b_41 b_42 b_43 b_44 b_45 b_46 b_47 b_48 b_49 b_50 b_51 b_52 b_53 b_54 b_55 b_56 b_57 b_58 b_59 b_60 b_61 b_62 b_63)))
 (let ((?x741 (+ a_35 a_37 a_38 a_39 a_41 a_42 a_43 a_44 a_45 a_46 a_47 a_49 a_50 a_51 a_52 a_53 a_54 a_55 a_56 a_57 a_58 a_59 a_60 a_61 a_62 a_63)))
 (= (+ ?x741 ?x742) 103600.0))))
(assert
 (let ((?x741 (+ a_35 a_37 a_38 a_39 a_41 a_42 a_43 a_44 a_45 a_46 a_47 a_49 a_50 a_51 a_52 a_53 a_54 a_55 a_56 a_57 a_58 a_59 a_60 a_61 a_62 a_63)))
 (let ((?x747 (- 121800.0 ?x741)))
 (or (and (>= ?x747 18200.0) (<= ?x747 54586.0)) (and (>= ?x747 57660.0) (<= ?x747 57660.0)) (and (>= ?x747 60914.0) (<= ?x747 61054.0)) (and (>= ?x747 64155.0) (<= ?x747 75845.0)) (and (>= ?x747 78946.0) (<= ?x747 79086.0)) (and (>= ?x747 82340.0) (<= ?x747 82340.0)) (and (>= ?x747 85414.0) (<= ?x747 121800.0))))))
(assert
 (let ((?x505 (+ a_7 a_11 a_14 a_15 a_19 a_22 a_23 a_26 a_27 a_30 a_31 a_35 a_38 a_39 a_42 a_43 a_46 a_47 a_50 a_51 a_54 a_55 a_58 a_59 a_62 a_63)))
 (let ((?x511 (- 121800.0 ?x505)))
 (let ((?x401 (+ a_7 a_11 a_13 a_15 a_19 a_21 a_23 a_25 a_27 a_29 a_31 a_35 a_37 a_39 a_41 a_43 a_45 a_47 a_49 a_51 a_53 a_55 a_57 a_59 a_61 a_63)))
 (let ((?x408 (- 121800.0 ?x401)))
 (<= ?x408 ?x511))))))
(assert
 (let ((?x571 (+ a_7 a_13 a_14 a_15 a_21 a_22 a_23 a_28 a_29 a_30 a_31 a_37 a_38 a_39 a_44 a_45 a_46 a_47 a_52 a_53 a_54 a_55 a_60 a_61 a_62 a_63)))
 (let ((?x577 (- 121800.0 ?x571)))
 (let ((?x505 (+ a_7 a_11 a_14 a_15 a_19 a_22 a_23 a_26 a_27 a_30 a_31 a_35 a_38 a_39 a_42 a_43 a_46 a_47 a_50 a_51 a_54 a_55 a_58 a_59 a_62 a_63)))
 (let ((?x511 (- 121800.0 ?x505)))
 (<= ?x511 ?x577))))))
(assert
 (let ((?x630 (+ a_11 a_13 a_14 a_15 a_25 a_26 a_27 a_28 a_29 a_30 a_31 a_41 a_42 a_43 a_44 a_45 a_46 a_47 a_56 a_57 a_58 a_59 a_60 a_61 a_62 a_63)))
 (let ((?x636 (- 121800.0 ?x630)))
 (let ((?x571 (+ a_7 a_13 a_14 a_15 a_21 a_22 a_23 a_28 a_29 a_30 a_31 a_37 a_38 a_39 a_44 a_45 a_46 a_47 a_52 a_53 a_54 a_55 a_60 a_61 a_62 a_63)))
 (let ((?x577 (- 121800.0 ?x571)))
 (<= ?x577 ?x636))))))
(assert
 (let ((?x686 (+ a_19 a_21 a_22 a_23 a_25 a_26 a_27 a_28 a_29 a_30 a_31 a_49 a_50 a_51 a_52 a_53 a_54 a_55 a_56 a_57 a_58 a_59 a_60 a_61 a_62 a_63)))
 (let ((?x692 (- 121800.0 ?x686)))
 (let ((?x630 (+ a_11 a_13 a_14 a_15 a_25 a_26 a_27 a_28 a_29 a_30 a_31 a_41 a_42 a_43 a_44 a_45 a_46 a_47 a_56 a_57 a_58 a_59 a_60 a_61 a_62 a_63)))
 (let ((?x636 (- 121800.0 ?x630)))
 (<= ?x636 ?x692))))))
(assert
 (let ((?x741 (+ a_35 a_37 a_38 a_39 a_41 a_42 a_43 a_44 a_45 a_46 a_47 a_49 a_50 a_51 a_52 a_53 a_54 a_55 a_56 a_57 a_58 a_59 a_60 a_61 a_62 a_63)))
(let ((?x747 (- 121800.0 ?x741)))
(let ((?x686 (+ a_19 a_21 a_22 a_23 a_25 a_26 a_27 a_28 a_29 a_30 a_31 a_49 a_50 a_51 a_52 a_53 a_54 a_55 a_56 a_57 a_58 a_59 a_60 a_61 a_62 a_63)))
(let ((?x692 (- 121800.0 ?x686)))
(<= ?x692 ?x747))))))
(check-sat)
