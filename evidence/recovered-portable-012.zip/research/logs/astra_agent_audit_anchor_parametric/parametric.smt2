; benchmark generated from python API
(set-info :status unknown)
(declare-fun q () Real)
(declare-fun a_7 () Real)
(declare-fun a_11 () Real)
(declare-fun a_13 () Real)
(declare-fun a_14 () Real)
(declare-fun a_15 () Real)
(declare-fun a_19 () Real)
(declare-fun a_21 () Real)
(declare-fun a_22 () Real)
(declare-fun a_23 () Real)
(declare-fun a_25 () Real)
(declare-fun a_26 () Real)
(declare-fun a_27 () Real)
(declare-fun a_28 () Real)
(declare-fun a_29 () Real)
(declare-fun a_30 () Real)
(declare-fun a_31 () Real)
(declare-fun a_35 () Real)
(declare-fun a_37 () Real)
(declare-fun a_38 () Real)
(declare-fun a_39 () Real)
(declare-fun a_41 () Real)
(declare-fun a_42 () Real)
(declare-fun a_43 () Real)
(declare-fun a_44 () Real)
(declare-fun a_45 () Real)
(declare-fun a_46 () Real)
(declare-fun a_47 () Real)
(declare-fun a_49 () Real)
(declare-fun a_50 () Real)
(declare-fun a_51 () Real)
(declare-fun a_52 () Real)
(declare-fun a_53 () Real)
(declare-fun a_54 () Real)
(declare-fun a_55 () Real)
(declare-fun a_56 () Real)
(declare-fun a_57 () Real)
(declare-fun a_58 () Real)
(declare-fun a_59 () Real)
(declare-fun a_60 () Real)
(declare-fun a_61 () Real)
(declare-fun a_62 () Real)
(declare-fun a_63 () Real)
(declare-fun b_3 () Real)
(declare-fun b_5 () Real)
(declare-fun b_6 () Real)
(declare-fun b_7 () Real)
(declare-fun b_9 () Real)
(declare-fun b_10 () Real)
(declare-fun b_11 () Real)
(declare-fun b_12 () Real)
(declare-fun b_13 () Real)
(declare-fun b_14 () Real)
(declare-fun b_15 () Real)
(declare-fun b_17 () Real)
(declare-fun b_18 () Real)
(declare-fun b_19 () Real)
(declare-fun b_20 () Real)
(declare-fun b_21 () Real)
(declare-fun b_22 () Real)
(declare-fun b_23 () Real)
(declare-fun b_24 () Real)
(declare-fun b_25 () Real)
(declare-fun b_26 () Real)
(declare-fun b_27 () Real)
(declare-fun b_28 () Real)
(declare-fun b_29 () Real)
(declare-fun b_30 () Real)
(declare-fun b_31 () Real)
(declare-fun b_33 () Real)
(declare-fun b_34 () Real)
(declare-fun b_35 () Real)
(declare-fun b_36 () Real)
(declare-fun b_37 () Real)
(declare-fun b_38 () Real)
(declare-fun b_39 () Real)
(declare-fun b_40 () Real)
(declare-fun b_41 () Real)
(declare-fun b_42 () Real)
(declare-fun b_43 () Real)
(declare-fun b_44 () Real)
(declare-fun b_45 () Real)
(declare-fun b_46 () Real)
(declare-fun b_47 () Real)
(declare-fun b_48 () Real)
(declare-fun b_49 () Real)
(declare-fun b_50 () Real)
(declare-fun b_51 () Real)
(declare-fun b_52 () Real)
(declare-fun b_53 () Real)
(declare-fun b_54 () Real)
(declare-fun b_55 () Real)
(declare-fun b_56 () Real)
(declare-fun b_57 () Real)
(declare-fun b_58 () Real)
(declare-fun b_59 () Real)
(declare-fun b_60 () Real)
(declare-fun b_61 () Real)
(declare-fun b_62 () Real)
(declare-fun b_63 () Real)
(assert
 (<= (/ 87.0 100.0) q))
(assert
 (> (/ 7.0 8.0) q))
(assert
 (>= a_7 0.0))
(assert
 (>= a_11 0.0))
(assert
 (>= a_13 0.0))
(assert
 (>= a_14 0.0))
(assert
 (>= a_15 0.0))
(assert
 (>= a_19 0.0))
(assert
 (>= a_21 0.0))
(assert
 (>= a_22 0.0))
(assert
 (>= a_23 0.0))
(assert
 (>= a_25 0.0))
(assert
 (>= a_26 0.0))
(assert
 (>= a_27 0.0))
(assert
 (>= a_28 0.0))
(assert
 (>= a_29 0.0))
(assert
 (>= a_30 0.0))
(assert
 (>= a_31 0.0))
(assert
 (>= a_35 0.0))
(assert
 (>= a_37 0.0))
(assert
 (>= a_38 0.0))
(assert
 (>= a_39 0.0))
(assert
 (>= a_41 0.0))
(assert
 (>= a_42 0.0))
(assert
 (>= a_43 0.0))
(assert
 (>= a_44 0.0))
(assert
 (>= a_45 0.0))
(assert
 (>= a_46 0.0))
(assert
 (>= a_47 0.0))
(assert
 (>= a_49 0.0))
(assert
 (>= a_50 0.0))
(assert
 (>= a_51 0.0))
(assert
 (>= a_52 0.0))
(assert
 (>= a_53 0.0))
(assert
 (>= a_54 0.0))
(assert
 (>= a_55 0.0))
(assert
 (>= a_56 0.0))
(assert
 (>= a_57 0.0))
(assert
 (>= a_58 0.0))
(assert
 (>= a_59 0.0))
(assert
 (>= a_60 0.0))
(assert
 (>= a_61 0.0))
(assert
 (>= a_62 0.0))
(assert
 (>= a_63 0.0))
(assert
 (>= b_3 0.0))
(assert
 (>= b_5 0.0))
(assert
 (>= b_6 0.0))
(assert
 (>= b_7 0.0))
(assert
 (>= b_9 0.0))
(assert
 (>= b_10 0.0))
(assert
 (>= b_11 0.0))
(assert
 (>= b_12 0.0))
(assert
 (>= b_13 0.0))
(assert
 (>= b_14 0.0))
(assert
 (>= b_15 0.0))
(assert
 (>= b_17 0.0))
(assert
 (>= b_18 0.0))
(assert
 (>= b_19 0.0))
(assert
 (>= b_20 0.0))
(assert
 (>= b_21 0.0))
(assert
 (>= b_22 0.0))
(assert
 (>= b_23 0.0))
(assert
 (>= b_24 0.0))
(assert
 (>= b_25 0.0))
(assert
 (>= b_26 0.0))
(assert
 (>= b_27 0.0))
(assert
 (>= b_28 0.0))
(assert
 (>= b_29 0.0))
(assert
 (>= b_30 0.0))
(assert
 (>= b_31 0.0))
(assert
 (>= b_33 0.0))
(assert
 (>= b_34 0.0))
(assert
 (>= b_35 0.0))
(assert
 (>= b_36 0.0))
(assert
 (>= b_37 0.0))
(assert
 (>= b_38 0.0))
(assert
 (>= b_39 0.0))
(assert
 (>= b_40 0.0))
(assert
 (>= b_41 0.0))
(assert
 (>= b_42 0.0))
(assert
 (>= b_43 0.0))
(assert
 (>= b_44 0.0))
(assert
 (>= b_45 0.0))
(assert
 (>= b_46 0.0))
(assert
 (>= b_47 0.0))
(assert
 (>= b_48 0.0))
(assert
 (>= b_49 0.0))
(assert
 (>= b_50 0.0))
(assert
 (>= b_51 0.0))
(assert
 (>= b_52 0.0))
(assert
 (>= b_53 0.0))
(assert
 (>= b_54 0.0))
(assert
 (>= b_55 0.0))
(assert
 (>= b_56 0.0))
(assert
 (>= b_57 0.0))
(assert
 (>= b_58 0.0))
(assert
 (>= b_59 0.0))
(assert
 (>= b_60 0.0))
(assert
 (>= b_61 0.0))
(assert
 (>= b_62 0.0))
(assert
 (>= b_63 0.0))
(assert
 (let ((?x263 (+ a_7 a_11 a_13 a_14 a_15 a_19 a_21 a_22 a_23 a_25 a_26 a_27 a_28 a_29 a_30 a_31 a_35 a_37 a_38 a_39 a_41 a_42 a_43 a_44 a_45 a_46 a_47 a_49 a_50 a_51 a_52 a_53 a_54 a_55 a_56 a_57 a_58 a_59 a_60 a_61 a_62 a_63)))
 (= ?x263 q)))
(assert
 (let ((?x265 (+ b_3 b_5 b_6 b_7 b_9 b_10 b_11 b_12 b_13 b_14 b_15 b_17 b_18 b_19 b_20 b_21 b_22 b_23 b_24 b_25 b_26 b_27 b_28 b_29 b_30 b_31 b_33 b_34 b_35 b_36 b_37 b_38 b_39 b_40 b_41 b_42 b_43 b_44 b_45 b_46 b_47 b_48 b_49 b_50 b_51 b_52 b_53 b_54 b_55 b_56 b_57 b_58 b_59 b_60 b_61 b_62 b_63)))
 (= ?x265 q)))
(assert
 (let (($x372 (= a_56 0.0)))
 (let (($x313 (= a_7 0.0)))
 (or $x313 $x372))))
(assert
 (let (($x374 (= b_24 0.0)))
 (let (($x313 (= a_7 0.0)))
 (or $x313 $x374))))
(assert
 (let (($x376 (= b_40 0.0)))
 (let (($x313 (= a_7 0.0)))
 (or $x313 $x376))))
(assert
 (let (($x378 (= b_48 0.0)))
 (let (($x313 (= a_7 0.0)))
 (or $x313 $x378))))
(assert
 (let (($x313 (= a_7 0.0)))
 (or $x313 (= b_56 0.0))))
(assert
 (let (($x383 (= a_52 0.0)))
 (let (($x382 (= a_11 0.0)))
 (or $x382 $x383))))
(assert
 (let (($x385 (= b_20 0.0)))
 (let (($x382 (= a_11 0.0)))
 (or $x382 $x385))))
(assert
 (let (($x387 (= b_36 0.0)))
 (let (($x382 (= a_11 0.0)))
 (or $x382 $x387))))
(assert
 (let (($x378 (= b_48 0.0)))
 (let (($x382 (= a_11 0.0)))
 (or $x382 $x378))))
(assert
 (let (($x382 (= a_11 0.0)))
 (or $x382 (= b_52 0.0))))
(assert
 (let (($x393 (= a_50 0.0)))
 (let (($x392 (= a_13 0.0)))
 (or $x392 $x393))))
(assert
 (let (($x395 (= b_18 0.0)))
 (let (($x392 (= a_13 0.0)))
 (or $x392 $x395))))
(assert
 (let (($x397 (= b_34 0.0)))
 (let (($x392 (= a_13 0.0)))
 (or $x392 $x397))))
(assert
 (let (($x378 (= b_48 0.0)))
 (let (($x392 (= a_13 0.0)))
 (or $x392 $x378))))
(assert
 (let (($x392 (= a_13 0.0)))
 (or $x392 (= b_50 0.0))))
(assert
 (let (($x403 (= a_49 0.0)))
 (let (($x402 (= a_14 0.0)))
 (or $x402 $x403))))
(assert
 (let (($x405 (= b_17 0.0)))
 (let (($x402 (= a_14 0.0)))
 (or $x402 $x405))))
(assert
 (let (($x407 (= b_33 0.0)))
 (let (($x402 (= a_14 0.0)))
 (or $x402 $x407))))
(assert
 (let (($x378 (= b_48 0.0)))
 (let (($x402 (= a_14 0.0)))
 (or $x402 $x378))))
(assert
 (let (($x402 (= a_14 0.0)))
 (or $x402 (= b_49 0.0))))
(assert
 (let (($x378 (= b_48 0.0)))
 (or (= a_15 0.0) $x378)))
(assert
 (let (($x415 (= a_44 0.0)))
 (let (($x414 (= a_19 0.0)))
 (or $x414 $x415))))
(assert
 (let (($x417 (= b_12 0.0)))
 (let (($x414 (= a_19 0.0)))
 (or $x414 $x417))))
(assert
 (let (($x387 (= b_36 0.0)))
 (let (($x414 (= a_19 0.0)))
 (or $x414 $x387))))
(assert
 (let (($x376 (= b_40 0.0)))
 (let (($x414 (= a_19 0.0)))
 (or $x414 $x376))))
(assert
 (let (($x414 (= a_19 0.0)))
 (or $x414 (= b_44 0.0))))
(assert
 (let (($x424 (= a_42 0.0)))
 (let (($x423 (= a_21 0.0)))
 (or $x423 $x424))))
(assert
 (let (($x426 (= b_10 0.0)))
 (let (($x423 (= a_21 0.0)))
 (or $x423 $x426))))
(assert
 (let (($x397 (= b_34 0.0)))
 (let (($x423 (= a_21 0.0)))
 (or $x423 $x397))))
(assert
 (let (($x376 (= b_40 0.0)))
 (let (($x423 (= a_21 0.0)))
 (or $x423 $x376))))
(assert
 (let (($x423 (= a_21 0.0)))
 (or $x423 (= b_42 0.0))))
(assert
 (let (($x433 (= a_41 0.0)))
 (let (($x432 (= a_22 0.0)))
 (or $x432 $x433))))
(assert
 (let (($x435 (= b_9 0.0)))
 (let (($x432 (= a_22 0.0)))
 (or $x432 $x435))))
(assert
 (let (($x407 (= b_33 0.0)))
 (let (($x432 (= a_22 0.0)))
 (or $x432 $x407))))
(assert
 (let (($x376 (= b_40 0.0)))
 (let (($x432 (= a_22 0.0)))
 (or $x432 $x376))))
(assert
 (let (($x432 (= a_22 0.0)))
 (or $x432 (= b_41 0.0))))
(assert
 (let (($x376 (= b_40 0.0)))
 (or (= a_23 0.0) $x376)))
(assert
 (let (($x444 (= a_38 0.0)))
 (let (($x443 (= a_25 0.0)))
 (or $x443 $x444))))
(assert
 (let (($x446 (= b_6 0.0)))
 (let (($x443 (= a_25 0.0)))
 (or $x443 $x446))))
(assert
 (let (($x397 (= b_34 0.0)))
 (let (($x443 (= a_25 0.0)))
 (or $x443 $x397))))
(assert
 (let (($x387 (= b_36 0.0)))
 (let (($x443 (= a_25 0.0)))
 (or $x443 $x387))))
(assert
 (let (($x443 (= a_25 0.0)))
 (or $x443 (= b_38 0.0))))
(assert
 (let (($x453 (= a_37 0.0)))
 (let (($x452 (= a_26 0.0)))
 (or $x452 $x453))))
(assert
 (let (($x455 (= b_5 0.0)))
 (let (($x452 (= a_26 0.0)))
 (or $x452 $x455))))
(assert
 (let (($x407 (= b_33 0.0)))
 (let (($x452 (= a_26 0.0)))
 (or $x452 $x407))))
(assert
 (let (($x387 (= b_36 0.0)))
 (let (($x452 (= a_26 0.0)))
 (or $x452 $x387))))
(assert
 (let (($x452 (= a_26 0.0)))
 (or $x452 (= b_37 0.0))))
(assert
 (let (($x387 (= b_36 0.0)))
 (or (= a_27 0.0) $x387)))
(assert
 (let (($x464 (= a_35 0.0)))
 (let (($x463 (= a_28 0.0)))
 (or $x463 $x464))))
(assert
 (let (($x466 (= b_3 0.0)))
 (let (($x463 (= a_28 0.0)))
 (or $x463 $x466))))
(assert
 (let (($x407 (= b_33 0.0)))
 (let (($x463 (= a_28 0.0)))
 (or $x463 $x407))))
(assert
 (let (($x397 (= b_34 0.0)))
 (let (($x463 (= a_28 0.0)))
 (or $x463 $x397))))
(assert
 (let (($x463 (= a_28 0.0)))
 (or $x463 (= b_35 0.0))))
(assert
 (let (($x397 (= b_34 0.0)))
 (or (= a_29 0.0) $x397)))
(assert
 (let (($x407 (= b_33 0.0)))
 (or (= a_30 0.0) $x407)))
(assert
 (let (($x417 (= b_12 0.0)))
 (let (($x464 (= a_35 0.0)))
 (or $x464 $x417))))
(assert
 (let (($x385 (= b_20 0.0)))
 (let (($x464 (= a_35 0.0)))
 (or $x464 $x385))))
(assert
 (let (($x374 (= b_24 0.0)))
 (let (($x464 (= a_35 0.0)))
 (or $x464 $x374))))
(assert
 (let (($x464 (= a_35 0.0)))
 (or $x464 (= b_28 0.0))))
(assert
 (let (($x426 (= b_10 0.0)))
 (let (($x453 (= a_37 0.0)))
 (or $x453 $x426))))
(assert
 (let (($x395 (= b_18 0.0)))
 (let (($x453 (= a_37 0.0)))
 (or $x453 $x395))))
(assert
 (let (($x374 (= b_24 0.0)))
 (let (($x453 (= a_37 0.0)))
 (or $x453 $x374))))
(assert
 (let (($x453 (= a_37 0.0)))
 (or $x453 (= b_26 0.0))))
(assert
 (let (($x435 (= b_9 0.0)))
 (let (($x444 (= a_38 0.0)))
 (or $x444 $x435))))
(assert
 (let (($x405 (= b_17 0.0)))
 (let (($x444 (= a_38 0.0)))
 (or $x444 $x405))))
(assert
 (let (($x374 (= b_24 0.0)))
 (let (($x444 (= a_38 0.0)))
 (or $x444 $x374))))
(assert
 (let (($x444 (= a_38 0.0)))
 (or $x444 (= b_25 0.0))))
(assert
 (let (($x374 (= b_24 0.0)))
 (or (= a_39 0.0) $x374)))
(assert
 (let (($x446 (= b_6 0.0)))
 (let (($x433 (= a_41 0.0)))
 (or $x433 $x446))))
(assert
 (let (($x395 (= b_18 0.0)))
 (let (($x433 (= a_41 0.0)))
 (or $x433 $x395))))
(assert
 (let (($x385 (= b_20 0.0)))
 (let (($x433 (= a_41 0.0)))
 (or $x433 $x385))))
(assert
 (let (($x433 (= a_41 0.0)))
 (or $x433 (= b_22 0.0))))
(assert
 (let (($x455 (= b_5 0.0)))
 (let (($x424 (= a_42 0.0)))
 (or $x424 $x455))))
(assert
 (let (($x405 (= b_17 0.0)))
 (let (($x424 (= a_42 0.0)))
 (or $x424 $x405))))
(assert
 (let (($x385 (= b_20 0.0)))
 (let (($x424 (= a_42 0.0)))
 (or $x424 $x385))))
(assert
 (let (($x424 (= a_42 0.0)))
 (or $x424 (= b_21 0.0))))
(assert
 (let (($x385 (= b_20 0.0)))
 (or (= a_43 0.0) $x385)))
(assert
 (let (($x466 (= b_3 0.0)))
 (let (($x415 (= a_44 0.0)))
 (or $x415 $x466))))
(assert
 (let (($x405 (= b_17 0.0)))
 (let (($x415 (= a_44 0.0)))
 (or $x415 $x405))))
(assert
 (let (($x395 (= b_18 0.0)))
 (let (($x415 (= a_44 0.0)))
 (or $x415 $x395))))
(assert
 (let (($x415 (= a_44 0.0)))
 (or $x415 (= b_19 0.0))))
(assert
 (let (($x395 (= b_18 0.0)))
 (or (= a_45 0.0) $x395)))
(assert
 (let (($x405 (= b_17 0.0)))
 (or (= a_46 0.0) $x405)))
(assert
 (let (($x446 (= b_6 0.0)))
 (let (($x403 (= a_49 0.0)))
 (or $x403 $x446))))
(assert
 (let (($x426 (= b_10 0.0)))
 (let (($x403 (= a_49 0.0)))
 (or $x403 $x426))))
(assert
 (let (($x417 (= b_12 0.0)))
 (let (($x403 (= a_49 0.0)))
 (or $x403 $x417))))
(assert
 (let (($x403 (= a_49 0.0)))
 (or $x403 (= b_14 0.0))))
(assert
 (let (($x455 (= b_5 0.0)))
 (let (($x393 (= a_50 0.0)))
 (or $x393 $x455))))
(assert
 (let (($x435 (= b_9 0.0)))
 (let (($x393 (= a_50 0.0)))
 (or $x393 $x435))))
(assert
 (let (($x417 (= b_12 0.0)))
 (let (($x393 (= a_50 0.0)))
 (or $x393 $x417))))
(assert
 (let (($x393 (= a_50 0.0)))
 (or $x393 (= b_13 0.0))))
(assert
 (let (($x417 (= b_12 0.0)))
 (or (= a_51 0.0) $x417)))
(assert
 (let (($x466 (= b_3 0.0)))
 (let (($x383 (= a_52 0.0)))
 (or $x383 $x466))))
(assert
 (let (($x435 (= b_9 0.0)))
 (let (($x383 (= a_52 0.0)))
 (or $x383 $x435))))
(assert
 (let (($x426 (= b_10 0.0)))
 (let (($x383 (= a_52 0.0)))
 (or $x383 $x426))))
(assert
 (let (($x383 (= a_52 0.0)))
 (or $x383 (= b_11 0.0))))
(assert
 (let (($x426 (= b_10 0.0)))
 (or (= a_53 0.0) $x426)))
(assert
 (let (($x435 (= b_9 0.0)))
 (or (= a_54 0.0) $x435)))
(assert
 (let (($x466 (= b_3 0.0)))
 (let (($x372 (= a_56 0.0)))
 (or $x372 $x466))))
(assert
 (let (($x455 (= b_5 0.0)))
 (let (($x372 (= a_56 0.0)))
 (or $x372 $x455))))
(assert
 (let (($x446 (= b_6 0.0)))
 (let (($x372 (= a_56 0.0)))
 (or $x372 $x446))))
(assert
 (let (($x372 (= a_56 0.0)))
 (or $x372 (= b_7 0.0))))
(assert
 (let (($x446 (= b_6 0.0)))
 (or (= a_57 0.0) $x446)))
(assert
 (let (($x455 (= b_5 0.0)))
 (or (= a_58 0.0) $x455)))
(assert
 (let (($x466 (= b_3 0.0)))
 (or (= a_60 0.0) $x466)))
(assert
 (let ((?x549 (* 2.0 q)))
 (let ((?x550 (- ?x549 1.0)))
 (let ((?x547 (+ b_3 b_5 b_7 b_9 b_11 b_13 b_15 b_17 b_19 b_21 b_23 b_25 b_27 b_29 b_31 b_33 b_35 b_37 b_39 b_41 b_43 b_45 b_47 b_49 b_51 b_53 b_55 b_57 b_59 b_61 b_63)))
 (let ((?x546 (+ a_7 a_11 a_13 a_15 a_19 a_21 a_23 a_25 a_27 a_29 a_31 a_35 a_37 a_39 a_41 a_43 a_45 a_47 a_49 a_51 a_53 a_55 a_57 a_59 a_61 a_63)))
 (= (+ ?x546 ?x547) ?x550))))))
(assert
 (let ((?x546 (+ a_7 a_11 a_13 a_15 a_19 a_21 a_23 a_25 a_27 a_29 a_31 a_35 a_37 a_39 a_41 a_43 a_45 a_47 a_49 a_51 a_53 a_55 a_57 a_59 a_61 a_63)))
 (let ((?x552 (- q ?x546)))
 (let ((?x36 (/ (- (/ 7.0 8.0) q) 10.0)))
 (let ((?x46 (/ ?x36 2.0)))
 (let ((?x47 (- (- 3.0 (* 3.0 q)) ?x46)))
 (let ((?x63 (- 1.0 ?x47)))
 (let (($x575 (and (>= ?x552 (- 1.0 (- (- (/ 3.0 7.0) (* (/ 5.0 4.0) (- q (/ 6.0 7.0)))) ?x36))) (<= ?x552 (- 1.0 (- (- (/ 3.0 7.0) (* (/ 5.0 4.0) (- q (/ 6.0 7.0)))) ?x36))))))
 (let (($x572 (and (>= ?x552 (- 1.0 (+ (/ q 2.0) (/ (* 3.0 ?x36) 2.0)))) (<= ?x552 (- 1.0 (+ (/ q 2.0) ?x46))))))
 (let ((?x51 (/ (* 3.0 ?x36) 2.0)))
 (let ((?x56 (+ (+ (/ 3.0 7.0) (* (/ 9.0 4.0) (- q (/ 6.0 7.0)))) ?x51)))
 (let ((?x59 (- 1.0 ?x56)))
 (let (($x566 (and (>= ?x552 (+ (/ q 2.0) ?x46)) (<= ?x552 (+ (/ q 2.0) ?x51)))))
 (let (($x563 (and (>= ?x552 (- (- (/ 3.0 7.0) (* (/ 5.0 4.0) (- q (/ 6.0 7.0)))) ?x36)) (<= ?x552 (- (- (/ 3.0 7.0) (* (/ 5.0 4.0) (- q (/ 6.0 7.0)))) ?x36)))))
 (or (and (>= ?x552 (- 1.0 q)) (<= ?x552 ?x47)) $x563 $x566 (and (>= ?x552 ?x56) (<= ?x552 ?x59)) $x572 $x575 (and (>= ?x552 ?x63) (<= ?x552 q)))))))))))))))))
(assert
 (let ((?x549 (* 2.0 q)))
 (let ((?x550 (- ?x549 1.0)))
 (let ((?x795 (+ b_3 b_6 b_7 b_10 b_11 b_14 b_15 b_18 b_19 b_22 b_23 b_26 b_27 b_30 b_31 b_34 b_35 b_38 b_39 b_42 b_43 b_46 b_47 b_50 b_51 b_54 b_55 b_58 b_59 b_62 b_63)))
 (let ((?x794 (+ a_7 a_11 a_14 a_15 a_19 a_22 a_23 a_26 a_27 a_30 a_31 a_35 a_38 a_39 a_42 a_43 a_46 a_47 a_50 a_51 a_54 a_55 a_58 a_59 a_62 a_63)))
 (= (+ ?x794 ?x795) ?x550))))))
(assert
 (let ((?x794 (+ a_7 a_11 a_14 a_15 a_19 a_22 a_23 a_26 a_27 a_30 a_31 a_35 a_38 a_39 a_42 a_43 a_46 a_47 a_50 a_51 a_54 a_55 a_58 a_59 a_62 a_63)))
 (let ((?x798 (- q ?x794)))
 (let ((?x36 (/ (- (/ 7.0 8.0) q) 10.0)))
 (let ((?x46 (/ ?x36 2.0)))
 (let ((?x47 (- (- 3.0 (* 3.0 q)) ?x46)))
 (let ((?x63 (- 1.0 ?x47)))
 (let (($x818 (and (>= ?x798 (- 1.0 (- (- (/ 3.0 7.0) (* (/ 5.0 4.0) (- q (/ 6.0 7.0)))) ?x36))) (<= ?x798 (- 1.0 (- (- (/ 3.0 7.0) (* (/ 5.0 4.0) (- q (/ 6.0 7.0)))) ?x36))))))
 (let (($x815 (and (>= ?x798 (- 1.0 (+ (/ q 2.0) (/ (* 3.0 ?x36) 2.0)))) (<= ?x798 (- 1.0 (+ (/ q 2.0) ?x46))))))
 (let ((?x51 (/ (* 3.0 ?x36) 2.0)))
 (let ((?x56 (+ (+ (/ 3.0 7.0) (* (/ 9.0 4.0) (- q (/ 6.0 7.0)))) ?x51)))
 (let ((?x59 (- 1.0 ?x56)))
 (let (($x809 (and (>= ?x798 (+ (/ q 2.0) ?x46)) (<= ?x798 (+ (/ q 2.0) ?x51)))))
 (let (($x806 (and (>= ?x798 (- (- (/ 3.0 7.0) (* (/ 5.0 4.0) (- q (/ 6.0 7.0)))) ?x36)) (<= ?x798 (- (- (/ 3.0 7.0) (* (/ 5.0 4.0) (- q (/ 6.0 7.0)))) ?x36)))))
 (or (and (>= ?x798 (- 1.0 q)) (<= ?x798 ?x47)) $x806 $x809 (and (>= ?x798 ?x56) (<= ?x798 ?x59)) $x815 $x818 (and (>= ?x798 ?x63) (<= ?x798 q)))))))))))))))))
(assert
 (let ((?x549 (* 2.0 q)))
 (let ((?x550 (- ?x549 1.0)))
 (let ((?x861 (+ b_5 b_6 b_7 b_12 b_13 b_14 b_15 b_20 b_21 b_22 b_23 b_28 b_29 b_30 b_31 b_36 b_37 b_38 b_39 b_44 b_45 b_46 b_47 b_52 b_53 b_54 b_55 b_60 b_61 b_62 b_63)))
 (let ((?x860 (+ a_7 a_13 a_14 a_15 a_21 a_22 a_23 a_28 a_29 a_30 a_31 a_37 a_38 a_39 a_44 a_45 a_46 a_47 a_52 a_53 a_54 a_55 a_60 a_61 a_62 a_63)))
 (= (+ ?x860 ?x861) ?x550))))))
(assert
 (let ((?x860 (+ a_7 a_13 a_14 a_15 a_21 a_22 a_23 a_28 a_29 a_30 a_31 a_37 a_38 a_39 a_44 a_45 a_46 a_47 a_52 a_53 a_54 a_55 a_60 a_61 a_62 a_63)))
 (let ((?x864 (- q ?x860)))
 (let ((?x36 (/ (- (/ 7.0 8.0) q) 10.0)))
 (let ((?x46 (/ ?x36 2.0)))
 (let ((?x47 (- (- 3.0 (* 3.0 q)) ?x46)))
 (let ((?x63 (- 1.0 ?x47)))
 (let (($x884 (and (>= ?x864 (- 1.0 (- (- (/ 3.0 7.0) (* (/ 5.0 4.0) (- q (/ 6.0 7.0)))) ?x36))) (<= ?x864 (- 1.0 (- (- (/ 3.0 7.0) (* (/ 5.0 4.0) (- q (/ 6.0 7.0)))) ?x36))))))
 (let (($x881 (and (>= ?x864 (- 1.0 (+ (/ q 2.0) (/ (* 3.0 ?x36) 2.0)))) (<= ?x864 (- 1.0 (+ (/ q 2.0) ?x46))))))
 (let ((?x51 (/ (* 3.0 ?x36) 2.0)))
 (let ((?x56 (+ (+ (/ 3.0 7.0) (* (/ 9.0 4.0) (- q (/ 6.0 7.0)))) ?x51)))
 (let ((?x59 (- 1.0 ?x56)))
 (let (($x875 (and (>= ?x864 (+ (/ q 2.0) ?x46)) (<= ?x864 (+ (/ q 2.0) ?x51)))))
 (let (($x872 (and (>= ?x864 (- (- (/ 3.0 7.0) (* (/ 5.0 4.0) (- q (/ 6.0 7.0)))) ?x36)) (<= ?x864 (- (- (/ 3.0 7.0) (* (/ 5.0 4.0) (- q (/ 6.0 7.0)))) ?x36)))))
 (or (and (>= ?x864 (- 1.0 q)) (<= ?x864 ?x47)) $x872 $x875 (and (>= ?x864 ?x56) (<= ?x864 ?x59)) $x881 $x884 (and (>= ?x864 ?x63) (<= ?x864 q)))))))))))))))))
(assert
 (let ((?x549 (* 2.0 q)))
 (let ((?x550 (- ?x549 1.0)))
 (let ((?x927 (+ b_9 b_10 b_11 b_12 b_13 b_14 b_15 b_24 b_25 b_26 b_27 b_28 b_29 b_30 b_31 b_40 b_41 b_42 b_43 b_44 b_45 b_46 b_47 b_56 b_57 b_58 b_59 b_60 b_61 b_62 b_63)))
 (let ((?x926 (+ a_11 a_13 a_14 a_15 a_25 a_26 a_27 a_28 a_29 a_30 a_31 a_41 a_42 a_43 a_44 a_45 a_46 a_47 a_56 a_57 a_58 a_59 a_60 a_61 a_62 a_63)))
 (= (+ ?x926 ?x927) ?x550))))))
(assert
 (let ((?x926 (+ a_11 a_13 a_14 a_15 a_25 a_26 a_27 a_28 a_29 a_30 a_31 a_41 a_42 a_43 a_44 a_45 a_46 a_47 a_56 a_57 a_58 a_59 a_60 a_61 a_62 a_63)))
 (let ((?x930 (- q ?x926)))
 (let ((?x36 (/ (- (/ 7.0 8.0) q) 10.0)))
 (let ((?x46 (/ ?x36 2.0)))
 (let ((?x47 (- (- 3.0 (* 3.0 q)) ?x46)))
 (let ((?x63 (- 1.0 ?x47)))
 (let (($x950 (and (>= ?x930 (- 1.0 (- (- (/ 3.0 7.0) (* (/ 5.0 4.0) (- q (/ 6.0 7.0)))) ?x36))) (<= ?x930 (- 1.0 (- (- (/ 3.0 7.0) (* (/ 5.0 4.0) (- q (/ 6.0 7.0)))) ?x36))))))
 (let (($x947 (and (>= ?x930 (- 1.0 (+ (/ q 2.0) (/ (* 3.0 ?x36) 2.0)))) (<= ?x930 (- 1.0 (+ (/ q 2.0) ?x46))))))
 (let ((?x51 (/ (* 3.0 ?x36) 2.0)))
 (let ((?x56 (+ (+ (/ 3.0 7.0) (* (/ 9.0 4.0) (- q (/ 6.0 7.0)))) ?x51)))
 (let ((?x59 (- 1.0 ?x56)))
 (let (($x941 (and (>= ?x930 (+ (/ q 2.0) ?x46)) (<= ?x930 (+ (/ q 2.0) ?x51)))))
 (let (($x938 (and (>= ?x930 (- (- (/ 3.0 7.0) (* (/ 5.0 4.0) (- q (/ 6.0 7.0)))) ?x36)) (<= ?x930 (- (- (/ 3.0 7.0) (* (/ 5.0 4.0) (- q (/ 6.0 7.0)))) ?x36)))))
 (or (and (>= ?x930 (- 1.0 q)) (<= ?x930 ?x47)) $x938 $x941 (and (>= ?x930 ?x56) (<= ?x930 ?x59)) $x947 $x950 (and (>= ?x930 ?x63) (<= ?x930 q)))))))))))))))))
(assert
 (let ((?x549 (* 2.0 q)))
 (let ((?x550 (- ?x549 1.0)))
 (let ((?x993 (+ b_17 b_18 b_19 b_20 b_21 b_22 b_23 b_24 b_25 b_26 b_27 b_28 b_29 b_30 b_31 b_48 b_49 b_50 b_51 b_52 b_53 b_54 b_55 b_56 b_57 b_58 b_59 b_60 b_61 b_62 b_63)))
 (let ((?x992 (+ a_19 a_21 a_22 a_23 a_25 a_26 a_27 a_28 a_29 a_30 a_31 a_49 a_50 a_51 a_52 a_53 a_54 a_55 a_56 a_57 a_58 a_59 a_60 a_61 a_62 a_63)))
 (= (+ ?x992 ?x993) ?x550))))))
(assert
 (let ((?x992 (+ a_19 a_21 a_22 a_23 a_25 a_26 a_27 a_28 a_29 a_30 a_31 a_49 a_50 a_51 a_52 a_53 a_54 a_55 a_56 a_57 a_58 a_59 a_60 a_61 a_62 a_63)))
 (let ((?x996 (- q ?x992)))
 (let ((?x36 (/ (- (/ 7.0 8.0) q) 10.0)))
 (let ((?x46 (/ ?x36 2.0)))
 (let ((?x47 (- (- 3.0 (* 3.0 q)) ?x46)))
 (let ((?x63 (- 1.0 ?x47)))
 (let (($x1016 (and (>= ?x996 (- 1.0 (- (- (/ 3.0 7.0) (* (/ 5.0 4.0) (- q (/ 6.0 7.0)))) ?x36))) (<= ?x996 (- 1.0 (- (- (/ 3.0 7.0) (* (/ 5.0 4.0) (- q (/ 6.0 7.0)))) ?x36))))))
 (let (($x1013 (and (>= ?x996 (- 1.0 (+ (/ q 2.0) (/ (* 3.0 ?x36) 2.0)))) (<= ?x996 (- 1.0 (+ (/ q 2.0) ?x46))))))
 (let ((?x51 (/ (* 3.0 ?x36) 2.0)))
 (let ((?x56 (+ (+ (/ 3.0 7.0) (* (/ 9.0 4.0) (- q (/ 6.0 7.0)))) ?x51)))
 (let ((?x59 (- 1.0 ?x56)))
 (let (($x1007 (and (>= ?x996 (+ (/ q 2.0) ?x46)) (<= ?x996 (+ (/ q 2.0) ?x51)))))
 (let (($x1004 (and (>= ?x996 (- (- (/ 3.0 7.0) (* (/ 5.0 4.0) (- q (/ 6.0 7.0)))) ?x36)) (<= ?x996 (- (- (/ 3.0 7.0) (* (/ 5.0 4.0) (- q (/ 6.0 7.0)))) ?x36)))))
 (or (and (>= ?x996 (- 1.0 q)) (<= ?x996 ?x47)) $x1004 $x1007 (and (>= ?x996 ?x56) (<= ?x996 ?x59)) $x1013 $x1016 (and (>= ?x996 ?x63) (<= ?x996 q)))))))))))))))))
(assert
 (let ((?x549 (* 2.0 q)))
 (let ((?x550 (- ?x549 1.0)))
 (let ((?x1059 (+ b_33 b_34 b_35 b_36 b_37 b_38 b_39 b_40 b_41 b_42 b_43 b_44 b_45 b_46 b_47 b_48 b_49 b_50 b_51 b_52 b_53 b_54 b_55 b_56 b_57 b_58 b_59 b_60 b_61 b_62 b_63)))
 (let ((?x1058 (+ a_35 a_37 a_38 a_39 a_41 a_42 a_43 a_44 a_45 a_46 a_47 a_49 a_50 a_51 a_52 a_53 a_54 a_55 a_56 a_57 a_58 a_59 a_60 a_61 a_62 a_63)))
 (= (+ ?x1058 ?x1059) ?x550))))))
(assert
 (let ((?x1058 (+ a_35 a_37 a_38 a_39 a_41 a_42 a_43 a_44 a_45 a_46 a_47 a_49 a_50 a_51 a_52 a_53 a_54 a_55 a_56 a_57 a_58 a_59 a_60 a_61 a_62 a_63)))
 (let ((?x1062 (- q ?x1058)))
 (let ((?x36 (/ (- (/ 7.0 8.0) q) 10.0)))
 (let ((?x46 (/ ?x36 2.0)))
 (let ((?x47 (- (- 3.0 (* 3.0 q)) ?x46)))
 (let ((?x63 (- 1.0 ?x47)))
 (let (($x1082 (and (>= ?x1062 (- 1.0 (- (- (/ 3.0 7.0) (* (/ 5.0 4.0) (- q (/ 6.0 7.0)))) ?x36))) (<= ?x1062 (- 1.0 (- (- (/ 3.0 7.0) (* (/ 5.0 4.0) (- q (/ 6.0 7.0)))) ?x36))))))
 (let (($x1079 (and (>= ?x1062 (- 1.0 (+ (/ q 2.0) (/ (* 3.0 ?x36) 2.0)))) (<= ?x1062 (- 1.0 (+ (/ q 2.0) ?x46))))))
 (let ((?x51 (/ (* 3.0 ?x36) 2.0)))
 (let ((?x56 (+ (+ (/ 3.0 7.0) (* (/ 9.0 4.0) (- q (/ 6.0 7.0)))) ?x51)))
 (let ((?x59 (- 1.0 ?x56)))
 (let (($x1073 (and (>= ?x1062 (+ (/ q 2.0) ?x46)) (<= ?x1062 (+ (/ q 2.0) ?x51)))))
 (let (($x1070 (and (>= ?x1062 (- (- (/ 3.0 7.0) (* (/ 5.0 4.0) (- q (/ 6.0 7.0)))) ?x36)) (<= ?x1062 (- (- (/ 3.0 7.0) (* (/ 5.0 4.0) (- q (/ 6.0 7.0)))) ?x36)))))
 (or (and (>= ?x1062 (- 1.0 q)) (<= ?x1062 ?x47)) $x1070 $x1073 (and (>= ?x1062 ?x56) (<= ?x1062 ?x59)) $x1079 $x1082 (and (>= ?x1062 ?x63) (<= ?x1062 q)))))))))))))))))
(assert
 (let ((?x794 (+ a_7 a_11 a_14 a_15 a_19 a_22 a_23 a_26 a_27 a_30 a_31 a_35 a_38 a_39 a_42 a_43 a_46 a_47 a_50 a_51 a_54 a_55 a_58 a_59 a_62 a_63)))
 (let ((?x798 (- q ?x794)))
 (let ((?x546 (+ a_7 a_11 a_13 a_15 a_19 a_21 a_23 a_25 a_27 a_29 a_31 a_35 a_37 a_39 a_41 a_43 a_45 a_47 a_49 a_51 a_53 a_55 a_57 a_59 a_61 a_63)))
 (let ((?x552 (- q ?x546)))
 (<= ?x552 ?x798))))))
(assert
 (let ((?x860 (+ a_7 a_13 a_14 a_15 a_21 a_22 a_23 a_28 a_29 a_30 a_31 a_37 a_38 a_39 a_44 a_45 a_46 a_47 a_52 a_53 a_54 a_55 a_60 a_61 a_62 a_63)))
 (let ((?x864 (- q ?x860)))
 (let ((?x794 (+ a_7 a_11 a_14 a_15 a_19 a_22 a_23 a_26 a_27 a_30 a_31 a_35 a_38 a_39 a_42 a_43 a_46 a_47 a_50 a_51 a_54 a_55 a_58 a_59 a_62 a_63)))
 (let ((?x798 (- q ?x794)))
 (<= ?x798 ?x864))))))
(assert
 (let ((?x926 (+ a_11 a_13 a_14 a_15 a_25 a_26 a_27 a_28 a_29 a_30 a_31 a_41 a_42 a_43 a_44 a_45 a_46 a_47 a_56 a_57 a_58 a_59 a_60 a_61 a_62 a_63)))
 (let ((?x930 (- q ?x926)))
 (let ((?x860 (+ a_7 a_13 a_14 a_15 a_21 a_22 a_23 a_28 a_29 a_30 a_31 a_37 a_38 a_39 a_44 a_45 a_46 a_47 a_52 a_53 a_54 a_55 a_60 a_61 a_62 a_63)))
 (let ((?x864 (- q ?x860)))
 (<= ?x864 ?x930))))))
(assert
 (let ((?x992 (+ a_19 a_21 a_22 a_23 a_25 a_26 a_27 a_28 a_29 a_30 a_31 a_49 a_50 a_51 a_52 a_53 a_54 a_55 a_56 a_57 a_58 a_59 a_60 a_61 a_62 a_63)))
 (let ((?x996 (- q ?x992)))
 (let ((?x926 (+ a_11 a_13 a_14 a_15 a_25 a_26 a_27 a_28 a_29 a_30 a_31 a_41 a_42 a_43 a_44 a_45 a_46 a_47 a_56 a_57 a_58 a_59 a_60 a_61 a_62 a_63)))
 (let ((?x930 (- q ?x926)))
 (<= ?x930 ?x996))))))
(assert
 (let ((?x1058 (+ a_35 a_37 a_38 a_39 a_41 a_42 a_43 a_44 a_45 a_46 a_47 a_49 a_50 a_51 a_52 a_53 a_54 a_55 a_56 a_57 a_58 a_59 a_60 a_61 a_62 a_63)))
(let ((?x1062 (- q ?x1058)))
(let ((?x992 (+ a_19 a_21 a_22 a_23 a_25 a_26 a_27 a_28 a_29 a_30 a_31 a_49 a_50 a_51 a_52 a_53 a_54 a_55 a_56 a_57 a_58 a_59 a_60 a_61 a_62 a_63)))
(let ((?x996 (- q ?x992)))
(<= ?x996 ?x1062))))))
(check-sat)
